var tweet_index =  [ {
  "file_name" : "data\/js\/tweets\/2017_12.js",
  "year" : 2017,
  "var_name" : "tweets_2017_12",
  "tweet_count" : 5,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2017_11.js",
  "year" : 2017,
  "var_name" : "tweets_2017_11",
  "tweet_count" : 23,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2017_10.js",
  "year" : 2017,
  "var_name" : "tweets_2017_10",
  "tweet_count" : 3,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2017_09.js",
  "year" : 2017,
  "var_name" : "tweets_2017_09",
  "tweet_count" : 25,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2017_07.js",
  "year" : 2017,
  "var_name" : "tweets_2017_07",
  "tweet_count" : 1,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2017_05.js",
  "year" : 2017,
  "var_name" : "tweets_2017_05",
  "tweet_count" : 1,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2017_03.js",
  "year" : 2017,
  "var_name" : "tweets_2017_03",
  "tweet_count" : 1,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2017_01.js",
  "year" : 2017,
  "var_name" : "tweets_2017_01",
  "tweet_count" : 4,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2016_11.js",
  "year" : 2016,
  "var_name" : "tweets_2016_11",
  "tweet_count" : 1,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2016_09.js",
  "year" : 2016,
  "var_name" : "tweets_2016_09",
  "tweet_count" : 1,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2016_08.js",
  "year" : 2016,
  "var_name" : "tweets_2016_08",
  "tweet_count" : 1,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2016_07.js",
  "year" : 2016,
  "var_name" : "tweets_2016_07",
  "tweet_count" : 3,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2016_03.js",
  "year" : 2016,
  "var_name" : "tweets_2016_03",
  "tweet_count" : 13,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2016_02.js",
  "year" : 2016,
  "var_name" : "tweets_2016_02",
  "tweet_count" : 5,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2016_01.js",
  "year" : 2016,
  "var_name" : "tweets_2016_01",
  "tweet_count" : 99,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2015_12.js",
  "year" : 2015,
  "var_name" : "tweets_2015_12",
  "tweet_count" : 9,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2015_11.js",
  "year" : 2015,
  "var_name" : "tweets_2015_11",
  "tweet_count" : 3,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2015_10.js",
  "year" : 2015,
  "var_name" : "tweets_2015_10",
  "tweet_count" : 1,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2015_09.js",
  "year" : 2015,
  "var_name" : "tweets_2015_09",
  "tweet_count" : 12,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2015_08.js",
  "year" : 2015,
  "var_name" : "tweets_2015_08",
  "tweet_count" : 3,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2015_07.js",
  "year" : 2015,
  "var_name" : "tweets_2015_07",
  "tweet_count" : 3,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2015_05.js",
  "year" : 2015,
  "var_name" : "tweets_2015_05",
  "tweet_count" : 1,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2014_04.js",
  "year" : 2014,
  "var_name" : "tweets_2014_04",
  "tweet_count" : 1,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2014_03.js",
  "year" : 2014,
  "var_name" : "tweets_2014_03",
  "tweet_count" : 1,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2014_02.js",
  "year" : 2014,
  "var_name" : "tweets_2014_02",
  "tweet_count" : 3,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2014_01.js",
  "year" : 2014,
  "var_name" : "tweets_2014_01",
  "tweet_count" : 10,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2013_12.js",
  "year" : 2013,
  "var_name" : "tweets_2013_12",
  "tweet_count" : 4,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2013_10.js",
  "year" : 2013,
  "var_name" : "tweets_2013_10",
  "tweet_count" : 3,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2013_09.js",
  "year" : 2013,
  "var_name" : "tweets_2013_09",
  "tweet_count" : 11,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2013_08.js",
  "year" : 2013,
  "var_name" : "tweets_2013_08",
  "tweet_count" : 7,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2013_06.js",
  "year" : 2013,
  "var_name" : "tweets_2013_06",
  "tweet_count" : 2,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2013_05.js",
  "year" : 2013,
  "var_name" : "tweets_2013_05",
  "tweet_count" : 1,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2013_01.js",
  "year" : 2013,
  "var_name" : "tweets_2013_01",
  "tweet_count" : 8,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2012_08.js",
  "year" : 2012,
  "var_name" : "tweets_2012_08",
  "tweet_count" : 1,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2012_07.js",
  "year" : 2012,
  "var_name" : "tweets_2012_07",
  "tweet_count" : 2,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2010_05.js",
  "year" : 2010,
  "var_name" : "tweets_2010_05",
  "tweet_count" : 1,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2010_04.js",
  "year" : 2010,
  "var_name" : "tweets_2010_04",
  "tweet_count" : 1,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2010_02.js",
  "year" : 2010,
  "var_name" : "tweets_2010_02",
  "tweet_count" : 3,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2009_08.js",
  "year" : 2009,
  "var_name" : "tweets_2009_08",
  "tweet_count" : 1,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2009_07.js",
  "year" : 2009,
  "var_name" : "tweets_2009_07",
  "tweet_count" : 1,
  "month" : 7
} ]