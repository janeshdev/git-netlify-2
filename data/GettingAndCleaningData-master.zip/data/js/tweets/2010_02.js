Grailbird.data.tweets_2010_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujan Baral",
      "screen_name" : "baralsujan",
      "indices" : [ 0, 11 ],
      "id_str" : "18218149",
      "id" : 18218149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9672248958",
  "geo" : { },
  "id_str" : "9685394702",
  "in_reply_to_user_id" : 18218149,
  "text" : "@baralsujan k bhayo ra baral ?",
  "id" : 9685394702,
  "in_reply_to_status_id" : 9672248958,
  "created_at" : "2010-02-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "baralsujan",
  "in_reply_to_user_id_str" : "18218149",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EzineArticles",
      "screen_name" : "EzineArticles",
      "indices" : [ 0, 14 ],
      "id_str" : "14632998",
      "id" : 14632998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9648446182",
  "in_reply_to_user_id" : 14632998,
  "text" : "@EzineArticles - I pledge to write and submit at least 100 articles before Apr 10 for the 3rd HAHD Challenge. Go me! http:\/\/is.gd\/5xWJW",
  "id" : 9648446182,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "EzineArticles",
  "in_reply_to_user_id_str" : "14632998",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rajan Devkota",
      "screen_name" : "rajandevkota",
      "indices" : [ 0, 13 ],
      "id_str" : "69660252",
      "id" : 69660252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6441028607",
  "geo" : { },
  "id_str" : "9648720838",
  "in_reply_to_user_id" : 69660252,
  "text" : "@rajandevkota what's this ?",
  "id" : 9648720838,
  "in_reply_to_status_id" : 6441028607,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "rajandevkota",
  "in_reply_to_user_id_str" : "69660252",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]