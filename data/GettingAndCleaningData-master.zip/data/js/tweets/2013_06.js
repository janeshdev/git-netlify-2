Grailbird.data.tweets_2013_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janaranjan Devkota",
      "screen_name" : "devkotajanan",
      "indices" : [ 0, 13 ],
      "id_str" : "628011414",
      "id" : 628011414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342322168954241024",
  "in_reply_to_user_id" : 628011414,
  "text" : "@devkotajanan r u travelling ?",
  "id" : 342322168954241024,
  "created_at" : "2013-06-05 16:48:59 +0000",
  "in_reply_to_screen_name" : "devkotajanan",
  "in_reply_to_user_id_str" : "628011414",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rajan Devkota",
      "screen_name" : "rajandevkota",
      "indices" : [ 0, 13 ],
      "id_str" : "69660252",
      "id" : 69660252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342321929392377856",
  "in_reply_to_user_id" : 69660252,
  "text" : "@rajandevkota what's up dude. Long time no see.",
  "id" : 342321929392377856,
  "created_at" : "2013-06-05 16:48:02 +0000",
  "in_reply_to_screen_name" : "rajandevkota",
  "in_reply_to_user_id_str" : "69660252",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]