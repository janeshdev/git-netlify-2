Grailbird.data.tweets_2017_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 0, 7 ],
      "id_str" : "558797310",
      "id" : 558797310
    }, {
      "name" : "Basti Schweinsteiger",
      "screen_name" : "BSchweinsteiger",
      "indices" : [ 8, 24 ],
      "id_str" : "1283561876",
      "id" : 1283561876
    }, {
      "name" : "Chicago Fire",
      "screen_name" : "ChicagoFire",
      "indices" : [ 25, 37 ],
      "id_str" : "21677316",
      "id" : 21677316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847107837830549510",
  "geo" : { },
  "id_str" : "847118331207303169",
  "in_reply_to_user_id" : 558797310,
  "text" : "@ManUtd @BSchweinsteiger @ChicagoFire Best of luck bastian.",
  "id" : 847118331207303169,
  "in_reply_to_status_id" : 847107837830549510,
  "created_at" : "2017-03-29 16:08:43 +0000",
  "in_reply_to_screen_name" : "ManUtd",
  "in_reply_to_user_id_str" : "558797310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]