Grailbird.data.tweets_2016_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/Lx95mtfQjJ",
      "expanded_url" : "http:\/\/observer.com\/2016\/07\/how-a-billion-oysters-are-set-to-change-new-yorks-harbor\/#.WCnvm1AHvd0.twitter",
      "display_url" : "observer.com\/2016\/07\/how-a-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "798282715384541187",
  "text" : "RT @EFDC_Explorer: How a Billion Oysters Are Set to Change New York\u2019s Harbor https:\/\/t.co\/Lx95mtfQjJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/Lx95mtfQjJ",
        "expanded_url" : "http:\/\/observer.com\/2016\/07\/how-a-billion-oysters-are-set-to-change-new-yorks-harbor\/#.WCnvm1AHvd0.twitter",
        "display_url" : "observer.com\/2016\/07\/how-a-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "798269479365079040",
    "text" : "How a Billion Oysters Are Set to Change New York\u2019s Harbor https:\/\/t.co\/Lx95mtfQjJ",
    "id" : 798269479365079040,
    "created_at" : "2016-11-14 21:00:49 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 798282715384541187,
  "created_at" : "2016-11-14 21:53:25 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]