Grailbird.data.tweets_2015_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC Sport",
      "screen_name" : "BBCSport",
      "indices" : [ 65, 74 ],
      "id_str" : "265902729",
      "id" : 265902729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620222822070157314",
  "text" : "Federer is playing pretty well this season. I think he will win. @BBCSport vote",
  "id" : 620222822070157314,
  "created_at" : "2015-07-12 13:26:58 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wimbledon2015",
      "indices" : [ 17, 31 ]
    }, {
      "text" : "Federer",
      "indices" : [ 32, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620221563380445185",
  "text" : "Come on Federer. #Wimbledon2015 #Federer",
  "id" : 620221563380445185,
  "created_at" : "2015-07-12 13:21:58 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger Federer",
      "screen_name" : "rogerfederer",
      "indices" : [ 53, 66 ],
      "id_str" : "1337785291",
      "id" : 1337785291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wimbledon2015",
      "indices" : [ 83, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619232241630101504",
  "text" : "Murray vs Federer would be a good match. Hoping that @rogerfederer goes through to #Wimbledon2015 final.",
  "id" : 619232241630101504,
  "created_at" : "2015-07-09 19:50:45 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]