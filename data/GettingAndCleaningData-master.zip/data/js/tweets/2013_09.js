Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Everton",
      "indices" : [ 12, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378947374296870912",
  "text" : "Well played #Everton",
  "id" : 378947374296870912,
  "created_at" : "2013-09-14 18:24:29 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374684942623440896",
  "text" : "Wow, what a win for Tommy Robredo !!!!",
  "id" : 374684942623440896,
  "created_at" : "2013-09-03 00:07:06 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bloodzeed",
      "screen_name" : "Bloodzeed",
      "indices" : [ 0, 10 ],
      "id_str" : "375536678",
      "id" : 375536678
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374659684294074368",
  "geo" : { },
  "id_str" : "374659993938579456",
  "in_reply_to_user_id" : 375536678,
  "text" : "@Bloodzeed Is it true that Fellaini signed for United ?",
  "id" : 374659993938579456,
  "in_reply_to_status_id" : 374659684294074368,
  "created_at" : "2013-09-02 22:27:58 +0000",
  "in_reply_to_screen_name" : "Bloodzeed",
  "in_reply_to_user_id_str" : "375536678",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Edwoodwardout",
      "indices" : [ 0, 14 ]
    }, {
      "text" : "DavidGill",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374652251605708801",
  "text" : "#Edwoodwardout What the hell are you doing ? Bring back #DavidGill",
  "id" : 374652251605708801,
  "created_at" : "2013-09-02 21:57:12 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ManUtd",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374648555492753409",
  "text" : "Last 20 minutes and no signings yet..... #ManUtd",
  "id" : 374648555492753409,
  "created_at" : "2013-09-02 21:42:30 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "United",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374643050435190784",
  "text" : "Damn my beloved #United couldn't sign high profile players.",
  "id" : 374643050435190784,
  "created_at" : "2013-09-02 21:20:38 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Arsenal",
      "indices" : [ 19, 27 ]
    }, {
      "text" : "Ozil",
      "indices" : [ 40, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374642079927779328",
  "text" : "Congratulations to #Arsenal for signing #Ozil",
  "id" : 374642079927779328,
  "created_at" : "2013-09-02 21:16:47 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374607453700096000",
  "text" : "Not any signings for United yet ?",
  "id" : 374607453700096000,
  "created_at" : "2013-09-02 18:59:11 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Moyes",
      "indices" : [ 16, 22 ]
    }, {
      "text" : "Ozil",
      "indices" : [ 39, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374512519710142464",
  "text" : "It's sad to see #Moyes not going after #Ozil",
  "id" : 374512519710142464,
  "created_at" : "2013-09-02 12:41:57 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bloodzeed",
      "screen_name" : "Bloodzeed",
      "indices" : [ 0, 10 ],
      "id_str" : "375536678",
      "id" : 375536678
    }, {
      "name" : "indykaila  News",
      "screen_name" : "indykaila",
      "indices" : [ 11, 21 ],
      "id_str" : "580967619",
      "id" : 580967619
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Manchester",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374511531787952128",
  "geo" : { },
  "id_str" : "374511846041997314",
  "in_reply_to_user_id" : 375536678,
  "text" : "@Bloodzeed @indykaila any news regarding #Manchester United ?",
  "id" : 374511846041997314,
  "in_reply_to_status_id" : 374511531787952128,
  "created_at" : "2013-09-02 12:39:16 +0000",
  "in_reply_to_screen_name" : "Bloodzeed",
  "in_reply_to_user_id_str" : "375536678",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Manchester",
      "indices" : [ 114, 125 ]
    }, {
      "text" : "Moyes",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374511459658510337",
  "text" : "Any new signings for Manchester United ? It's so frustrating to see United not being involved in transfer at all. #Manchester United #Moyes",
  "id" : 374511459658510337,
  "created_at" : "2013-09-02 12:37:44 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]