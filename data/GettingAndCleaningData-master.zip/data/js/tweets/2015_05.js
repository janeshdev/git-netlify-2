Grailbird.data.tweets_2015_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoHomeIndianMedia",
      "indices" : [ 72, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595119945802907648",
  "text" : "What's going on India Tv ? Who said Thamel is Mini India of kathmandu ? #GoHomeIndianMedia",
  "id" : 595119945802907648,
  "created_at" : "2015-05-04 06:57:06 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]