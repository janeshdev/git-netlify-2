Grailbird.data.tweets_2015_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/4DTRBTZRSV",
      "expanded_url" : "https:\/\/twitter.com\/KanakManiDixit\/status\/647722744587530240",
      "display_url" : "twitter.com\/KanakManiDixit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648263842066108416",
  "text" : "Yes, apology required  https:\/\/t.co\/4DTRBTZRSV",
  "id" : 648263842066108416,
  "created_at" : "2015-09-27 22:31:58 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basti Schweinsteiger",
      "screen_name" : "BSchweinsteiger",
      "indices" : [ 3, 19 ],
      "id_str" : "1283561876",
      "id" : 1283561876
    }, {
      "name" : "Premier League",
      "screen_name" : "premierleague",
      "indices" : [ 48, 62 ],
      "id_str" : "343627165",
      "id" : 343627165
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BSchweinsteiger\/status\/648155352895221760\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/S9SNhKEkCp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP612IKWoAEhmWY.jpg",
      "id_str" : "648155337896402945",
      "id" : 648155337896402945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP612IKWoAEhmWY.jpg",
      "sizes" : [ {
        "h" : 963,
        "resize" : "fit",
        "w" : 963
      }, {
        "h" : 963,
        "resize" : "fit",
        "w" : 963
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 963,
        "resize" : "fit",
        "w" : 963
      } ],
      "display_url" : "pic.twitter.com\/S9SNhKEkCp"
    } ],
    "hashtags" : [ {
      "text" : "mufc",
      "indices" : [ 21, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648263714068541441",
  "text" : "RT @BSchweinsteiger: #mufc number 1, top of the @premierleague http:\/\/t.co\/S9SNhKEkCp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Premier League",
        "screen_name" : "premierleague",
        "indices" : [ 27, 41 ],
        "id_str" : "343627165",
        "id" : 343627165
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BSchweinsteiger\/status\/648155352895221760\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/S9SNhKEkCp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CP612IKWoAEhmWY.jpg",
        "id_str" : "648155337896402945",
        "id" : 648155337896402945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP612IKWoAEhmWY.jpg",
        "sizes" : [ {
          "h" : 963,
          "resize" : "fit",
          "w" : 963
        }, {
          "h" : 963,
          "resize" : "fit",
          "w" : 963
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 963,
          "resize" : "fit",
          "w" : 963
        } ],
        "display_url" : "pic.twitter.com\/S9SNhKEkCp"
      } ],
      "hashtags" : [ {
        "text" : "mufc",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648155352895221760",
    "text" : "#mufc number 1, top of the @premierleague http:\/\/t.co\/S9SNhKEkCp",
    "id" : 648155352895221760,
    "created_at" : "2015-09-27 15:20:52 +0000",
    "user" : {
      "name" : "Basti Schweinsteiger",
      "screen_name" : "BSchweinsteiger",
      "protected" : false,
      "id_str" : "1283561876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852220762807312386\/TlJQZ7AR_normal.jpg",
      "id" : 1283561876,
      "verified" : true
    }
  },
  "id" : 648263714068541441,
  "created_at" : "2015-09-27 22:31:28 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 0, 14 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647527801533280256",
  "in_reply_to_user_id" : 351972911,
  "text" : "@EFDC_Explorer EFDC Explorer training in Edmonds from 2015-09-28 to 2015-10-02.",
  "id" : 647527801533280256,
  "created_at" : "2015-09-25 21:47:13 +0000",
  "in_reply_to_screen_name" : "EFDC_Explorer",
  "in_reply_to_user_id_str" : "351972911",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Footytube",
      "screen_name" : "footytube",
      "indices" : [ 73, 83 ],
      "id_str" : "22332200",
      "id" : 22332200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/G7zQomCs5d",
      "expanded_url" : "http:\/\/www.footytube.com\/video\/manchester-united-ipswich-town-sep23-372596",
      "display_url" : "footytube.com\/video\/manchest\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647127866035990529",
  "text" : "Manchester United v Ipswich Town - highlights http:\/\/t.co\/G7zQomCs5d via @footytube",
  "id" : 647127866035990529,
  "created_at" : "2015-09-24 19:18:00 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AnthonyMartial",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646789041598304256",
  "text" : "#AnthonyMartial 4 goals in four matches. What a player.",
  "id" : 646789041598304256,
  "created_at" : "2015-09-23 20:51:38 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BackOffIndia",
      "indices" : [ 16, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/mLnSaZdxf2",
      "expanded_url" : "https:\/\/twitter.com\/DeShobhaa\/status\/646548346820104192",
      "display_url" : "twitter.com\/DeShobhaa\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646735629158453248",
  "text" : "Back off India. #BackOffIndia  https:\/\/t.co\/mLnSaZdxf2",
  "id" : 646735629158453248,
  "created_at" : "2015-09-23 17:19:24 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646727963422035969",
  "text" : "Manchester United vs Ipswich Town at 12 PST today. Hope Red Devils will march to the victory.",
  "id" : 646727963422035969,
  "created_at" : "2015-09-23 16:48:56 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bhusan dahal",
      "screen_name" : "DahalTbd",
      "indices" : [ 3, 12 ],
      "id_str" : "1041367052",
      "id" : 1041367052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646550619600252928",
  "text" : "RT @DahalTbd: \u0915\u0938\u0948\u0915\u094B \u091A\u093F\u0924\u094D\u0924 \u092C\u0941\u091D\u094B\u0938 \u0928\u092C\u0941\u091D\u094B\u0938 \u0939\u093F\u0928\u094D\u0926\u0941\u0938\u094D\u0924\u093E\u0928\u0940 \u0926\u093E\u0926\u093E\u0917\u093F\u0930\u0940 \u0916\u093F\u0932\u093E\u092B \u0909\u092D\u093F\u0928\u094D\u0926\u093E \u091C\u093E\u0917\u093F\u0930 \u0935\u093E \u091C\u093F\u0935\u0928 \u0917\u0941\u092E\u093E\u090F\u0915\u093E\u0939\u0930\u0941 \u092F\u093F\u0928\u0948 \u0939\u0941\u0928\n\u0928\u0947\u092A\u093E\u0932\u0940 \u091A\u093F\u0924\u094D\u0924\u0932\u0947 \u0938\u094B\u091A\u094C\u0902 \u0924 http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DahalTbd\/status\/646515378177228800\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/eJQ3hfDCIH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPjiTqwUwAEVUj0.jpg",
        "id_str" : "646515374050033665",
        "id" : 646515374050033665,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPjiTqwUwAEVUj0.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/eJQ3hfDCIH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "646515378177228800",
    "text" : "\u0915\u0938\u0948\u0915\u094B \u091A\u093F\u0924\u094D\u0924 \u092C\u0941\u091D\u094B\u0938 \u0928\u092C\u0941\u091D\u094B\u0938 \u0939\u093F\u0928\u094D\u0926\u0941\u0938\u094D\u0924\u093E\u0928\u0940 \u0926\u093E\u0926\u093E\u0917\u093F\u0930\u0940 \u0916\u093F\u0932\u093E\u092B \u0909\u092D\u093F\u0928\u094D\u0926\u093E \u091C\u093E\u0917\u093F\u0930 \u0935\u093E \u091C\u093F\u0935\u0928 \u0917\u0941\u092E\u093E\u090F\u0915\u093E\u0939\u0930\u0941 \u092F\u093F\u0928\u0948 \u0939\u0941\u0928\n\u0928\u0947\u092A\u093E\u0932\u0940 \u091A\u093F\u0924\u094D\u0924\u0932\u0947 \u0938\u094B\u091A\u094C\u0902 \u0924 http:\/\/t.co\/eJQ3hfDCIH",
    "id" : 646515378177228800,
    "created_at" : "2015-09-23 02:44:12 +0000",
    "user" : {
      "name" : "bhusan dahal",
      "screen_name" : "DahalTbd",
      "protected" : false,
      "id_str" : "1041367052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915107231808417797\/o9wsgXLV_normal.jpg",
      "id" : 1041367052,
      "verified" : false
    }
  },
  "id" : 646550619600252928,
  "created_at" : "2015-09-23 05:04:14 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bhusan dahal",
      "screen_name" : "DahalTbd",
      "indices" : [ 3, 12 ],
      "id_str" : "1041367052",
      "id" : 1041367052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646550589938118656",
  "text" : "RT @DahalTbd: \u0926\u0947\u0936\u0915\u094B \u0938\u0902\u0915\u091F\u0939\u0930\u0923 \u0917\u0930\u094D\u0928 \u0905\u093E\u092A\u0941\u0930\u094D\u0924\u093F \u092E\u0902\u0924\u094D\u0930\u093F \u092F\u0941\u0930\u094B\u092A \n\u0938\u0902\u091A\u093E\u0930 \u0915\u0924\u093E\u0930 \u0930 \n\u092A\u094D\u0930\u092E \u0905\u092E\u0947\u0930\u093F\u0915\u093E \n\u092D\u093E\u0901\u0921\u092E\u0947 \u091C\u093E\u090F \u0939\u093F\u0928\u094D\u0926\u0941\u0938\u094D\u0924\u093E\u0928\u093F \u0926\u093E\u0926\u093E\u0917\u093F\u0930\u0940 \n\u0915\u094D\u092F\u093E \u092E\u0941\u0932\u0941\u0915 \u091B \u0939\u093E\u092E\u094D\u0930\u094B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "646503567902113792",
    "text" : "\u0926\u0947\u0936\u0915\u094B \u0938\u0902\u0915\u091F\u0939\u0930\u0923 \u0917\u0930\u094D\u0928 \u0905\u093E\u092A\u0941\u0930\u094D\u0924\u093F \u092E\u0902\u0924\u094D\u0930\u093F \u092F\u0941\u0930\u094B\u092A \n\u0938\u0902\u091A\u093E\u0930 \u0915\u0924\u093E\u0930 \u0930 \n\u092A\u094D\u0930\u092E \u0905\u092E\u0947\u0930\u093F\u0915\u093E \n\u092D\u093E\u0901\u0921\u092E\u0947 \u091C\u093E\u090F \u0939\u093F\u0928\u094D\u0926\u0941\u0938\u094D\u0924\u093E\u0928\u093F \u0926\u093E\u0926\u093E\u0917\u093F\u0930\u0940 \n\u0915\u094D\u092F\u093E \u092E\u0941\u0932\u0941\u0915 \u091B \u0939\u093E\u092E\u094D\u0930\u094B",
    "id" : 646503567902113792,
    "created_at" : "2015-09-23 01:57:16 +0000",
    "user" : {
      "name" : "bhusan dahal",
      "screen_name" : "DahalTbd",
      "protected" : false,
      "id_str" : "1041367052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915107231808417797\/o9wsgXLV_normal.jpg",
      "id" : 1041367052,
      "verified" : false
    }
  },
  "id" : 646550589938118656,
  "created_at" : "2015-09-23 05:04:07 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Amexoffers",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646415028581715968",
  "text" : "#Amexoffers",
  "id" : 646415028581715968,
  "created_at" : "2015-09-22 20:05:27 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646411382351523840",
  "text" : "5 goals by Lewandowski in 9 minutes. What an achievement.",
  "id" : 646411382351523840,
  "created_at" : "2015-09-22 19:50:57 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nepali Times",
      "screen_name" : "nepalitimes",
      "indices" : [ 3, 15 ],
      "id_str" : "74679662",
      "id" : 74679662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nepal",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/jVz40SwAzt",
      "expanded_url" : "http:\/\/bit.ly\/1iZHl5m",
      "display_url" : "bit.ly\/1iZHl5m"
    } ]
  },
  "geo" : { },
  "id_str" : "646410888459587585",
  "text" : "RT @nepalitimes: \"New constitution has institutionalised #Nepal as a federal democratic republic\" http:\/\/t.co\/jVz40SwAzt http:\/\/t.co\/iBLsA7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nepalitimes\/status\/645574894504165376\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/iBLsA7jorA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPWKqtvUwAAkgsM.jpg",
        "id_str" : "645574588034760704",
        "id" : 645574588034760704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPWKqtvUwAAkgsM.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/iBLsA7jorA"
      } ],
      "hashtags" : [ {
        "text" : "Nepal",
        "indices" : [ 40, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/jVz40SwAzt",
        "expanded_url" : "http:\/\/bit.ly\/1iZHl5m",
        "display_url" : "bit.ly\/1iZHl5m"
      } ]
    },
    "geo" : { },
    "id_str" : "645574894504165376",
    "text" : "\"New constitution has institutionalised #Nepal as a federal democratic republic\" http:\/\/t.co\/jVz40SwAzt http:\/\/t.co\/iBLsA7jorA",
    "id" : 645574894504165376,
    "created_at" : "2015-09-20 12:27:03 +0000",
    "user" : {
      "name" : "Nepali Times",
      "screen_name" : "nepalitimes",
      "protected" : false,
      "id_str" : "74679662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472617556730081280\/hfjo3guT_normal.jpeg",
      "id" : 74679662,
      "verified" : true
    }
  },
  "id" : 646410888459587585,
  "created_at" : "2015-09-22 19:49:00 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]