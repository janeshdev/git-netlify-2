Grailbird.data.tweets_2017_12 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/eQ76qtRWDZ",
      "expanded_url" : "https:\/\/twitter.com\/Ronald_vanLoon\/status\/936627338967646208",
      "display_url" : "twitter.com\/Ronald_vanLoon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "936632740400656385",
  "text" : "R and python cheat sheets https:\/\/t.co\/eQ76qtRWDZ",
  "id" : 936632740400656385,
  "created_at" : "2017-12-01 16:27:01 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/nXB9mPkaQI",
      "expanded_url" : "https:\/\/twitter.com\/EFFCharity\/status\/936630028959404033",
      "display_url" : "twitter.com\/EFFCharity\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "936632288200204288",
  "text" : "The world cup draw is out https:\/\/t.co\/nXB9mPkaQI",
  "id" : 936632288200204288,
  "created_at" : "2017-12-01 16:25:13 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coursera",
      "screen_name" : "coursera",
      "indices" : [ 46, 55 ],
      "id_str" : "352053266",
      "id" : 352053266
    }, {
      "name" : "Andrew Ng",
      "screen_name" : "AndrewYNg",
      "indices" : [ 74, 84 ],
      "id_str" : "216939636",
      "id" : 216939636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "936485990985641984",
  "text" : "Completed second course on deep learning from @coursera Thank you so much @AndrewYNg  for putting so great courses. Getting ready to dive into third course.",
  "id" : 936485990985641984,
  "created_at" : "2017-12-01 06:43:53 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yihui Xie",
      "screen_name" : "xieyihui",
      "indices" : [ 33, 42 ],
      "id_str" : "39010299",
      "id" : 39010299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "xaringan",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "936303805968261120",
  "text" : "#xaringan Really nice package by @xieyihui while is built on top of remark.js . Much better than other presentation frameworks I used in R.",
  "id" : 936303805968261120,
  "created_at" : "2017-11-30 18:39:57 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Monn",
      "screen_name" : "dqmonn",
      "indices" : [ 45, 52 ],
      "id_str" : "3097332387",
      "id" : 3097332387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/fafdObUvz8",
      "expanded_url" : "https:\/\/towardsdatascience.com\/pytorch-vs-tensorflow-1-month-summary-35d138590f9",
      "display_url" : "towardsdatascience.com\/pytorch-vs-ten\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "936303423716073473",
  "text" : "\u201CPyTorch vs. TensorFlow: 1 month summary\u201D by @dqmonn https:\/\/t.co\/fafdObUvz8",
  "id" : 936303423716073473,
  "created_at" : "2017-11-30 18:38:26 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]