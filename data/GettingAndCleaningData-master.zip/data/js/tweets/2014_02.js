Grailbird.data.tweets_2014_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432544304997744640",
  "text" : "Hope to see a good game today.",
  "id" : 432544304997744640,
  "created_at" : "2014-02-09 15:59:33 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hillier",
      "screen_name" : "Chri5_Hillier",
      "indices" : [ 3, 17 ],
      "id_str" : "986379037",
      "id" : 986379037
    }, {
      "name" : "Bloodzeed",
      "screen_name" : "Bloodzeed",
      "indices" : [ 19, 29 ],
      "id_str" : "375536678",
      "id" : 375536678
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Chri5_Hillier\/status\/432154264455352322\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/BDO2vKTD6v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf9SA4IIUAACjQz.jpg",
      "id_str" : "432154264270819328",
      "id" : 432154264270819328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf9SA4IIUAACjQz.jpg",
      "sizes" : [ {
        "h" : 296,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/BDO2vKTD6v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432165552904503296",
  "text" : "RT @Chri5_Hillier: @Bloodzeed http:\/\/t.co\/BDO2vKTD6v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bloodzeed",
        "screen_name" : "Bloodzeed",
        "indices" : [ 0, 10 ],
        "id_str" : "375536678",
        "id" : 375536678
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Chri5_Hillier\/status\/432154264455352322\/photo\/1",
        "indices" : [ 11, 33 ],
        "url" : "http:\/\/t.co\/BDO2vKTD6v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf9SA4IIUAACjQz.jpg",
        "id_str" : "432154264270819328",
        "id" : 432154264270819328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf9SA4IIUAACjQz.jpg",
        "sizes" : [ {
          "h" : 296,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/BDO2vKTD6v"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "432154264455352322",
    "in_reply_to_user_id" : 375536678,
    "text" : "@Bloodzeed http:\/\/t.co\/BDO2vKTD6v",
    "id" : 432154264455352322,
    "created_at" : "2014-02-08 14:09:40 +0000",
    "in_reply_to_screen_name" : "Bloodzeed",
    "in_reply_to_user_id_str" : "375536678",
    "user" : {
      "name" : "Chris Hillier",
      "screen_name" : "Chri5_Hillier",
      "protected" : false,
      "id_str" : "986379037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000379306930\/70c3d26169c3211f727bf134a9b1342a_normal.jpeg",
      "id" : 986379037,
      "verified" : false
    }
  },
  "id" : 432165552904503296,
  "created_at" : "2014-02-08 14:54:31 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432147546438242305",
  "text" : "What an awesome performance by Liverpool.",
  "id" : 432147546438242305,
  "created_at" : "2014-02-08 13:42:58 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]