Grailbird.data.tweets_2017_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mason Cross",
      "screen_name" : "MasonCrossBooks",
      "indices" : [ 3, 19 ],
      "id_str" : "1381485247",
      "id" : 1381485247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "868192268791889920",
  "text" : "RT @MasonCrossBooks: My daughter actually submitted this feedback at school. Not sure if I should ground her or buy her ice cream... https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MasonCrossBooks\/status\/867687194718351360\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/4v8Gjb9riv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DAqk5PhW0AArZvS.jpg",
        "id_str" : "867687181548179456",
        "id" : 867687181548179456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAqk5PhW0AArZvS.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 674
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 674
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 674
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 674
        } ],
        "display_url" : "pic.twitter.com\/4v8Gjb9riv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "867687194718351360",
    "text" : "My daughter actually submitted this feedback at school. Not sure if I should ground her or buy her ice cream... https:\/\/t.co\/4v8Gjb9riv",
    "id" : 867687194718351360,
    "created_at" : "2017-05-25 10:22:02 +0000",
    "user" : {
      "name" : "Mason Cross",
      "screen_name" : "MasonCrossBooks",
      "protected" : false,
      "id_str" : "1381485247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856450542528319489\/1eFCnSSh_normal.jpg",
      "id" : 1381485247,
      "verified" : true
    }
  },
  "id" : 868192268791889920,
  "created_at" : "2017-05-26 19:49:01 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]