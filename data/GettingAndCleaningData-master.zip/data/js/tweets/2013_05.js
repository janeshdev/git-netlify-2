Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/www.copy.com\/\" rel=\"nofollow\"\u003ECopy.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "copyapp",
      "screen_name" : "copyapp",
      "indices" : [ 21, 29 ],
      "id_str" : "2484747530",
      "id" : 2484747530
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetFor2GBMore",
      "indices" : [ 65, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/6WTO4oSHiJ",
      "expanded_url" : "http:\/\/copy.com\/?s=twitter.usr.tour",
      "display_url" : "copy.com\/?s=twitter.usr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "336937925809938432",
  "text" : "I just signed up for @CopyApp and got 15 GB free online storage! #tweetFor2GBMore\nhttp:\/\/t.co\/6WTO4oSHiJ",
  "id" : 336937925809938432,
  "created_at" : "2013-05-21 20:13:56 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]