Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujan Baral",
      "screen_name" : "baralsujan",
      "indices" : [ 0, 11 ],
      "id_str" : "18218149",
      "id" : 18218149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224179378731487232",
  "geo" : { },
  "id_str" : "224357064821047296",
  "in_reply_to_user_id" : 18218149,
  "text" : "@baralsujan sahi cha la photo",
  "id" : 224357064821047296,
  "in_reply_to_status_id" : 224179378731487232,
  "created_at" : "2012-07-15 04:17:47 +0000",
  "in_reply_to_screen_name" : "baralsujan",
  "in_reply_to_user_id_str" : "18218149",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224356944088018945",
  "text" : "Very tired. But no time for break.",
  "id" : 224356944088018945,
  "created_at" : "2012-07-15 04:17:18 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]