Grailbird.data.tweets_2017_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rajan Devkota",
      "screen_name" : "rajandevkota",
      "indices" : [ 0, 13 ],
      "id_str" : "69660252",
      "id" : 69660252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910253473626820609",
  "geo" : { },
  "id_str" : "913252966475358208",
  "in_reply_to_user_id" : 69660252,
  "text" : "@rajandevkota That's awesome to know where your blood went",
  "id" : 913252966475358208,
  "in_reply_to_status_id" : 910253473626820609,
  "created_at" : "2017-09-28 04:04:09 +0000",
  "in_reply_to_screen_name" : "rajandevkota",
  "in_reply_to_user_id_str" : "69660252",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "911733029696978944",
  "text" : "RT @paulocoelho: I have a lot of friends that are very poor: the only thing they have is money",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "911568341059489792",
    "text" : "I have a lot of friends that are very poor: the only thing they have is money",
    "id" : 911568341059489792,
    "created_at" : "2017-09-23 12:30:03 +0000",
    "user" : {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "protected" : false,
      "id_str" : "5520952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791423363797377024\/svEXr6X8_normal.jpg",
      "id" : 5520952,
      "verified" : true
    }
  },
  "id" : 911733029696978944,
  "created_at" : "2017-09-23 23:24:28 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bhusan dahal",
      "screen_name" : "DahalTbd",
      "indices" : [ 3, 12 ],
      "id_str" : "1041367052",
      "id" : 1041367052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "911057031187931136",
  "text" : "RT @DahalTbd: \"\u0935\u093F\u0926\u094D\u092F\u093E \u0928\u0937\u094D\u091F, \u0938\u0941\u0928\u094D\u0926\u0930\" \u091B \u0915\u093E\u0920\u092E\u093E\u0921\u094C \n\u092F\u094B \u092B\u094B\u0939\u0930 \n\u0915\u093E\u092E \u0917\u0930\u094D\u0928 \u0928\u0938\u0915\u094D\u0928\u0947 \u0926\u093F\u092E\u093E\u0917\u0915\u094B \u092A\u094D\u0930\u0924\u093F\u092E\u0941\u0930\u094D\u0924\u093F  \u0939\u094B, \n\u092B\u094B\u0939\u094B\u0930 \u092E\u093F\u0932\u094D\u0915\u093E\u0909\u0928 \u0938\u0915\u093F\u0928\u094D\u091B, \n\u0930 \u0924\u094D\u092F\u0938\u094D\u0924\u093E \u0926\u093F\u092E\u093E\u0917\u0939\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/gNWiLtKUr0",
        "expanded_url" : "https:\/\/twitter.com\/s_mahat\/status\/910838530154176513",
        "display_url" : "twitter.com\/s_mahat\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "911034065347735554",
    "text" : "\"\u0935\u093F\u0926\u094D\u092F\u093E \u0928\u0937\u094D\u091F, \u0938\u0941\u0928\u094D\u0926\u0930\" \u091B \u0915\u093E\u0920\u092E\u093E\u0921\u094C \n\u092F\u094B \u092B\u094B\u0939\u0930 \n\u0915\u093E\u092E \u0917\u0930\u094D\u0928 \u0928\u0938\u0915\u094D\u0928\u0947 \u0926\u093F\u092E\u093E\u0917\u0915\u094B \u092A\u094D\u0930\u0924\u093F\u092E\u0941\u0930\u094D\u0924\u093F  \u0939\u094B, \n\u092B\u094B\u0939\u094B\u0930 \u092E\u093F\u0932\u094D\u0915\u093E\u0909\u0928 \u0938\u0915\u093F\u0928\u094D\u091B, \n\u0930 \u0924\u094D\u092F\u0938\u094D\u0924\u093E \u0926\u093F\u092E\u093E\u0917\u0939\u0930\u0941\u0932\u093E\u0908 \u092A\u0928\u093F, \u0938\u094B\u091A\u094C\u0902 https:\/\/t.co\/gNWiLtKUr0",
    "id" : 911034065347735554,
    "created_at" : "2017-09-22 01:07:02 +0000",
    "user" : {
      "name" : "bhusan dahal",
      "screen_name" : "DahalTbd",
      "protected" : false,
      "id_str" : "1041367052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915107231808417797\/o9wsgXLV_normal.jpg",
      "id" : 1041367052,
      "verified" : false
    }
  },
  "id" : 911057031187931136,
  "created_at" : "2017-09-22 02:38:17 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USGS R Community",
      "screen_name" : "USGS_R",
      "indices" : [ 0, 7 ],
      "id_str" : "3313531039",
      "id" : 3313531039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908684335032750080",
  "geo" : { },
  "id_str" : "910196262950989824",
  "in_reply_to_user_id" : 3313531039,
  "text" : "@USGS_R Fantastic",
  "id" : 910196262950989824,
  "in_reply_to_status_id" : 908684335032750080,
  "created_at" : "2017-09-19 17:37:54 +0000",
  "in_reply_to_screen_name" : "USGS_R",
  "in_reply_to_user_id_str" : "3313531039",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USGS R Community",
      "screen_name" : "USGS_R",
      "indices" : [ 3, 10 ],
      "id_str" : "3313531039",
      "id" : 3313531039
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 20, 27 ]
    }, {
      "text" : "dataviz",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "flooding",
      "indices" : [ 49, 58 ]
    }, {
      "text" : "HurricaneIrma",
      "indices" : [ 64, 78 ]
    }, {
      "text" : "opensource",
      "indices" : [ 81, 92 ]
    }, {
      "text" : "openscience",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/rpocPQe7zR",
      "expanded_url" : "http:\/\/github.com\/USGS-VIZLAB\/hurricane-irma",
      "display_url" : "github.com\/USGS-VIZLAB\/hu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "910196239764828161",
  "text" : "RT @USGS_R: Another #rstats #dataviz! Precip and #flooding from #HurricaneIrma \uD83D\uDCA7 #opensource code: https:\/\/t.co\/rpocPQe7zR #openscience htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USGS_R\/status\/908684335032750080\/photo\/1",
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/rGX1SNiYEM",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DJtoo3lWsAAXUQ0.jpg",
        "id_str" : "908434801169969152",
        "id" : 908434801169969152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DJtoo3lWsAAXUQ0.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/rGX1SNiYEM"
      } ],
      "hashtags" : [ {
        "text" : "rstats",
        "indices" : [ 8, 15 ]
      }, {
        "text" : "dataviz",
        "indices" : [ 16, 24 ]
      }, {
        "text" : "flooding",
        "indices" : [ 37, 46 ]
      }, {
        "text" : "HurricaneIrma",
        "indices" : [ 52, 66 ]
      }, {
        "text" : "opensource",
        "indices" : [ 69, 80 ]
      }, {
        "text" : "openscience",
        "indices" : [ 111, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/rpocPQe7zR",
        "expanded_url" : "http:\/\/github.com\/USGS-VIZLAB\/hurricane-irma",
        "display_url" : "github.com\/USGS-VIZLAB\/hu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "908684335032750080",
    "text" : "Another #rstats #dataviz! Precip and #flooding from #HurricaneIrma \uD83D\uDCA7 #opensource code: https:\/\/t.co\/rpocPQe7zR #openscience https:\/\/t.co\/rGX1SNiYEM",
    "id" : 908684335032750080,
    "created_at" : "2017-09-15 13:30:02 +0000",
    "user" : {
      "name" : "USGS R Community",
      "screen_name" : "USGS_R",
      "protected" : false,
      "id_str" : "3313531039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631488083863584769\/gDqhLdAL_normal.png",
      "id" : 3313531039,
      "verified" : false
    }
  },
  "id" : 910196239764828161,
  "created_at" : "2017-09-19 17:37:48 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "909136029835173888",
  "text" : "RT @paulocoelho: Happy week and remember:\nYou never lose by loving. You always lose by holding back",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "909128646010564609",
    "text" : "Happy week and remember:\nYou never lose by loving. You always lose by holding back",
    "id" : 909128646010564609,
    "created_at" : "2017-09-16 18:55:34 +0000",
    "user" : {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "protected" : false,
      "id_str" : "5520952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791423363797377024\/svEXr6X8_normal.jpg",
      "id" : 5520952,
      "verified" : true
    }
  },
  "id" : 909136029835173888,
  "created_at" : "2017-09-16 19:24:55 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NRDC \uD83C\uDF0E",
      "screen_name" : "NRDC",
      "indices" : [ 3, 8 ],
      "id_str" : "18713552",
      "id" : 18713552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/V0HPfo41K7",
      "expanded_url" : "http:\/\/on.nrdc.org\/2f9gqV2",
      "display_url" : "on.nrdc.org\/2f9gqV2"
    } ]
  },
  "geo" : { },
  "id_str" : "908173017515270146",
  "text" : "RT @NRDC: France announced its decision to get rid of oil &amp; gas production by 2040! France, we applaud you. \uD83D\uDC4F\uD83D\uDC4F https:\/\/t.co\/V0HPfo41K7 via\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Futurism",
        "screen_name" : "futurism",
        "indices" : [ 133, 142 ],
        "id_str" : "2557446343",
        "id" : 2557446343
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/V0HPfo41K7",
        "expanded_url" : "http:\/\/on.nrdc.org\/2f9gqV2",
        "display_url" : "on.nrdc.org\/2f9gqV2"
      } ]
    },
    "geo" : { },
    "id_str" : "908163405948866560",
    "text" : "France announced its decision to get rid of oil &amp; gas production by 2040! France, we applaud you. \uD83D\uDC4F\uD83D\uDC4F https:\/\/t.co\/V0HPfo41K7 via @futurism",
    "id" : 908163405948866560,
    "created_at" : "2017-09-14 03:00:03 +0000",
    "user" : {
      "name" : "NRDC \uD83C\uDF0E",
      "screen_name" : "NRDC",
      "protected" : false,
      "id_str" : "18713552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817502654725296129\/gL3moZlE_normal.jpg",
      "id" : 18713552,
      "verified" : true
    }
  },
  "id" : 908173017515270146,
  "created_at" : "2017-09-14 03:38:15 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RStudio",
      "screen_name" : "rstudio",
      "indices" : [ 3, 11 ],
      "id_str" : "235261861",
      "id" : 235261861
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/mDna7C2huo",
      "expanded_url" : "https:\/\/blog.rstudio.com\/2017\/09\/13\/rstudio-v1.1---the-little-things",
      "display_url" : "blog.rstudio.com\/2017\/09\/13\/rst\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908157956583280641",
  "text" : "RT @rstudio: RStudio v1.1 Preview - The Little Things: https:\/\/t.co\/mDna7C2huo #rstats",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rstats",
        "indices" : [ 66, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/mDna7C2huo",
        "expanded_url" : "https:\/\/blog.rstudio.com\/2017\/09\/13\/rstudio-v1.1---the-little-things",
        "display_url" : "blog.rstudio.com\/2017\/09\/13\/rst\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "908015008923226112",
    "text" : "RStudio v1.1 Preview - The Little Things: https:\/\/t.co\/mDna7C2huo #rstats",
    "id" : 908015008923226112,
    "created_at" : "2017-09-13 17:10:22 +0000",
    "user" : {
      "name" : "RStudio",
      "screen_name" : "rstudio",
      "protected" : false,
      "id_str" : "235261861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487277095681150976\/aEp2vlJy_normal.png",
      "id" : 235261861,
      "verified" : false
    }
  },
  "id" : 908157956583280641,
  "created_at" : "2017-09-14 02:38:24 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger D. Peng",
      "screen_name" : "rdpeng",
      "indices" : [ 0, 7 ],
      "id_str" : "9308212",
      "id" : 9308212
    }, {
      "name" : "Yihui Xie",
      "screen_name" : "xieyihui",
      "indices" : [ 8, 17 ],
      "id_str" : "39010299",
      "id" : 39010299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "907378217069174784",
  "geo" : { },
  "id_str" : "907400428853350406",
  "in_reply_to_user_id" : 9308212,
  "text" : "@rdpeng @xieyihui This is a very nice package. I have been using it for several months",
  "id" : 907400428853350406,
  "in_reply_to_status_id" : 907378217069174784,
  "created_at" : "2017-09-12 00:28:15 +0000",
  "in_reply_to_screen_name" : "rdpeng",
  "in_reply_to_user_id_str" : "9308212",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Guo",
      "screen_name" : "pgbovine",
      "indices" : [ 3, 12 ],
      "id_str" : "17773446",
      "id" : 17773446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/96H2QdmbGK",
      "expanded_url" : "https:\/\/twitter.com\/poniewozik\/status\/907266834877034498",
      "display_url" : "twitter.com\/poniewozik\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "907398491080679425",
  "text" : "RT @pgbovine: This is similar in many fields ... https:\/\/t.co\/96H2QdmbGK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/96H2QdmbGK",
        "expanded_url" : "https:\/\/twitter.com\/poniewozik\/status\/907266834877034498",
        "display_url" : "twitter.com\/poniewozik\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "907317068172746752",
    "text" : "This is similar in many fields ... https:\/\/t.co\/96H2QdmbGK",
    "id" : 907317068172746752,
    "created_at" : "2017-09-11 18:57:00 +0000",
    "user" : {
      "name" : "Philip Guo",
      "screen_name" : "pgbovine",
      "protected" : false,
      "id_str" : "17773446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661230489357967360\/HB3vsn3O_normal.jpg",
      "id" : 17773446,
      "verified" : true
    }
  },
  "id" : 907398491080679425,
  "created_at" : "2017-09-12 00:20:33 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rajan Devkota",
      "screen_name" : "rajandevkota",
      "indices" : [ 0, 13 ],
      "id_str" : "69660252",
      "id" : 69660252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "907386757720809477",
  "geo" : { },
  "id_str" : "907398225090490368",
  "in_reply_to_user_id" : 69660252,
  "text" : "@rajandevkota Aba hernu parcha jasto Cha",
  "id" : 907398225090490368,
  "in_reply_to_status_id" : 907386757720809477,
  "created_at" : "2017-09-12 00:19:30 +0000",
  "in_reply_to_screen_name" : "rajandevkota",
  "in_reply_to_user_id_str" : "69660252",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Gauld",
      "screen_name" : "tomgauld",
      "indices" : [ 3, 12 ],
      "id_str" : "46090073",
      "id" : 46090073
    }, {
      "name" : "Guardian Review",
      "screen_name" : "guardianreview",
      "indices" : [ 77, 92 ],
      "id_str" : "52854513",
      "id" : 52854513
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tomgauld\/status\/907176391959080960\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Kr9dGbobrg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DJbQNUcW0AA5hcb.jpg",
      "id_str" : "907141302206255104",
      "id" : 907141302206255104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJbQNUcW0AA5hcb.jpg",
      "sizes" : [ {
        "h" : 508,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/Kr9dGbobrg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "907369720453754880",
  "text" : "RT @tomgauld: \u2018Useful abbreviations for the time-pressed online reader\u2019 (for @guardianreview) https:\/\/t.co\/Kr9dGbobrg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Guardian Review",
        "screen_name" : "guardianreview",
        "indices" : [ 63, 78 ],
        "id_str" : "52854513",
        "id" : 52854513
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tomgauld\/status\/907176391959080960\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/Kr9dGbobrg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DJbQNUcW0AA5hcb.jpg",
        "id_str" : "907141302206255104",
        "id" : 907141302206255104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJbQNUcW0AA5hcb.jpg",
        "sizes" : [ {
          "h" : 508,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 508,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 508,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/Kr9dGbobrg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "907176391959080960",
    "text" : "\u2018Useful abbreviations for the time-pressed online reader\u2019 (for @guardianreview) https:\/\/t.co\/Kr9dGbobrg",
    "id" : 907176391959080960,
    "created_at" : "2017-09-11 09:38:01 +0000",
    "user" : {
      "name" : "Tom Gauld",
      "screen_name" : "tomgauld",
      "protected" : false,
      "id_str" : "46090073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882181291952787456\/I6gs4h3R_normal.jpg",
      "id" : 46090073,
      "verified" : false
    }
  },
  "id" : 907369720453754880,
  "created_at" : "2017-09-11 22:26:14 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Irma",
      "indices" : [ 85, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "907365063962619904",
  "text" : "RT @fema: You should only return home when local officials say it's ok. Keep in mind #Irma may have ongoing impacts &amp; disruptions to daily\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fema\/status\/907245481469849600\/photo\/1",
        "indices" : [ 145, 168 ],
        "url" : "https:\/\/t.co\/g0ggmwbqF4",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DJcuj4bW0AE9e1H.jpg",
        "id_str" : "907245043915870209",
        "id" : 907245043915870209,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DJcuj4bW0AE9e1H.jpg",
        "sizes" : [ {
          "h" : 579,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 850
        } ],
        "display_url" : "pic.twitter.com\/g0ggmwbqF4"
      } ],
      "hashtags" : [ {
        "text" : "Irma",
        "indices" : [ 75, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "907245481469849600",
    "text" : "You should only return home when local officials say it's ok. Keep in mind #Irma may have ongoing impacts &amp; disruptions to daily activities. https:\/\/t.co\/g0ggmwbqF4",
    "id" : 907245481469849600,
    "created_at" : "2017-09-11 14:12:33 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875380682637234176\/Fw_Rx4T-_normal.jpg",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 907365063962619904,
  "created_at" : "2017-09-11 22:07:43 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "907270013769453569",
  "text" : "Flying to NYC",
  "id" : 907270013769453569,
  "created_at" : "2017-09-11 15:50:02 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rick Knabb",
      "screen_name" : "DrRickKnabb",
      "indices" : [ 3, 15 ],
      "id_str" : "20031296",
      "id" : 20031296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "907068373862801408",
  "text" : "RT @DrRickKnabb: Continue to stay away from Gulf, bays, all salt water bodies along Florida Gulf coast. Water coming in quickly after cente\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Irma",
        "indices" : [ 127, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "907041332480430080",
    "text" : "Continue to stay away from Gulf, bays, all salt water bodies along Florida Gulf coast. Water coming in quickly after center of #Irma passes.",
    "id" : 907041332480430080,
    "created_at" : "2017-09-11 00:41:20 +0000",
    "user" : {
      "name" : "Dr. Rick Knabb",
      "screen_name" : "DrRickKnabb",
      "protected" : false,
      "id_str" : "20031296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/867871308515876864\/8YhcVnX2_normal.jpg",
      "id" : 20031296,
      "verified" : true
    }
  },
  "id" : 907068373862801408,
  "created_at" : "2017-09-11 02:28:47 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manutdvsstoke",
      "indices" : [ 16, 30 ]
    }, {
      "text" : "ManUtd",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "906587655437131776",
  "text" : "Not good enough #manutdvsstoke #ManUtd",
  "id" : 906587655437131776,
  "created_at" : "2017-09-09 18:38:35 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammy Duckworth",
      "screen_name" : "SenDuckworth",
      "indices" : [ 3, 16 ],
      "id_str" : "1058520120",
      "id" : 1058520120
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SenDuckworth\/status\/905918332490174464\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/slTWGx6sMD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DJJ3fbSXoAAa2E8.jpg",
      "id_str" : "905917856839344128",
      "id" : 905917856839344128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJJ3fbSXoAAa2E8.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2400,
        "resize" : "fit",
        "w" : 1800
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/slTWGx6sMD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "906565798654754817",
  "text" : "RT @SenDuckworth: Just broke my leg rowing \u2014 I blame my hardcore pace. Luckily, it no longer hurts to break a leg! https:\/\/t.co\/slTWGx6sMD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenDuckworth\/status\/905918332490174464\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/slTWGx6sMD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DJJ3fbSXoAAa2E8.jpg",
        "id_str" : "905917856839344128",
        "id" : 905917856839344128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJJ3fbSXoAAa2E8.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2400,
          "resize" : "fit",
          "w" : 1800
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/slTWGx6sMD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "905918332490174464",
    "text" : "Just broke my leg rowing \u2014 I blame my hardcore pace. Luckily, it no longer hurts to break a leg! https:\/\/t.co\/slTWGx6sMD",
    "id" : 905918332490174464,
    "created_at" : "2017-09-07 22:18:56 +0000",
    "user" : {
      "name" : "Tammy Duckworth",
      "screen_name" : "SenDuckworth",
      "protected" : false,
      "id_str" : "1058520120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/928404187750326272\/G7KDvNwC_normal.jpg",
      "id" : 1058520120,
      "verified" : true
    }
  },
  "id" : 906565798654754817,
  "created_at" : "2017-09-09 17:11:44 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tshakya",
      "screen_name" : "Lhatseri",
      "indices" : [ 3, 12 ],
      "id_str" : "16588298",
      "id" : 16588298
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Lhatseri\/status\/906175294649753600\/video\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/lKISKIbvAZ",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/906175135174025216\/pu\/img\/H3MP76Q8UZ3XxNbR.jpg",
      "id_str" : "906175135174025216",
      "id" : 906175135174025216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/906175135174025216\/pu\/img\/H3MP76Q8UZ3XxNbR.jpg",
      "sizes" : [ {
        "h" : 230,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/lKISKIbvAZ"
    } ],
    "hashtags" : [ {
      "text" : "Tibet",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "906565608761724928",
  "text" : "RT @Lhatseri: This video is circulating on Wechat &amp; Weibo, melting permafrost, flowing like lava in #Tibet. https:\/\/t.co\/lKISKIbvAZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lhatseri\/status\/906175294649753600\/video\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/lKISKIbvAZ",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/906175135174025216\/pu\/img\/H3MP76Q8UZ3XxNbR.jpg",
        "id_str" : "906175135174025216",
        "id" : 906175135174025216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/906175135174025216\/pu\/img\/H3MP76Q8UZ3XxNbR.jpg",
        "sizes" : [ {
          "h" : 230,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/lKISKIbvAZ"
      } ],
      "hashtags" : [ {
        "text" : "Tibet",
        "indices" : [ 90, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "906175294649753600",
    "text" : "This video is circulating on Wechat &amp; Weibo, melting permafrost, flowing like lava in #Tibet. https:\/\/t.co\/lKISKIbvAZ",
    "id" : 906175294649753600,
    "created_at" : "2017-09-08 15:20:00 +0000",
    "user" : {
      "name" : "tshakya",
      "screen_name" : "Lhatseri",
      "protected" : false,
      "id_str" : "16588298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554366269231607808\/5uCqx-JK_normal.png",
      "id" : 16588298,
      "verified" : false
    }
  },
  "id" : 906565608761724928,
  "created_at" : "2017-09-09 17:10:58 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ASHLEY  STAHL",
      "screen_name" : "AshleyStahl",
      "indices" : [ 21, 33 ],
      "id_str" : "519439629",
      "id" : 519439629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "905976935041220608",
  "text" : "Joining career coach @ASHLEYSTAHL on her free training to learn resume tips",
  "id" : 905976935041220608,
  "created_at" : "2017-09-08 02:11:48 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carlos Scheidegger",
      "screen_name" : "scheidegger",
      "indices" : [ 0, 12 ],
      "id_str" : "44195788",
      "id" : 44195788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "905597010719383552",
  "geo" : { },
  "id_str" : "905844078570496001",
  "in_reply_to_user_id" : 44195788,
  "text" : "@scheidegger Just tried in on desktop. Works. This is amazing.",
  "id" : 905844078570496001,
  "in_reply_to_status_id" : 905597010719383552,
  "created_at" : "2017-09-07 17:23:52 +0000",
  "in_reply_to_screen_name" : "scheidegger",
  "in_reply_to_user_id_str" : "44195788",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carlos Scheidegger",
      "screen_name" : "scheidegger",
      "indices" : [ 3, 15 ],
      "id_str" : "44195788",
      "id" : 44195788
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scheidegger\/status\/905597010719383552\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/aZzqVbUhF6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DJFTrQbUQAARxNw.jpg",
      "id_str" : "905597002687201280",
      "id" : 905597002687201280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJFTrQbUQAARxNw.jpg",
      "sizes" : [ {
        "h" : 574,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/aZzqVbUhF6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "905843318982033409",
  "text" : "RT @scheidegger: oh my god I can now talk math on facebook messenger. this changes everythingggggggg https:\/\/t.co\/aZzqVbUhF6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scheidegger\/status\/905597010719383552\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/aZzqVbUhF6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DJFTrQbUQAARxNw.jpg",
        "id_str" : "905597002687201280",
        "id" : 905597002687201280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJFTrQbUQAARxNw.jpg",
        "sizes" : [ {
          "h" : 574,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 574,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 574,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/aZzqVbUhF6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "905597010719383552",
    "text" : "oh my god I can now talk math on facebook messenger. this changes everythingggggggg https:\/\/t.co\/aZzqVbUhF6",
    "id" : 905597010719383552,
    "created_at" : "2017-09-07 01:02:07 +0000",
    "user" : {
      "name" : "Carlos Scheidegger",
      "screen_name" : "scheidegger",
      "protected" : false,
      "id_str" : "44195788",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1795343628\/cscheid_normal.jpg",
      "id" : 44195788,
      "verified" : false
    }
  },
  "id" : 905843318982033409,
  "created_at" : "2017-09-07 17:20:51 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namrataa Shrestha",
      "screen_name" : "NamrataaS",
      "indices" : [ 0, 10 ],
      "id_str" : "1279362427",
      "id" : 1279362427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "904899937627906049",
  "geo" : { },
  "id_str" : "905842575365423104",
  "in_reply_to_user_id" : 1279362427,
  "text" : "@NamrataaS where can we watch this theater play ?",
  "id" : 905842575365423104,
  "in_reply_to_status_id" : 904899937627906049,
  "created_at" : "2017-09-07 17:17:54 +0000",
  "in_reply_to_screen_name" : "NamrataaS",
  "in_reply_to_user_id_str" : "1279362427",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romain Fran\u00E7ois",
      "screen_name" : "romain_francois",
      "indices" : [ 3, 19 ],
      "id_str" : "377578645",
      "id" : 377578645
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "funwithflags",
      "indices" : [ 21, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "905620036928147456",
  "text" : "RT @romain_francois: #funwithflags \nemo::jis %&gt;% \n   filter( category == \"Flags\" &amp; vendor_apple ) %&gt;% \n   pull( emoji ) %&gt;% \n   paste( coll\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/romain_francois\/status\/905537589175869441\/photo\/1",
        "indices" : [ 157, 180 ],
        "url" : "https:\/\/t.co\/WUZaBDFfda",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DJEdoa6XgAA5Qux.jpg",
        "id_str" : "905537580334284800",
        "id" : 905537580334284800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJEdoa6XgAA5Qux.jpg",
        "sizes" : [ {
          "h" : 254,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 636,
          "resize" : "fit",
          "w" : 1702
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 636,
          "resize" : "fit",
          "w" : 1702
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/WUZaBDFfda"
      } ],
      "hashtags" : [ {
        "text" : "funwithflags",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "905537589175869441",
    "text" : "#funwithflags \nemo::jis %&gt;% \n   filter( category == \"Flags\" &amp; vendor_apple ) %&gt;% \n   pull( emoji ) %&gt;% \n   paste( collapse = \"\") %&gt;% \n   cat https:\/\/t.co\/WUZaBDFfda",
    "id" : 905537589175869441,
    "created_at" : "2017-09-06 21:05:59 +0000",
    "user" : {
      "name" : "Romain Fran\u00E7ois",
      "screen_name" : "romain_francois",
      "protected" : false,
      "id_str" : "377578645",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/873245497091395584\/FPC4QEtQ_normal.jpg",
      "id" : 377578645,
      "verified" : false
    }
  },
  "id" : 905620036928147456,
  "created_at" : "2017-09-07 02:33:37 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olmos.",
      "screen_name" : "itsjustolmos",
      "indices" : [ 3, 16 ],
      "id_str" : "5293842",
      "id" : 5293842
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/itsjustolmos\/status\/904802256851218436\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/xlNzVlwWVf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DI6A2jkUIAA8omH.jpg",
      "id_str" : "904802249896894464",
      "id" : 904802249896894464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DI6A2jkUIAA8omH.jpg",
      "sizes" : [ {
        "h" : 669,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/xlNzVlwWVf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "905514889652748288",
  "text" : "RT @itsjustolmos: \"Tell Cersei. I want her to know it was me.\" https:\/\/t.co\/xlNzVlwWVf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/itsjustolmos\/status\/904802256851218436\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/xlNzVlwWVf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DI6A2jkUIAA8omH.jpg",
        "id_str" : "904802249896894464",
        "id" : 904802249896894464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DI6A2jkUIAA8omH.jpg",
        "sizes" : [ {
          "h" : 669,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 738,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 738,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 738,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/xlNzVlwWVf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "904802256851218436",
    "text" : "\"Tell Cersei. I want her to know it was me.\" https:\/\/t.co\/xlNzVlwWVf",
    "id" : 904802256851218436,
    "created_at" : "2017-09-04 20:24:03 +0000",
    "user" : {
      "name" : "Olmos.",
      "screen_name" : "itsjustolmos",
      "protected" : false,
      "id_str" : "5293842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/865042228145782784\/xdTjHqcL_normal.jpg",
      "id" : 5293842,
      "verified" : false
    }
  },
  "id" : 905514889652748288,
  "created_at" : "2017-09-06 19:35:48 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "codecentric AG",
      "screen_name" : "codecentric",
      "indices" : [ 0, 12 ],
      "id_str" : "16497594",
      "id" : 16497594
    }, {
      "name" : "Shirin Glander",
      "screen_name" : "ShirinGlander",
      "indices" : [ 13, 27 ],
      "id_str" : "3363802942",
      "id" : 3363802942
    }, {
      "name" : "Shirin Glander",
      "screen_name" : "ShirinGlander",
      "indices" : [ 63, 77 ],
      "id_str" : "3363802942",
      "id" : 3363802942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "905400185953636352",
  "geo" : { },
  "id_str" : "905498192619425792",
  "in_reply_to_user_id" : 16497594,
  "text" : "@codecentric @ShirinGlander This is a very interesting article @ShirinGlander . Thanks for sharing.",
  "id" : 905498192619425792,
  "in_reply_to_status_id" : 905400185953636352,
  "created_at" : "2017-09-06 18:29:27 +0000",
  "in_reply_to_screen_name" : "codecentric",
  "in_reply_to_user_id_str" : "16497594",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]