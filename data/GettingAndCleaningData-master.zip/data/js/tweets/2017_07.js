Grailbird.data.tweets_2017_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rio Ferdinand",
      "screen_name" : "rioferdy5",
      "indices" : [ 3, 13 ],
      "id_str" : "155927976",
      "id" : 155927976
    }, {
      "name" : "Chicharito Hernandez",
      "screen_name" : "CH14_",
      "indices" : [ 30, 36 ],
      "id_str" : "618420295",
      "id" : 618420295
    }, {
      "name" : "Premier League",
      "screen_name" : "premierleague",
      "indices" : [ 61, 75 ],
      "id_str" : "343627165",
      "id" : 343627165
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Goals",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/ekoTgwGSJL",
      "expanded_url" : "https:\/\/twitter.com\/westhamutd\/status\/889789438997528576",
      "display_url" : "twitter.com\/westhamutd\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "889939255333535744",
  "text" : "RT @rioferdy5: Yesssss my man @CH14_ ... welcome back to the @premierleague \uD83D\uDE4C\uD83C\uDFFD\u2692 #Goals https:\/\/t.co\/ekoTgwGSJL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chicharito Hernandez",
        "screen_name" : "CH14_",
        "indices" : [ 15, 21 ],
        "id_str" : "618420295",
        "id" : 618420295
      }, {
        "name" : "Premier League",
        "screen_name" : "premierleague",
        "indices" : [ 46, 60 ],
        "id_str" : "343627165",
        "id" : 343627165
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Goals",
        "indices" : [ 65, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/ekoTgwGSJL",
        "expanded_url" : "https:\/\/twitter.com\/westhamutd\/status\/889789438997528576",
        "display_url" : "twitter.com\/westhamutd\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "889792398875914242",
    "text" : "Yesssss my man @CH14_ ... welcome back to the @premierleague \uD83D\uDE4C\uD83C\uDFFD\u2692 #Goals https:\/\/t.co\/ekoTgwGSJL",
    "id" : 889792398875914242,
    "created_at" : "2017-07-25 10:20:14 +0000",
    "user" : {
      "name" : "Rio Ferdinand",
      "screen_name" : "rioferdy5",
      "protected" : false,
      "id_str" : "155927976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/904754411733385216\/BarUaDlG_normal.jpg",
      "id" : 155927976,
      "verified" : true
    }
  },
  "id" : 889939255333535744,
  "created_at" : "2017-07-25 20:03:47 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]