Grailbird.data.tweets_2016_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 3, 10 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mufc",
      "indices" : [ 19, 24 ]
    }, {
      "text" : "VivaVidic",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693098709232459777",
  "text" : "RT @ManUtd: Former #mufc defender Nemanja Vidic has announced his retirement from football. Thanks for the memories! #VivaVidic https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/693041251487240192\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/G4sbdsjj1m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ4tU5lWcAAN4sC.jpg",
        "id_str" : "693041229739749376",
        "id" : 693041229739749376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ4tU5lWcAAN4sC.jpg",
        "sizes" : [ {
          "h" : 530,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1598,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 936,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2352,
          "resize" : "fit",
          "w" : 3015
        } ],
        "display_url" : "pic.twitter.com\/G4sbdsjj1m"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/693041251487240192\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/G4sbdsjj1m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ4tWExWYAAYy4J.jpg",
        "id_str" : "693041249922736128",
        "id" : 693041249922736128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ4tWExWYAAYy4J.jpg",
        "sizes" : [ {
          "h" : 834,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1424,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2433,
          "resize" : "fit",
          "w" : 3500
        } ],
        "display_url" : "pic.twitter.com\/G4sbdsjj1m"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/693041251487240192\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/G4sbdsjj1m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ4tV5BWEAAgGfM.jpg",
        "id_str" : "693041246768599040",
        "id" : 693041246768599040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ4tV5BWEAAgGfM.jpg",
        "sizes" : [ {
          "h" : 826,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2066,
          "resize" : "fit",
          "w" : 3000
        }, {
          "h" : 1410,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/G4sbdsjj1m"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/693041251487240192\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/G4sbdsjj1m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ4tU-vWcAEHHaq.jpg",
        "id_str" : "693041231123869697",
        "id" : 693041231123869697,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ4tU-vWcAEHHaq.jpg",
        "sizes" : [ {
          "h" : 1377,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 807,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2026,
          "resize" : "fit",
          "w" : 3013
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/G4sbdsjj1m"
      } ],
      "hashtags" : [ {
        "text" : "mufc",
        "indices" : [ 7, 12 ]
      }, {
        "text" : "VivaVidic",
        "indices" : [ 105, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693041251487240192",
    "text" : "Former #mufc defender Nemanja Vidic has announced his retirement from football. Thanks for the memories! #VivaVidic https:\/\/t.co\/G4sbdsjj1m",
    "id" : 693041251487240192,
    "created_at" : "2016-01-29 12:01:25 +0000",
    "user" : {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "protected" : false,
      "id_str" : "558797310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/934706707258904578\/7HAVD2b0_normal.jpg",
      "id" : 558797310,
      "verified" : true
    }
  },
  "id" : 693098709232459777,
  "created_at" : "2016-01-29 15:49:44 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sudhamshu K.C.",
      "screen_name" : "Drsudhamshu",
      "indices" : [ 3, 15 ],
      "id_str" : "1264983847",
      "id" : 1264983847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693091466285940736",
  "text" : "RT @Drsudhamshu: \u0928\u0947\u092A\u093E\u0932\u0940 U19 \u091F\u094B\u0932\u0940\u0932\u0947 \u092D\u093E\u0930\u0924\u0932\u093E\u0908 \u091C\u093F\u0924\u0947\u092E\u093E \u0938\u0902\u092A\u0942\u0930\u094D\u0923 \u0916\u0947\u0932\u093E\u0921\u0940 \u0939\u0930\u0941\u0932\u093E\u0908 \u091C\u093F\u0928\u094D\u0926\u0917\u0940 \u092D\u0930\u0940 \u092E\u0947\u0930\u094B \u0915\u094D\u0932\u093F\u0928\u093F\u0915\u092E\u093E \u0928\u093F\u0936\u0941\u0932\u094D\u0915 \u0909\u092A\u091A\u093E\u0930\u0915\u094B \u0918\u094B\u0937\u0923\u093E \u0917\u0930\u094D\u0926\u091B\u0941 \u0964",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692721505583697921",
    "text" : "\u0928\u0947\u092A\u093E\u0932\u0940 U19 \u091F\u094B\u0932\u0940\u0932\u0947 \u092D\u093E\u0930\u0924\u0932\u093E\u0908 \u091C\u093F\u0924\u0947\u092E\u093E \u0938\u0902\u092A\u0942\u0930\u094D\u0923 \u0916\u0947\u0932\u093E\u0921\u0940 \u0939\u0930\u0941\u0932\u093E\u0908 \u091C\u093F\u0928\u094D\u0926\u0917\u0940 \u092D\u0930\u0940 \u092E\u0947\u0930\u094B \u0915\u094D\u0932\u093F\u0928\u093F\u0915\u092E\u093E \u0928\u093F\u0936\u0941\u0932\u094D\u0915 \u0909\u092A\u091A\u093E\u0930\u0915\u094B \u0918\u094B\u0937\u0923\u093E \u0917\u0930\u094D\u0926\u091B\u0941 \u0964",
    "id" : 692721505583697921,
    "created_at" : "2016-01-28 14:50:51 +0000",
    "user" : {
      "name" : "Sudhamshu K.C.",
      "screen_name" : "Drsudhamshu",
      "protected" : false,
      "id_str" : "1264983847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765797755625373696\/s1v4p73e_normal.jpg",
      "id" : 1264983847,
      "verified" : false
    }
  },
  "id" : 693091466285940736,
  "created_at" : "2016-01-29 15:20:57 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NOAA",
      "screen_name" : "NOAA",
      "indices" : [ 3, 8 ],
      "id_str" : "14342564",
      "id" : 14342564
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "students",
      "indices" : [ 20, 29 ]
    }, {
      "text" : "Undergrad",
      "indices" : [ 36, 46 ]
    }, {
      "text" : "Scholarship",
      "indices" : [ 47, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692422184896049153",
  "text" : "RT @NOAA: Heads up, #students: NOAA #Undergrad #Scholarship applications deadline is 1\/29. Don't forget to submit yours: https:\/\/t.co\/4P5u9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "students",
        "indices" : [ 10, 19 ]
      }, {
        "text" : "Undergrad",
        "indices" : [ 26, 36 ]
      }, {
        "text" : "Scholarship",
        "indices" : [ 37, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/4P5u9u0zN6",
        "expanded_url" : "http:\/\/www.oesd.noaa.gov\/scholarships\/",
        "display_url" : "oesd.noaa.gov\/scholarships\/"
      } ]
    },
    "geo" : { },
    "id_str" : "692421178686836736",
    "text" : "Heads up, #students: NOAA #Undergrad #Scholarship applications deadline is 1\/29. Don't forget to submit yours: https:\/\/t.co\/4P5u9u0zN6",
    "id" : 692421178686836736,
    "created_at" : "2016-01-27 18:57:28 +0000",
    "user" : {
      "name" : "NOAA",
      "screen_name" : "NOAA",
      "protected" : false,
      "id_str" : "14342564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529277799018676225\/MOsMKe14_normal.jpeg",
      "id" : 14342564,
      "verified" : true
    }
  },
  "id" : 692422184896049153,
  "created_at" : "2016-01-27 19:01:28 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 3, 18 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/washingtonpost\/status\/692404214652391424\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/FbnmUaZ681",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZvp9r_WAAA1YEc.jpg",
      "id_str" : "692404213721202688",
      "id" : 692404213721202688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZvp9r_WAAA1YEc.jpg",
      "sizes" : [ {
        "h" : 529,
        "resize" : "fit",
        "w" : 1018
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 1018
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 1018
      } ],
      "display_url" : "pic.twitter.com\/FbnmUaZ681"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/z4EF508jxn",
      "expanded_url" : "http:\/\/wapo.st\/1nyoWix",
      "display_url" : "wapo.st\/1nyoWix"
    } ]
  },
  "geo" : { },
  "id_str" : "692409578609328129",
  "text" : "RT @washingtonpost: Murder was up 17 percent in America's biggest cities last year https:\/\/t.co\/z4EF508jxn https:\/\/t.co\/FbnmUaZ681",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/washingtonpost\/status\/692404214652391424\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/FbnmUaZ681",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZvp9r_WAAA1YEc.jpg",
        "id_str" : "692404213721202688",
        "id" : 692404213721202688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZvp9r_WAAA1YEc.jpg",
        "sizes" : [ {
          "h" : 529,
          "resize" : "fit",
          "w" : 1018
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 1018
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 1018
        } ],
        "display_url" : "pic.twitter.com\/FbnmUaZ681"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/z4EF508jxn",
        "expanded_url" : "http:\/\/wapo.st\/1nyoWix",
        "display_url" : "wapo.st\/1nyoWix"
      } ]
    },
    "geo" : { },
    "id_str" : "692404214652391424",
    "text" : "Murder was up 17 percent in America's biggest cities last year https:\/\/t.co\/z4EF508jxn https:\/\/t.co\/FbnmUaZ681",
    "id" : 692404214652391424,
    "created_at" : "2016-01-27 17:50:03 +0000",
    "user" : {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "protected" : false,
      "id_str" : "2467791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875440182501277696\/n-Ic9nBO_normal.jpg",
      "id" : 2467791,
      "verified" : true
    }
  },
  "id" : 692409578609328129,
  "created_at" : "2016-01-27 18:11:22 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "South Florida Water",
      "screen_name" : "SFWMD",
      "indices" : [ 0, 6 ],
      "id_str" : "54424058",
      "id" : 54424058
    }, {
      "name" : "USACE Jax District",
      "screen_name" : "JaxStrong",
      "indices" : [ 7, 17 ],
      "id_str" : "50683217",
      "id" : 50683217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692406999615668224",
  "geo" : { },
  "id_str" : "692408991725555713",
  "in_reply_to_user_id" : 54424058,
  "text" : "@SFWMD @JaxStrong Thank you SFWMWD. I think these links would be useful for me.",
  "id" : 692408991725555713,
  "in_reply_to_status_id" : 692406999615668224,
  "created_at" : "2016-01-27 18:09:02 +0000",
  "in_reply_to_screen_name" : "SFWMD",
  "in_reply_to_user_id_str" : "54424058",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USACE Jax District",
      "screen_name" : "JaxStrong",
      "indices" : [ 0, 10 ],
      "id_str" : "50683217",
      "id" : 50683217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692407353577213952",
  "geo" : { },
  "id_str" : "692408662476873728",
  "in_reply_to_user_id" : 50683217,
  "text" : "@JaxStrong Thank you for these link. I will try to look into these link. An easier way to extract just data time series would be helpful.",
  "id" : 692408662476873728,
  "in_reply_to_status_id" : 692407353577213952,
  "created_at" : "2016-01-27 18:07:44 +0000",
  "in_reply_to_screen_name" : "JaxStrong",
  "in_reply_to_user_id_str" : "50683217",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USACE Jax District",
      "screen_name" : "JaxStrong",
      "indices" : [ 0, 10 ],
      "id_str" : "50683217",
      "id" : 50683217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692406268418482177",
  "geo" : { },
  "id_str" : "692406616226975750",
  "in_reply_to_user_id" : 50683217,
  "text" : "@JaxStrong I am interested in lake level and water quality data if available.",
  "id" : 692406616226975750,
  "in_reply_to_status_id" : 692406268418482177,
  "created_at" : "2016-01-27 17:59:36 +0000",
  "in_reply_to_screen_name" : "JaxStrong",
  "in_reply_to_user_id_str" : "50683217",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USACE Jax District",
      "screen_name" : "JaxStrong",
      "indices" : [ 0, 10 ],
      "id_str" : "50683217",
      "id" : 50683217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692404617255239680",
  "geo" : { },
  "id_str" : "692405213492162560",
  "in_reply_to_user_id" : 50683217,
  "text" : "@JaxStrong while I saw the daily report there but is there any way to view long term data for example a month of data from yesterday ?",
  "id" : 692405213492162560,
  "in_reply_to_status_id" : 692404617255239680,
  "created_at" : "2016-01-27 17:54:01 +0000",
  "in_reply_to_screen_name" : "JaxStrong",
  "in_reply_to_user_id_str" : "50683217",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SFWMD Emergency",
      "screen_name" : "SFWMD_EM",
      "indices" : [ 3, 12 ],
      "id_str" : "2463179851",
      "id" : 2463179851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692402761967747072",
  "text" : "RT @SFWMD_EM: Water managers are adjusting the regional flood control system as needed to accept runoff from secondary canals. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SFWMD_EM\/status\/692350744884858880\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/CtpbYycDke",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZu5N48WYAEZzBY.jpg",
        "id_str" : "692350616006451201",
        "id" : 692350616006451201,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZu5N48WYAEZzBY.jpg",
        "sizes" : [ {
          "h" : 1325,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 776,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2211,
          "resize" : "fit",
          "w" : 3417
        } ],
        "display_url" : "pic.twitter.com\/CtpbYycDke"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "692350555113521153",
    "geo" : { },
    "id_str" : "692350744884858880",
    "in_reply_to_user_id" : 2463179851,
    "text" : "Water managers are adjusting the regional flood control system as needed to accept runoff from secondary canals. https:\/\/t.co\/CtpbYycDke",
    "id" : 692350744884858880,
    "in_reply_to_status_id" : 692350555113521153,
    "created_at" : "2016-01-27 14:17:35 +0000",
    "in_reply_to_screen_name" : "SFWMD_EM",
    "in_reply_to_user_id_str" : "2463179851",
    "user" : {
      "name" : "SFWMD Emergency",
      "screen_name" : "SFWMD_EM",
      "protected" : false,
      "id_str" : "2463179851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461522747999264769\/bLzw_ftl_normal.jpeg",
      "id" : 2463179851,
      "verified" : false
    }
  },
  "id" : 692402761967747072,
  "created_at" : "2016-01-27 17:44:17 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USACE Jax District",
      "screen_name" : "JaxStrong",
      "indices" : [ 0, 10 ],
      "id_str" : "50683217",
      "id" : 50683217
    }, {
      "name" : "South Florida Water",
      "screen_name" : "SFWMD",
      "indices" : [ 11, 17 ],
      "id_str" : "54424058",
      "id" : 54424058
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692380040667996161",
  "geo" : { },
  "id_str" : "692402324002738176",
  "in_reply_to_user_id" : 50683217,
  "text" : "@JaxStrong @SFWMD Is lake okeechobee continuous monitoring data available to public ?",
  "id" : 692402324002738176,
  "in_reply_to_status_id" : 692380040667996161,
  "created_at" : "2016-01-27 17:42:32 +0000",
  "in_reply_to_screen_name" : "JaxStrong",
  "in_reply_to_user_id_str" : "50683217",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achim Steiner",
      "screen_name" : "ASteiner",
      "indices" : [ 3, 12 ],
      "id_str" : "3232924232",
      "id" : 3232924232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/EInQC0tCVL",
      "expanded_url" : "http:\/\/www.nature.com\/news\/worst-year-ever-for-rhino-poaching-in-africa-1.19225",
      "display_url" : "nature.com\/news\/worst-yea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692023705153581057",
  "text" : "RT @ASteiner: A tragic year for rhinos in Africa. 2015 saw a record high number poached on the continent. https:\/\/t.co\/EInQC0tCVL https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ASteiner\/status\/691944129765470208\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/sDVPOF4lEH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZpHhMBWcAAk5NH.jpg",
        "id_str" : "691944128242937856",
        "id" : 691944128242937856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZpHhMBWcAAk5NH.jpg",
        "sizes" : [ {
          "h" : 1461,
          "resize" : "fit",
          "w" : 2200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 797,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1360,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/sDVPOF4lEH"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/EInQC0tCVL",
        "expanded_url" : "http:\/\/www.nature.com\/news\/worst-year-ever-for-rhino-poaching-in-africa-1.19225",
        "display_url" : "nature.com\/news\/worst-yea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "691944129765470208",
    "text" : "A tragic year for rhinos in Africa. 2015 saw a record high number poached on the continent. https:\/\/t.co\/EInQC0tCVL https:\/\/t.co\/sDVPOF4lEH",
    "id" : 691944129765470208,
    "created_at" : "2016-01-26 11:21:50 +0000",
    "user" : {
      "name" : "Achim Steiner",
      "screen_name" : "ASteiner",
      "protected" : false,
      "id_str" : "3232924232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612695984150331392\/XzH-Gphh_normal.jpg",
      "id" : 3232924232,
      "verified" : true
    }
  },
  "id" : 692023705153581057,
  "created_at" : "2016-01-26 16:38:03 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    }, {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 57, 71 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EE",
      "indices" : [ 120, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691672340590043139",
  "text" : "RT @EFDC_Explorer: A great video to getting started with @EFDC_Explorer software. Reliable environmental modeling using #EE https:\/\/t.co\/GA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EFDC_Explorer",
        "screen_name" : "EFDC_Explorer",
        "indices" : [ 38, 52 ],
        "id_str" : "351972911",
        "id" : 351972911
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EE",
        "indices" : [ 101, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/GAifHFtEqf",
        "expanded_url" : "https:\/\/youtu.be\/Pn2WJecxgx0",
        "display_url" : "youtu.be\/Pn2WJecxgx0"
      } ]
    },
    "geo" : { },
    "id_str" : "691670858780127232",
    "text" : "A great video to getting started with @EFDC_Explorer software. Reliable environmental modeling using #EE https:\/\/t.co\/GAifHFtEqf",
    "id" : 691670858780127232,
    "created_at" : "2016-01-25 17:15:58 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 691672340590043139,
  "created_at" : "2016-01-25 17:21:51 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lvgout",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691000980435931136",
  "text" : "United is so boring to watch.  #lvgout",
  "id" : 691000980435931136,
  "created_at" : "2016-01-23 20:54:06 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "indices" : [ 0, 12 ],
      "id_str" : "216299334",
      "id" : 216299334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690588223177752577",
  "in_reply_to_user_id" : 216299334,
  "text" : "@piersmorgan Did you ever win premier league for 8 years when RVP was in Arsenal ?",
  "id" : 690588223177752577,
  "created_at" : "2016-01-22 17:33:57 +0000",
  "in_reply_to_screen_name" : "piersmorgan",
  "in_reply_to_user_id_str" : "216299334",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Climate Reality",
      "screen_name" : "ClimateReality",
      "indices" : [ 3, 18 ],
      "id_str" : "16958346",
      "id" : 16958346
    }, {
      "name" : "Climate Central",
      "screen_name" : "ClimateCentral",
      "indices" : [ 23, 38 ],
      "id_str" : "15463610",
      "id" : 15463610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ClimateCentral\/status\/689871264039723008\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/2Z1wlXTnNI",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CZLqQkbWIAA0VAC.png",
      "id_str" : "689871263318286336",
      "id" : 689871263318286336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CZLqQkbWIAA0VAC.png",
      "sizes" : [ {
        "h" : 490,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/2Z1wlXTnNI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/nMBd1YuqLU",
      "expanded_url" : "http:\/\/buff.ly\/1WuAcIq",
      "display_url" : "buff.ly\/1WuAcIq"
    } ]
  },
  "geo" : { },
  "id_str" : "690295921976864768",
  "text" : "RT @ClimateReality: MT @ClimateCentral: 2015 blew away the competition for record heat https:\/\/t.co\/nMBd1YuqLU  https:\/\/t.co\/2Z1wlXTnNI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Climate Central",
        "screen_name" : "ClimateCentral",
        "indices" : [ 3, 18 ],
        "id_str" : "15463610",
        "id" : 15463610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ClimateCentral\/status\/689871264039723008\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/2Z1wlXTnNI",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CZLqQkbWIAA0VAC.png",
        "id_str" : "689871263318286336",
        "id" : 689871263318286336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CZLqQkbWIAA0VAC.png",
        "sizes" : [ {
          "h" : 490,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/2Z1wlXTnNI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/nMBd1YuqLU",
        "expanded_url" : "http:\/\/buff.ly\/1WuAcIq",
        "display_url" : "buff.ly\/1WuAcIq"
      } ]
    },
    "geo" : { },
    "id_str" : "690295656049672194",
    "text" : "MT @ClimateCentral: 2015 blew away the competition for record heat https:\/\/t.co\/nMBd1YuqLU  https:\/\/t.co\/2Z1wlXTnNI",
    "id" : 690295656049672194,
    "created_at" : "2016-01-21 22:11:24 +0000",
    "user" : {
      "name" : "Climate Reality",
      "screen_name" : "ClimateReality",
      "protected" : false,
      "id_str" : "16958346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/808356177851518976\/ZxOHK5Vm_normal.jpg",
      "id" : 16958346,
      "verified" : true
    }
  },
  "id" : 690295921976864768,
  "created_at" : "2016-01-21 22:12:27 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/xKdTrpjdCp",
      "expanded_url" : "https:\/\/twitter.com\/EFDC_Explorer\/status\/690262774358761472",
      "display_url" : "twitter.com\/EFDC_Explorer\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690263080605917184",
  "text" : "Free EFDC training. That's great opportunity.  https:\/\/t.co\/xKdTrpjdCp",
  "id" : 690263080605917184,
  "created_at" : "2016-01-21 20:01:57 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achim Steiner",
      "screen_name" : "ASteiner",
      "indices" : [ 3, 12 ],
      "id_str" : "3232924232",
      "id" : 3232924232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "climatechange",
      "indices" : [ 88, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/B6lG3N5MPp",
      "expanded_url" : "http:\/\/www.ncdc.noaa.gov\/sotc\/summary-info\/global\/201512",
      "display_url" : "ncdc.noaa.gov\/sotc\/summary-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690253821214257152",
  "text" : "RT @ASteiner: 2015 was the warmest year on record. We can keep debating facts or act on #climatechange now https:\/\/t.co\/B6lG3N5MPp https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ASteiner\/status\/690125972616642561\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/rpQkesO4Br",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZPR5zJXEAAK4Tc.jpg",
        "id_str" : "690125958830034944",
        "id" : 690125958830034944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZPR5zJXEAAK4Tc.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 583
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 583
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 583
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 583
        } ],
        "display_url" : "pic.twitter.com\/rpQkesO4Br"
      } ],
      "hashtags" : [ {
        "text" : "climatechange",
        "indices" : [ 74, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/B6lG3N5MPp",
        "expanded_url" : "http:\/\/www.ncdc.noaa.gov\/sotc\/summary-info\/global\/201512",
        "display_url" : "ncdc.noaa.gov\/sotc\/summary-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "690125972616642561",
    "text" : "2015 was the warmest year on record. We can keep debating facts or act on #climatechange now https:\/\/t.co\/B6lG3N5MPp https:\/\/t.co\/rpQkesO4Br",
    "id" : 690125972616642561,
    "created_at" : "2016-01-21 10:57:08 +0000",
    "user" : {
      "name" : "Achim Steiner",
      "screen_name" : "ASteiner",
      "protected" : false,
      "id_str" : "3232924232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612695984150331392\/XzH-Gphh_normal.jpg",
      "id" : 3232924232,
      "verified" : true
    }
  },
  "id" : 690253821214257152,
  "created_at" : "2016-01-21 19:25:09 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    }, {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 23, 37 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFDC",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/BPQO27ykYu",
      "expanded_url" : "http:\/\/www.efdc-explorer.com\/support\/newsletters\/efdc-explorer-did-you-know-2015-07-10.html",
      "display_url" : "efdc-explorer.com\/support\/newsle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690242607696326656",
  "text" : "RT @EFDC_Explorer: Use @EFDC_Explorer software to automatically triangularize the grid cells in #EFDC model.  https:\/\/t.co\/BPQO27ykYu https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EFDC_Explorer",
        "screen_name" : "EFDC_Explorer",
        "indices" : [ 4, 18 ],
        "id_str" : "351972911",
        "id" : 351972911
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EFDC_Explorer\/status\/690241940525215744\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/znpqmqYH4K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZQ7Yx5VAAAYzBy.jpg",
        "id_str" : "690241939791216640",
        "id" : 690241939791216640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZQ7Yx5VAAAYzBy.jpg",
        "sizes" : [ {
          "h" : 789,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 521
        }, {
          "h" : 789,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 789,
          "resize" : "fit",
          "w" : 605
        } ],
        "display_url" : "pic.twitter.com\/znpqmqYH4K"
      } ],
      "hashtags" : [ {
        "text" : "EFDC",
        "indices" : [ 77, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/BPQO27ykYu",
        "expanded_url" : "http:\/\/www.efdc-explorer.com\/support\/newsletters\/efdc-explorer-did-you-know-2015-07-10.html",
        "display_url" : "efdc-explorer.com\/support\/newsle\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "690241940525215744",
    "text" : "Use @EFDC_Explorer software to automatically triangularize the grid cells in #EFDC model.  https:\/\/t.co\/BPQO27ykYu https:\/\/t.co\/znpqmqYH4K",
    "id" : 690241940525215744,
    "created_at" : "2016-01-21 18:37:57 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 690242607696326656,
  "created_at" : "2016-01-21 18:40:36 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New York Times World",
      "screen_name" : "nytimesworld",
      "indices" : [ 0, 13 ],
      "id_str" : "1877831",
      "id" : 1877831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689593194313601030",
  "geo" : { },
  "id_str" : "689593405731536896",
  "in_reply_to_user_id" : 1877831,
  "text" : "@nytimesworld that husband should be punished publicly. The world has gone insane.",
  "id" : 689593405731536896,
  "in_reply_to_status_id" : 689593194313601030,
  "created_at" : "2016-01-19 23:40:54 +0000",
  "in_reply_to_screen_name" : "nytimesworld",
  "in_reply_to_user_id_str" : "1877831",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MLK Day",
      "screen_name" : "MLKDay",
      "indices" : [ 3, 10 ],
      "id_str" : "17001730",
      "id" : 17001730
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MLKDay\/status\/689095500721704961\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/XT8r544ZZs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZAotMSWsAAjAWv.png",
      "id_str" : "689095499845120000",
      "id" : 689095499845120000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZAotMSWsAAjAWv.png",
      "sizes" : [ {
        "h" : 308,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XT8r544ZZs"
    } ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 40, 47 ]
    }, {
      "text" : "service",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689142239755280384",
  "text" : "RT @MLKDay: What matters to you on this #MLKDay? Share your #service story. https:\/\/t.co\/XT8r544ZZs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MLKDay\/status\/689095500721704961\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/XT8r544ZZs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZAotMSWsAAjAWv.png",
        "id_str" : "689095499845120000",
        "id" : 689095499845120000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZAotMSWsAAjAWv.png",
        "sizes" : [ {
          "h" : 308,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 308,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 308,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 308,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/XT8r544ZZs"
      } ],
      "hashtags" : [ {
        "text" : "MLKDay",
        "indices" : [ 28, 35 ]
      }, {
        "text" : "service",
        "indices" : [ 48, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "689095500721704961",
    "text" : "What matters to you on this #MLKDay? Share your #service story. https:\/\/t.co\/XT8r544ZZs",
    "id" : 689095500721704961,
    "created_at" : "2016-01-18 14:42:24 +0000",
    "user" : {
      "name" : "MLK Day",
      "screen_name" : "MLKDay",
      "protected" : false,
      "id_str" : "17001730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556146916442902528\/Cu6dRDjT_normal.jpeg",
      "id" : 17001730,
      "verified" : false
    }
  },
  "id" : 689142239755280384,
  "created_at" : "2016-01-18 17:48:08 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 3, 8 ],
      "id_str" : "14293310",
      "id" : 14293310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/9obSAxvmet",
      "expanded_url" : "http:\/\/ti.me\/1QiwBwk",
      "display_url" : "ti.me\/1QiwBwk"
    } ]
  },
  "geo" : { },
  "id_str" : "689125244036976640",
  "text" : "RT @TIME: Avalanche kills 5 soldiers in French Alps https:\/\/t.co\/9obSAxvmet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/9obSAxvmet",
        "expanded_url" : "http:\/\/ti.me\/1QiwBwk",
        "display_url" : "ti.me\/1QiwBwk"
      } ]
    },
    "geo" : { },
    "id_str" : "689124854046572545",
    "text" : "Avalanche kills 5 soldiers in French Alps https:\/\/t.co\/9obSAxvmet",
    "id" : 689124854046572545,
    "created_at" : "2016-01-18 16:39:03 +0000",
    "user" : {
      "name" : "TIME",
      "screen_name" : "TIME",
      "protected" : false,
      "id_str" : "14293310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1700796190\/Picture_24_normal.png",
      "id" : 14293310,
      "verified" : true
    }
  },
  "id" : 689125244036976640,
  "created_at" : "2016-01-18 16:40:36 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UnitedvsLiverpool",
      "indices" : [ 34, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688781514964729856",
  "text" : "A sweet victory against Liverpool #UnitedvsLiverpool",
  "id" : 688781514964729856,
  "created_at" : "2016-01-17 17:54:44 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/ByCTBryI7N",
      "expanded_url" : "http:\/\/www.cnn.com\/2016\/01\/16\/middleeast\/syria-isis-attack\/index.html",
      "display_url" : "cnn.com\/2016\/01\/16\/mid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688766888617357312",
  "text" : "Reports: ISIS kills scores in Syria\nhttps:\/\/t.co\/ByCTBryI7N",
  "id" : 688766888617357312,
  "created_at" : "2016-01-17 16:56:37 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 0, 7 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688735745775898624",
  "geo" : { },
  "id_str" : "688737251992338433",
  "in_reply_to_user_id" : 558797310,
  "text" : "@ManUtd I didn't see any passion on players. Why do you sound like United played a great half ? I am so diasppointed with this performance.",
  "id" : 688737251992338433,
  "in_reply_to_status_id" : 688735745775898624,
  "created_at" : "2016-01-17 14:58:51 +0000",
  "in_reply_to_screen_name" : "ManUtd",
  "in_reply_to_user_id_str" : "558797310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United TV",
      "screen_name" : "ManUtd1__",
      "indices" : [ 0, 10 ],
      "id_str" : "2525096743",
      "id" : 2525096743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688731651162161152",
  "geo" : { },
  "id_str" : "688731795261534210",
  "in_reply_to_user_id" : 2525096743,
  "text" : "@ManUtd1__ No midfield players receiving the ball.",
  "id" : 688731795261534210,
  "in_reply_to_status_id" : 688731651162161152,
  "created_at" : "2016-01-17 14:37:10 +0000",
  "in_reply_to_screen_name" : "ManUtd1__",
  "in_reply_to_user_id_str" : "2525096743",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 0, 7 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688731418025918469",
  "geo" : { },
  "id_str" : "688731617741807617",
  "in_reply_to_user_id" : 558797310,
  "text" : "@ManUtd What a waste of team. Van Gaal needs to go and a bunch of players.",
  "id" : 688731617741807617,
  "in_reply_to_status_id" : 688731418025918469,
  "created_at" : "2016-01-17 14:36:28 +0000",
  "in_reply_to_screen_name" : "ManUtd",
  "in_reply_to_user_id_str" : "558797310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ManUtdvsLiverpool",
      "indices" : [ 80, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688730157553561601",
  "text" : "Really bad team choice by VanGaal. They are playing awful for first 25 minutes. #ManUtdvsLiverpool #2016-01-17",
  "id" : 688730157553561601,
  "created_at" : "2016-01-17 14:30:40 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688628173689389056",
  "text" : "Looking forward to Manchester United and Liverpool game. Hoping for United victory.",
  "id" : 688628173689389056,
  "created_at" : "2016-01-17 07:45:25 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 75, 79 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/6j545cana9",
      "expanded_url" : "http:\/\/cnn.it\/1RV0RNQ",
      "display_url" : "cnn.it\/1RV0RNQ"
    } ]
  },
  "geo" : { },
  "id_str" : "688268597701906432",
  "text" : "Burkina Faso terror: Security forces raid besieged hotel, free 63 hostages @CNN https:\/\/t.co\/6j545cana9",
  "id" : 688268597701906432,
  "created_at" : "2016-01-16 07:56:35 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert T. Kiyosaki",
      "screen_name" : "theRealKiyosaki",
      "indices" : [ 0, 16 ],
      "id_str" : "29856819",
      "id" : 29856819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687982620878090241",
  "geo" : { },
  "id_str" : "688043783771009025",
  "in_reply_to_user_id" : 29856819,
  "text" : "@theRealKiyosaki first word : overcome second word: market",
  "id" : 688043783771009025,
  "in_reply_to_status_id" : 687982620878090241,
  "created_at" : "2016-01-15 17:03:15 +0000",
  "in_reply_to_screen_name" : "theRealKiyosaki",
  "in_reply_to_user_id_str" : "29856819",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristiano Ronaldo",
      "screen_name" : "Cristiano",
      "indices" : [ 3, 13 ],
      "id_str" : "155659213",
      "id" : 155659213
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Cristiano\/status\/686646593408372737\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/o02KmJr76b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYd1baCWwAAIYxF.jpg",
      "id_str" : "686646581903409152",
      "id" : 686646581903409152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYd1baCWwAAIYxF.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/o02KmJr76b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686647346612969472",
  "text" : "RT @Cristiano: Wonderful team! \uD83D\uDD1D\uD83D\uDC4C\u26BD\uFE0F\uD83D\uDC4D https:\/\/t.co\/o02KmJr76b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cristiano\/status\/686646593408372737\/photo\/1",
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/o02KmJr76b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYd1baCWwAAIYxF.jpg",
        "id_str" : "686646581903409152",
        "id" : 686646581903409152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYd1baCWwAAIYxF.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/o02KmJr76b"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "686646593408372737",
    "text" : "Wonderful team! \uD83D\uDD1D\uD83D\uDC4C\u26BD\uFE0F\uD83D\uDC4D https:\/\/t.co\/o02KmJr76b",
    "id" : 686646593408372737,
    "created_at" : "2016-01-11 20:31:19 +0000",
    "user" : {
      "name" : "Cristiano Ronaldo",
      "screen_name" : "Cristiano",
      "protected" : false,
      "id_str" : "155659213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913794143322804225\/-yBKQ-3r_normal.jpg",
      "id" : 155659213,
      "verified" : true
    }
  },
  "id" : 686647346612969472,
  "created_at" : "2016-01-11 20:34:19 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 108, 112 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/vJ62Pl4lYx",
      "expanded_url" : "http:\/\/cnn.it\/1OlM4qN",
      "display_url" : "cnn.it\/1OlM4qN"
    } ]
  },
  "geo" : { },
  "id_str" : "686644019615547392",
  "text" : "These teens deserve punishment. 4 teens arrested in alleged gang rape of 18-year-old in Brooklyn playground @CNN https:\/\/t.co\/vJ62Pl4lYx",
  "id" : 686644019615547392,
  "created_at" : "2016-01-11 20:21:06 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "indices" : [ 0, 12 ],
      "id_str" : "216299334",
      "id" : 216299334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686642008878755841",
  "geo" : { },
  "id_str" : "686642857722052608",
  "in_reply_to_user_id" : 216299334,
  "text" : "@piersmorgan You will complain no matter how well Arsene and Arsenal are doing. Complaining is part of your job.",
  "id" : 686642857722052608,
  "in_reply_to_status_id" : 686642008878755841,
  "created_at" : "2016-01-11 20:16:29 +0000",
  "in_reply_to_screen_name" : "piersmorgan",
  "in_reply_to_user_id_str" : "216299334",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 0, 8 ],
      "id_str" : "807095",
      "id" : 807095
    }, {
      "name" : "Roy Price",
      "screen_name" : "RoyPrice",
      "indices" : [ 9, 18 ],
      "id_str" : "16618503",
      "id" : 16618503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686421613483548673",
  "geo" : { },
  "id_str" : "686642285015007233",
  "in_reply_to_user_id" : 807095,
  "text" : "@nytimes @RoyPrice Netflix 0 ?",
  "id" : 686642285015007233,
  "in_reply_to_status_id" : 686421613483548673,
  "created_at" : "2016-01-11 20:14:12 +0000",
  "in_reply_to_screen_name" : "nytimes",
  "in_reply_to_user_id_str" : "807095",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brigitte Mueller",
      "screen_name" : "brigittetwiits",
      "indices" : [ 3, 18 ],
      "id_str" : "3387549078",
      "id" : 3387549078
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sporting",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686636003759501312",
  "text" : "RT @brigittetwiits: Has your experience at a #sporting event ever been impaired by the people around you?\nAnswer not below = PM me",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sporting",
        "indices" : [ 25, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "686623421426483200",
    "text" : "Has your experience at a #sporting event ever been impaired by the people around you?\nAnswer not below = PM me",
    "id" : 686623421426483200,
    "created_at" : "2016-01-11 18:59:15 +0000",
    "user" : {
      "name" : "Brigitte Mueller",
      "screen_name" : "brigittetwiits",
      "protected" : false,
      "id_str" : "3387549078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641433882869436416\/VAkjoMt8_normal.jpg",
      "id" : 3387549078,
      "verified" : false
    }
  },
  "id" : 686636003759501312,
  "created_at" : "2016-01-11 19:49:15 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 0, 15 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686624647429931008",
  "geo" : { },
  "id_str" : "686624888300281856",
  "in_reply_to_user_id" : 2467791,
  "text" : "@washingtonpost That's so heartbreaking. Nobody has right to kill anyone even your own child.",
  "id" : 686624888300281856,
  "in_reply_to_status_id" : 686624647429931008,
  "created_at" : "2016-01-11 19:05:04 +0000",
  "in_reply_to_screen_name" : "washingtonpost",
  "in_reply_to_user_id_str" : "2467791",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686623978182410240",
  "text" : "Congratulations to Lionel Messi for winning 5th Balloon D'or.",
  "id" : 686623978182410240,
  "created_at" : "2016-01-11 19:01:27 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Martian Movie",
      "screen_name" : "MartianMovie",
      "indices" : [ 3, 16 ],
      "id_str" : "2931648200",
      "id" : 2931648200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/QfwnAIFWSw",
      "expanded_url" : "https:\/\/cards.twitter.com\/cards\/18ce53za1yo\/1cn3l",
      "display_url" : "cards.twitter.com\/cards\/18ce53za\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686395492415111168",
  "text" : "RT @MartianMovie: Congrats to Matt Damon for the Golden Globes Best Actor win! Now Bring It Home. https:\/\/t.co\/QfwnAIFWSw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/QfwnAIFWSw",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/18ce53za1yo\/1cn3l",
        "display_url" : "cards.twitter.com\/cards\/18ce53za\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "686368913668476929",
    "text" : "Congrats to Matt Damon for the Golden Globes Best Actor win! Now Bring It Home. https:\/\/t.co\/QfwnAIFWSw",
    "id" : 686368913668476929,
    "created_at" : "2016-01-11 02:07:55 +0000",
    "user" : {
      "name" : "The Martian Movie",
      "screen_name" : "MartianMovie",
      "protected" : false,
      "id_str" : "2931648200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672083989767720960\/Knu-Ym_w_normal.jpg",
      "id" : 2931648200,
      "verified" : true
    }
  },
  "id" : 686395492415111168,
  "created_at" : "2016-01-11 03:53:32 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annapurna Post",
      "screen_name" : "Annapurna_Post",
      "indices" : [ 0, 15 ],
      "id_str" : "1568130360",
      "id" : 1568130360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686390409908465664",
  "geo" : { },
  "id_str" : "686394816549109760",
  "in_reply_to_user_id" : 1568130360,
  "text" : "@Annapurna_Post don't understand why it takes so long to reward national heroes",
  "id" : 686394816549109760,
  "in_reply_to_status_id" : 686390409908465664,
  "created_at" : "2016-01-11 03:50:51 +0000",
  "in_reply_to_screen_name" : "Annapurna_Post",
  "in_reply_to_user_id_str" : "1568130360",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686294202406178816",
  "text" : "Seahawks won the impossible",
  "id" : 686294202406178816,
  "created_at" : "2016-01-10 21:11:03 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SEAvsMIN",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686262776533143552",
  "text" : "Why didn't they attempt a field goal? #SEAvsMIN",
  "id" : 686262776533143552,
  "created_at" : "2016-01-10 19:06:10 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SEAvsMIN",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686257107797032963",
  "text" : "Let's go Seahawks #SEAvsMIN",
  "id" : 686257107797032963,
  "created_at" : "2016-01-10 18:43:39 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 0, 7 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686110265398571009",
  "geo" : { },
  "id_str" : "686118487106785280",
  "in_reply_to_user_id" : 558797310,
  "text" : "@ManUtd that was an awesome signing.  He was such a beast.",
  "id" : 686118487106785280,
  "in_reply_to_status_id" : 686110265398571009,
  "created_at" : "2016-01-10 09:32:49 +0000",
  "in_reply_to_screen_name" : "ManUtd",
  "in_reply_to_user_id_str" : "558797310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 0, 5 ],
      "id_str" : "14293310",
      "id" : 14293310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685981903715971072",
  "geo" : { },
  "id_str" : "685983462189207552",
  "in_reply_to_user_id" : 14293310,
  "text" : "@TIME These days all these media companies want is click to their webpages.",
  "id" : 685983462189207552,
  "in_reply_to_status_id" : 685981903715971072,
  "created_at" : "2016-01-10 00:36:16 +0000",
  "in_reply_to_screen_name" : "TIME",
  "in_reply_to_user_id_str" : "14293310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 0, 7 ],
      "id_str" : "558797310",
      "id" : 558797310
    }, {
      "name" : "Ashley Young",
      "screen_name" : "youngy18",
      "indices" : [ 19, 28 ],
      "id_str" : "1692240811",
      "id" : 1692240811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MUNvsSHEFF",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685893707246080000",
  "in_reply_to_user_id" : 558797310,
  "text" : "@ManUtd in missing @youngy18 so bad today . #MUNvsSHEFF",
  "id" : 685893707246080000,
  "created_at" : "2016-01-09 18:39:37 +0000",
  "in_reply_to_screen_name" : "ManUtd",
  "in_reply_to_user_id_str" : "558797310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 3, 6 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/XjKC3yMFOS",
      "expanded_url" : "http:\/\/apne.ws\/1n9Q86P",
      "display_url" : "apne.ws\/1n9Q86P"
    } ]
  },
  "geo" : { },
  "id_str" : "685892019571408896",
  "text" : "RT @AP: Sickening stench from natural gas leak in California has driven thousands of residents away: https:\/\/t.co\/XjKC3yMFOS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/XjKC3yMFOS",
        "expanded_url" : "http:\/\/apne.ws\/1n9Q86P",
        "display_url" : "apne.ws\/1n9Q86P"
      } ]
    },
    "geo" : { },
    "id_str" : "685891561507389440",
    "text" : "Sickening stench from natural gas leak in California has driven thousands of residents away: https:\/\/t.co\/XjKC3yMFOS",
    "id" : 685891561507389440,
    "created_at" : "2016-01-09 18:31:06 +0000",
    "user" : {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "protected" : false,
      "id_str" : "51241574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461964160838803457\/8z9FImcv_normal.png",
      "id" : 51241574,
      "verified" : true
    }
  },
  "id" : 685892019571408896,
  "created_at" : "2016-01-09 18:32:55 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 0, 3 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685891561507389440",
  "geo" : { },
  "id_str" : "685891789090242560",
  "in_reply_to_user_id" : 51241574,
  "text" : "@AP Heard it takes about a week to completely get rid of. Unfortunate part is it is not visible through naked eyes. Hoping for resolution.",
  "id" : 685891789090242560,
  "in_reply_to_status_id" : 685891561507389440,
  "created_at" : "2016-01-09 18:32:00 +0000",
  "in_reply_to_screen_name" : "AP",
  "in_reply_to_user_id_str" : "51241574",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne Rooney",
      "screen_name" : "WayneRooney",
      "indices" : [ 0, 12 ],
      "id_str" : "285332860",
      "id" : 285332860
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MUNvsSHEFF",
      "indices" : [ 32, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685887052974391296",
  "in_reply_to_user_id" : 285332860,
  "text" : "@WayneRooney seems sharp today. #MUNvsSHEFF",
  "id" : 685887052974391296,
  "created_at" : "2016-01-09 18:13:11 +0000",
  "in_reply_to_screen_name" : "WayneRooney",
  "in_reply_to_user_id_str" : "285332860",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 0, 8 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685886264487350273",
  "geo" : { },
  "id_str" : "685886403264131072",
  "in_reply_to_user_id" : 807095,
  "text" : "@nytimes Really ? My wife's and mine are different. Is that good ?",
  "id" : 685886403264131072,
  "in_reply_to_status_id" : 685886264487350273,
  "created_at" : "2016-01-09 18:10:36 +0000",
  "in_reply_to_screen_name" : "nytimes",
  "in_reply_to_user_id_str" : "807095",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 0, 7 ],
      "id_str" : "558797310",
      "id" : 558797310
    }, {
      "name" : "Juan Mata Garc\u00EDa",
      "screen_name" : "juanmata8",
      "indices" : [ 8, 18 ],
      "id_str" : "140750163",
      "id" : 140750163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685883953090301952",
  "geo" : { },
  "id_str" : "685885582413725698",
  "in_reply_to_user_id" : 558797310,
  "text" : "@ManUtd @juanmata8 The dominance in possession has given nothing so far. The way we are playing we would probably end up with a draw.",
  "id" : 685885582413725698,
  "in_reply_to_status_id" : 685883953090301952,
  "created_at" : "2016-01-09 18:07:20 +0000",
  "in_reply_to_screen_name" : "ManUtd",
  "in_reply_to_user_id_str" : "558797310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "indices" : [ 0, 12 ],
      "id_str" : "216299334",
      "id" : 216299334
    }, {
      "name" : "Arsenal FC",
      "screen_name" : "Arsenal",
      "indices" : [ 29, 37 ],
      "id_str" : "34613288",
      "id" : 34613288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685884595208847361",
  "geo" : { },
  "id_str" : "685885388976603136",
  "in_reply_to_user_id" : 216299334,
  "text" : "@piersmorgan @Ben_The_Gooner @Arsenal Of course. I am not a Arsenal fan though.",
  "id" : 685885388976603136,
  "in_reply_to_status_id" : 685884595208847361,
  "created_at" : "2016-01-09 18:06:34 +0000",
  "in_reply_to_screen_name" : "piersmorgan",
  "in_reply_to_user_id_str" : "216299334",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 0, 7 ],
      "id_str" : "558797310",
      "id" : 558797310
    }, {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 89, 96 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685861125888585728",
  "geo" : { },
  "id_str" : "685871475216125952",
  "in_reply_to_user_id" : 558797310,
  "text" : "@ManUtd while it's a good team selecting all the first team players is kind of risky. Go @ManUtd",
  "id" : 685871475216125952,
  "in_reply_to_status_id" : 685861125888585728,
  "created_at" : "2016-01-09 17:11:17 +0000",
  "in_reply_to_screen_name" : "ManUtd",
  "in_reply_to_user_id_str" : "558797310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basti Schweinsteiger",
      "screen_name" : "BSchweinsteiger",
      "indices" : [ 0, 16 ],
      "id_str" : "1283561876",
      "id" : 1283561876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685828073351200768",
  "geo" : { },
  "id_str" : "685867646919655424",
  "in_reply_to_user_id" : 1283561876,
  "text" : "@BSchweinsteiger come on Bastian let's do the business",
  "id" : 685867646919655424,
  "in_reply_to_status_id" : 685828073351200768,
  "created_at" : "2016-01-09 16:56:04 +0000",
  "in_reply_to_screen_name" : "BSchweinsteiger",
  "in_reply_to_user_id_str" : "1283561876",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 0, 9 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685766720729038848",
  "geo" : { },
  "id_str" : "685768971220471809",
  "in_reply_to_user_id" : 87818409,
  "text" : "@guardian it's so sad",
  "id" : 685768971220471809,
  "in_reply_to_status_id" : 685766720729038848,
  "created_at" : "2016-01-09 10:23:58 +0000",
  "in_reply_to_screen_name" : "guardian",
  "in_reply_to_user_id_str" : "87818409",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annapurna Post",
      "screen_name" : "Annapurna_Post",
      "indices" : [ 0, 15 ],
      "id_str" : "1568130360",
      "id" : 1568130360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685740902535544832",
  "geo" : { },
  "id_str" : "685741566527324161",
  "in_reply_to_user_id" : 1568130360,
  "text" : "@Annapurna_Post kaam kei garne hoina ... meeting garne matra ho chor haru .. don't understand why it is taking so long to resolve.",
  "id" : 685741566527324161,
  "in_reply_to_status_id" : 685740902535544832,
  "created_at" : "2016-01-09 08:35:04 +0000",
  "in_reply_to_screen_name" : "Annapurna_Post",
  "in_reply_to_user_id_str" : "1568130360",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 3, 10 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/685740807366770688\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/rkEMKZFQin",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYQ9oW5WcAA3Z5F.png",
      "id_str" : "685740806817345536",
      "id" : 685740806817345536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYQ9oW5WcAA3Z5F.png",
      "sizes" : [ {
        "h" : 1002,
        "resize" : "fit",
        "w" : 709
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 481
      }, {
        "h" : 1002,
        "resize" : "fit",
        "w" : 709
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1002,
        "resize" : "fit",
        "w" : 709
      } ],
      "display_url" : "pic.twitter.com\/rkEMKZFQin"
    } ],
    "hashtags" : [ {
      "text" : "mufc",
      "indices" : [ 42, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685741286414913537",
  "text" : "RT @ManUtd: The FA Cup journey begins for #mufc today against Sheffield United at 17:30 GMT. Come on! https:\/\/t.co\/rkEMKZFQin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.buddymedia.com\" rel=\"nofollow\"\u003EStream Publisher\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/685740807366770688\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/rkEMKZFQin",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYQ9oW5WcAA3Z5F.png",
        "id_str" : "685740806817345536",
        "id" : 685740806817345536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYQ9oW5WcAA3Z5F.png",
        "sizes" : [ {
          "h" : 1002,
          "resize" : "fit",
          "w" : 709
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 481
        }, {
          "h" : 1002,
          "resize" : "fit",
          "w" : 709
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1002,
          "resize" : "fit",
          "w" : 709
        } ],
        "display_url" : "pic.twitter.com\/rkEMKZFQin"
      } ],
      "hashtags" : [ {
        "text" : "mufc",
        "indices" : [ 30, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685740807366770688",
    "text" : "The FA Cup journey begins for #mufc today against Sheffield United at 17:30 GMT. Come on! https:\/\/t.co\/rkEMKZFQin",
    "id" : 685740807366770688,
    "created_at" : "2016-01-09 08:32:03 +0000",
    "user" : {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "protected" : false,
      "id_str" : "558797310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/934706707258904578\/7HAVD2b0_normal.jpg",
      "id" : 558797310,
      "verified" : true
    }
  },
  "id" : 685741286414913537,
  "created_at" : "2016-01-09 08:33:57 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger James Hamilton",
      "screen_name" : "rogerhamilton",
      "indices" : [ 0, 14 ],
      "id_str" : "17536486",
      "id" : 17536486
    }, {
      "name" : "Genius U",
      "screen_name" : "geniususocial",
      "indices" : [ 15, 29 ],
      "id_str" : "2904135174",
      "id" : 2904135174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685633396299665408",
  "geo" : { },
  "id_str" : "685738252943265792",
  "in_reply_to_user_id" : 17536486,
  "text" : "@rogerhamilton @geniususocial It's true.",
  "id" : 685738252943265792,
  "in_reply_to_status_id" : 685633396299665408,
  "created_at" : "2016-01-09 08:21:54 +0000",
  "in_reply_to_screen_name" : "rogerhamilton",
  "in_reply_to_user_id_str" : "17536486",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshawn Lynch",
      "screen_name" : "MarshawnLynch24",
      "indices" : [ 18, 34 ],
      "id_str" : "812185519",
      "id" : 812185519
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SEAvsMIN",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685736738195554308",
  "text" : "It's a shame that @MarshawnLynch24 cannot play on this wild card game #SEAvsMIN",
  "id" : 685736738195554308,
  "created_at" : "2016-01-09 08:15:53 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 0, 5 ],
      "id_str" : "14293310",
      "id" : 14293310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685732765891997696",
  "geo" : { },
  "id_str" : "685734084652355584",
  "in_reply_to_user_id" : 14293310,
  "text" : "@TIME Looks really stunning. Looks like colored lines on a sheet of paper.",
  "id" : 685734084652355584,
  "in_reply_to_status_id" : 685732765891997696,
  "created_at" : "2016-01-09 08:05:20 +0000",
  "in_reply_to_screen_name" : "TIME",
  "in_reply_to_user_id_str" : "14293310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lomas \u0932\u094B\u092E\u0938",
      "screen_name" : "lomaspj",
      "indices" : [ 0, 8 ],
      "id_str" : "14788193",
      "id" : 14788193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685700211281281025",
  "geo" : { },
  "id_str" : "685731368140029952",
  "in_reply_to_user_id" : 14788193,
  "text" : "@lomaspj Oli ko guff matra thulo ... kaam chai kei chaina",
  "id" : 685731368140029952,
  "in_reply_to_status_id" : 685700211281281025,
  "created_at" : "2016-01-09 07:54:33 +0000",
  "in_reply_to_screen_name" : "lomaspj",
  "in_reply_to_user_id_str" : "14788193",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "History In Pictures",
      "screen_name" : "HistoryInPix",
      "indices" : [ 0, 13 ],
      "id_str" : "1557315432",
      "id" : 1557315432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685719711309557760",
  "geo" : { },
  "id_str" : "685731041970008064",
  "in_reply_to_user_id" : 1557315432,
  "text" : "@HistoryInPix Awesome job. That's how all humans should behave.",
  "id" : 685731041970008064,
  "in_reply_to_status_id" : 685719711309557760,
  "created_at" : "2016-01-09 07:53:15 +0000",
  "in_reply_to_screen_name" : "HistoryInPix",
  "in_reply_to_user_id_str" : "1557315432",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ranveer Singh",
      "screen_name" : "RanveerOfficial",
      "indices" : [ 0, 16 ],
      "id_str" : "68497896",
      "id" : 68497896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685722086740905984",
  "geo" : { },
  "id_str" : "685730877423271936",
  "in_reply_to_user_id" : 68497896,
  "text" : "@RanveerOfficial Well deserved man. Congratulations.",
  "id" : 685730877423271936,
  "in_reply_to_status_id" : 685722086740905984,
  "created_at" : "2016-01-09 07:52:36 +0000",
  "in_reply_to_screen_name" : "RanveerOfficial",
  "in_reply_to_user_id_str" : "68497896",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UN Development",
      "screen_name" : "UNDP",
      "indices" : [ 0, 5 ],
      "id_str" : "20596281",
      "id" : 20596281
    }, {
      "name" : "UN Environment",
      "screen_name" : "UNEP",
      "indices" : [ 6, 11 ],
      "id_str" : "38146999",
      "id" : 38146999
    }, {
      "name" : "UNDP Afghanistan",
      "screen_name" : "UNDPaf",
      "indices" : [ 12, 19 ],
      "id_str" : "262680348",
      "id" : 262680348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685476245686087681",
  "geo" : { },
  "id_str" : "685614629716754432",
  "in_reply_to_user_id" : 20596281,
  "text" : "@UNDP @UNEP @UNDPaf This picture looks fantastic. Such a beautiful country so unfortunate with series of unfortunate events.",
  "id" : 685614629716754432,
  "in_reply_to_status_id" : 685476245686087681,
  "created_at" : "2016-01-09 00:10:40 +0000",
  "in_reply_to_screen_name" : "UNDP",
  "in_reply_to_user_id_str" : "20596281",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 0, 5 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685594204479737856",
  "geo" : { },
  "id_str" : "685613858371710976",
  "in_reply_to_user_id" : 11348282,
  "text" : "@NASA While there are so many casualties with ELNINO but californians must be happy. Long standing drought might be eliminated.",
  "id" : 685613858371710976,
  "in_reply_to_status_id" : 685594204479737856,
  "created_at" : "2016-01-09 00:07:36 +0000",
  "in_reply_to_screen_name" : "NASA",
  "in_reply_to_user_id_str" : "11348282",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685613583296679936",
  "text" : "RT @NASA: How is the El Nino weather phenomenon impacting California? Satellite animation shows storms over the past 3 days.\nhttps:\/\/t.co\/0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/0CClwVjWc5",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/51602b43-8c03-4e12-b8dd-a5c0db11ee4b",
        "display_url" : "amp.twimg.com\/v\/51602b43-8c0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "685594204479737856",
    "text" : "How is the El Nino weather phenomenon impacting California? Satellite animation shows storms over the past 3 days.\nhttps:\/\/t.co\/0CClwVjWc5",
    "id" : 685594204479737856,
    "created_at" : "2016-01-08 22:49:30 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 685613583296679936,
  "created_at" : "2016-01-09 00:06:30 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 0, 5 ],
      "id_str" : "14293310",
      "id" : 14293310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685612008083963904",
  "geo" : { },
  "id_str" : "685613355147472896",
  "in_reply_to_user_id" : 14293310,
  "text" : "@TIME Jon Snow.",
  "id" : 685613355147472896,
  "in_reply_to_status_id" : 685612008083963904,
  "created_at" : "2016-01-09 00:05:36 +0000",
  "in_reply_to_screen_name" : "TIME",
  "in_reply_to_user_id_str" : "14293310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 0, 7 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685561877661913089",
  "geo" : { },
  "id_str" : "685612898639458305",
  "in_reply_to_user_id" : 558797310,
  "text" : "@ManUtd Field some big names. Winning is so much important at this point for the confidence to move forward.",
  "id" : 685612898639458305,
  "in_reply_to_status_id" : 685561877661913089,
  "created_at" : "2016-01-09 00:03:47 +0000",
  "in_reply_to_screen_name" : "ManUtd",
  "in_reply_to_user_id_str" : "558797310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TED Talks",
      "screen_name" : "TEDTalks",
      "indices" : [ 0, 9 ],
      "id_str" : "15492359",
      "id" : 15492359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685575577756119041",
  "geo" : { },
  "id_str" : "685611922838847488",
  "in_reply_to_user_id" : 15492359,
  "text" : "@TEDTalks That would be in a different era. I don't think that would be happening in our time. THough I would love to see that.",
  "id" : 685611922838847488,
  "in_reply_to_status_id" : 685575577756119041,
  "created_at" : "2016-01-08 23:59:55 +0000",
  "in_reply_to_screen_name" : "TEDTalks",
  "in_reply_to_user_id_str" : "15492359",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert T. Kiyosaki",
      "screen_name" : "theRealKiyosaki",
      "indices" : [ 0, 16 ],
      "id_str" : "29856819",
      "id" : 29856819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685581756565606400",
  "geo" : { },
  "id_str" : "685611620643426304",
  "in_reply_to_user_id" : 29856819,
  "text" : "@theRealKiyosaki Rich dad is such as awesome book. Of course it is opportunities that we need to look but it is so challenging to find out.",
  "id" : 685611620643426304,
  "in_reply_to_status_id" : 685581756565606400,
  "created_at" : "2016-01-08 23:58:43 +0000",
  "in_reply_to_screen_name" : "theRealKiyosaki",
  "in_reply_to_user_id_str" : "29856819",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 0, 5 ],
      "id_str" : "14293310",
      "id" : 14293310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685589322813313024",
  "geo" : { },
  "id_str" : "685611140622073857",
  "in_reply_to_user_id" : 14293310,
  "text" : "@TIME Wow amazing.",
  "id" : 685611140622073857,
  "in_reply_to_status_id" : 685589322813313024,
  "created_at" : "2016-01-08 23:56:48 +0000",
  "in_reply_to_screen_name" : "TIME",
  "in_reply_to_user_id_str" : "14293310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tina LaBonte-Gordon",
      "screen_name" : "TinaLG_Realtor",
      "indices" : [ 0, 15 ],
      "id_str" : "4324548016",
      "id" : 4324548016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685470455155691520",
  "geo" : { },
  "id_str" : "685610427426844672",
  "in_reply_to_user_id" : 4324548016,
  "text" : "@TinaLG_Realtor @successmajor_ Sure thing. A man is known by the company he keeps. Different culture have their own proverb for this thing.",
  "id" : 685610427426844672,
  "in_reply_to_status_id" : 685470455155691520,
  "created_at" : "2016-01-08 23:53:58 +0000",
  "in_reply_to_screen_name" : "TinaLG_Realtor",
  "in_reply_to_user_id_str" : "4324548016",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furtado",
      "screen_name" : "wxjay",
      "indices" : [ 3, 9 ],
      "id_str" : "19908047",
      "id" : 19908047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685610215807397888",
  "text" : "RT @wxjay: I will be looking for grad students to work on sub-seasonal prediction and other climate dynamics projects. Stop by! https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/kDa64CpxF7",
        "expanded_url" : "https:\/\/twitter.com\/Parsons_OUMet\/status\/685549041627734016",
        "display_url" : "twitter.com\/Parsons_OUMet\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "685578761958330368",
    "text" : "I will be looking for grad students to work on sub-seasonal prediction and other climate dynamics projects. Stop by! https:\/\/t.co\/kDa64CpxF7",
    "id" : 685578761958330368,
    "created_at" : "2016-01-08 21:48:08 +0000",
    "user" : {
      "name" : "Jason Furtado",
      "screen_name" : "wxjay",
      "protected" : false,
      "id_str" : "19908047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819579087828242432\/GhPF-Jsp_normal.jpg",
      "id" : 19908047,
      "verified" : false
    }
  },
  "id" : 685610215807397888,
  "created_at" : "2016-01-08 23:53:08 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685607856947605504",
  "geo" : { },
  "id_str" : "685609710884524033",
  "in_reply_to_user_id" : 3287869802,
  "text" : "@successmajor_ Absolutely. There are still some countries out there where they cannot choose their actions.",
  "id" : 685609710884524033,
  "in_reply_to_status_id" : 685607856947605504,
  "created_at" : "2016-01-08 23:51:07 +0000",
  "in_reply_to_screen_name" : "evolutionmentor",
  "in_reply_to_user_id_str" : "3287869802",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SuccessMajor",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685609087908761600",
  "text" : "RT @successmajor_: This is our greatest power - the power to choose our actions.\n#SuccessMajor",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SuccessMajor",
        "indices" : [ 62, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685607856947605504",
    "text" : "This is our greatest power - the power to choose our actions.\n#SuccessMajor",
    "id" : 685607856947605504,
    "created_at" : "2016-01-08 23:43:45 +0000",
    "user" : {
      "name" : "Evolution Mentor",
      "screen_name" : "evolutionmentor",
      "protected" : false,
      "id_str" : "3287869802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/917463381002588161\/QQyDi3CA_normal.jpg",
      "id" : 3287869802,
      "verified" : false
    }
  },
  "id" : 685609087908761600,
  "created_at" : "2016-01-08 23:48:39 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EE",
      "indices" : [ 114, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/xSCmqoh5ph",
      "expanded_url" : "https:\/\/youtu.be\/v_Iy2DhmnDU",
      "display_url" : "youtu.be\/v_Iy2DhmnDU"
    } ]
  },
  "geo" : { },
  "id_str" : "685596957088157696",
  "text" : "RT @EFDC_Explorer: Raging Floodwater Released from Oklahoma Dam after historic flooding. https:\/\/t.co\/xSCmqoh5ph  #EE has been used to mode\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EE",
        "indices" : [ 95, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/xSCmqoh5ph",
        "expanded_url" : "https:\/\/youtu.be\/v_Iy2DhmnDU",
        "display_url" : "youtu.be\/v_Iy2DhmnDU"
      } ]
    },
    "geo" : { },
    "id_str" : "685596350914797568",
    "text" : "Raging Floodwater Released from Oklahoma Dam after historic flooding. https:\/\/t.co\/xSCmqoh5ph  #EE has been used to model Lake Tenkiller.",
    "id" : 685596350914797568,
    "created_at" : "2016-01-08 22:58:02 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 685596957088157696,
  "created_at" : "2016-01-08 23:00:27 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 76, 80 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/8FsFCfG7HH",
      "expanded_url" : "http:\/\/cnn.it\/1ZR67EJ",
      "display_url" : "cnn.it\/1ZR67EJ"
    } ]
  },
  "geo" : { },
  "id_str" : "685520958992429056",
  "text" : "ISIS fighter executes own mother in Syria for 'apostasy,' rights groups say @CNN https:\/\/t.co\/8FsFCfG7HH",
  "id" : 685520958992429056,
  "created_at" : "2016-01-08 17:58:27 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 87, 101 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFDCPLUS",
      "indices" : [ 102, 111 ]
    }, {
      "text" : "EE",
      "indices" : [ 112, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/qMXOr45BHM",
      "expanded_url" : "http:\/\/www.efdc-explorer.com\/efdc-plus\/",
      "display_url" : "efdc-explorer.com\/efdc-plus\/"
    } ]
  },
  "geo" : { },
  "id_str" : "685512488293502977",
  "text" : "A new generation of EFDC plus coming soon that integrates EFDC_DSI, EFDC_OMP, EFDC_SGZ @EFDC_Explorer #EFDCPLUS #EE https:\/\/t.co\/qMXOr45BHM",
  "id" : 685512488293502977,
  "created_at" : "2016-01-08 17:24:48 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 0, 5 ],
      "id_str" : "14293310",
      "id" : 14293310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685180374956269570",
  "geo" : { },
  "id_str" : "685202203242397696",
  "in_reply_to_user_id" : 14293310,
  "text" : "@TIME Looks pretty cool. What is the maximum speed it travels ?",
  "id" : 685202203242397696,
  "in_reply_to_status_id" : 685180374956269570,
  "created_at" : "2016-01-07 20:51:50 +0000",
  "in_reply_to_screen_name" : "TIME",
  "in_reply_to_user_id_str" : "14293310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 0, 12 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685188389692375040",
  "geo" : { },
  "id_str" : "685195771818315776",
  "in_reply_to_user_id" : 5520952,
  "text" : "@paulocoelho I don't think so. Unless you forget and let it go  you cannot get peace with that person.",
  "id" : 685195771818315776,
  "in_reply_to_status_id" : 685188389692375040,
  "created_at" : "2016-01-07 20:26:16 +0000",
  "in_reply_to_screen_name" : "paulocoelho",
  "in_reply_to_user_id_str" : "5520952",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 0, 5 ],
      "id_str" : "14293310",
      "id" : 14293310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684776452924030979",
  "geo" : { },
  "id_str" : "684782327155671040",
  "in_reply_to_user_id" : 14293310,
  "text" : "@TIME That's some interesting points.",
  "id" : 684782327155671040,
  "in_reply_to_status_id" : 684776452924030979,
  "created_at" : "2016-01-06 17:03:24 +0000",
  "in_reply_to_screen_name" : "TIME",
  "in_reply_to_user_id_str" : "14293310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 3, 8 ],
      "id_str" : "14293310",
      "id" : 14293310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/aNMym55meJ",
      "expanded_url" : "http:\/\/ti.me\/1mG1pen",
      "display_url" : "ti.me\/1mG1pen"
    } ]
  },
  "geo" : { },
  "id_str" : "684781588370948097",
  "text" : "RT @TIME: 6 things the most productive people do every day https:\/\/t.co\/aNMym55meJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/aNMym55meJ",
        "expanded_url" : "http:\/\/ti.me\/1mG1pen",
        "display_url" : "ti.me\/1mG1pen"
      } ]
    },
    "geo" : { },
    "id_str" : "684776452924030979",
    "text" : "6 things the most productive people do every day https:\/\/t.co\/aNMym55meJ",
    "id" : 684776452924030979,
    "created_at" : "2016-01-06 16:40:03 +0000",
    "user" : {
      "name" : "TIME",
      "screen_name" : "TIME",
      "protected" : false,
      "id_str" : "14293310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1700796190\/Picture_24_normal.png",
      "id" : 14293310,
      "verified" : true
    }
  },
  "id" : 684781588370948097,
  "created_at" : "2016-01-06 17:00:27 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Climate Reality",
      "screen_name" : "ClimateReality",
      "indices" : [ 3, 18 ],
      "id_str" : "16958346",
      "id" : 16958346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/cAMXQWfG8B",
      "expanded_url" : "http:\/\/bit.ly\/1PG9mdp",
      "display_url" : "bit.ly\/1PG9mdp"
    } ]
  },
  "geo" : { },
  "id_str" : "684491944404189184",
  "text" : "RT @ClimateReality: Methane is erupting from this natural gas facility at an incredible rate of 110,000 lbs\/hour https:\/\/t.co\/cAMXQWfG8B ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.crowdbooster.com\" rel=\"nofollow\"\u003ECrowdbooster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ClimateReality\/status\/684487785248636928\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/AlizK3FXpL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX_KA5aWMAEYBCa.jpg",
        "id_str" : "684487785143742465",
        "id" : 684487785143742465,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX_KA5aWMAEYBCa.jpg",
        "sizes" : [ {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/AlizK3FXpL"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/cAMXQWfG8B",
        "expanded_url" : "http:\/\/bit.ly\/1PG9mdp",
        "display_url" : "bit.ly\/1PG9mdp"
      } ]
    },
    "geo" : { },
    "id_str" : "684487785248636928",
    "text" : "Methane is erupting from this natural gas facility at an incredible rate of 110,000 lbs\/hour https:\/\/t.co\/cAMXQWfG8B https:\/\/t.co\/AlizK3FXpL",
    "id" : 684487785248636928,
    "created_at" : "2016-01-05 21:32:59 +0000",
    "user" : {
      "name" : "Climate Reality",
      "screen_name" : "ClimateReality",
      "protected" : false,
      "id_str" : "16958346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/808356177851518976\/ZxOHK5Vm_normal.jpg",
      "id" : 16958346,
      "verified" : true
    }
  },
  "id" : 684491944404189184,
  "created_at" : "2016-01-05 21:49:31 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kamil Slowikowski",
      "screen_name" : "slowkow",
      "indices" : [ 0, 8 ],
      "id_str" : "97505313",
      "id" : 97505313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684018824778264576",
  "geo" : { },
  "id_str" : "684479831581437953",
  "in_reply_to_user_id" : 97505313,
  "text" : "@slowkow May be you wanna inform users that \"stringi\" package needs to be installed first.",
  "id" : 684479831581437953,
  "in_reply_to_status_id" : 684018824778264576,
  "created_at" : "2016-01-05 21:01:23 +0000",
  "in_reply_to_screen_name" : "slowkow",
  "in_reply_to_user_id_str" : "97505313",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kamil Slowikowski",
      "screen_name" : "slowkow",
      "indices" : [ 0, 8 ],
      "id_str" : "97505313",
      "id" : 97505313
    }, {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 9, 23 ],
      "id_str" : "69133574",
      "id" : 69133574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684470325220868096",
  "geo" : { },
  "id_str" : "684473906183323648",
  "in_reply_to_user_id" : 97505313,
  "text" : "@slowkow @hadleywickham Looks awesome. I will definitely try out ggrepel.",
  "id" : 684473906183323648,
  "in_reply_to_status_id" : 684470325220868096,
  "created_at" : "2016-01-05 20:37:50 +0000",
  "in_reply_to_screen_name" : "slowkow",
  "in_reply_to_user_id_str" : "97505313",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TED Talks",
      "screen_name" : "TEDTalks",
      "indices" : [ 3, 12 ],
      "id_str" : "15492359",
      "id" : 15492359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684469877181042688",
  "text" : "RT @TEDTalks: \"For developing countries, software companies and space ships may not be as important as taps and toilets.\" https:\/\/t.co\/bRlc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/bRlcqqHgrh",
        "expanded_url" : "http:\/\/t.ted.com\/Qyd7BTV",
        "display_url" : "t.ted.com\/Qyd7BTV"
      } ]
    },
    "geo" : { },
    "id_str" : "684431499291156480",
    "text" : "\"For developing countries, software companies and space ships may not be as important as taps and toilets.\" https:\/\/t.co\/bRlcqqHgrh",
    "id" : 684431499291156480,
    "created_at" : "2016-01-05 17:49:20 +0000",
    "user" : {
      "name" : "TED Talks",
      "screen_name" : "TEDTalks",
      "protected" : false,
      "id_str" : "15492359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877631054525472768\/Xp5FAPD5_normal.jpg",
      "id" : 15492359,
      "verified" : true
    }
  },
  "id" : 684469877181042688,
  "created_at" : "2016-01-05 20:21:50 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TED Talks",
      "screen_name" : "TEDTalks",
      "indices" : [ 0, 9 ],
      "id_str" : "15492359",
      "id" : 15492359
    }, {
      "name" : "Sebastian Wernicke",
      "screen_name" : "_wernicke",
      "indices" : [ 10, 20 ],
      "id_str" : "479104841",
      "id" : 479104841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684456254056611840",
  "geo" : { },
  "id_str" : "684469792296710144",
  "in_reply_to_user_id" : 15492359,
  "text" : "@TEDTalks @_wernicke interesting perspective.",
  "id" : 684469792296710144,
  "in_reply_to_status_id" : 684456254056611840,
  "created_at" : "2016-01-05 20:21:29 +0000",
  "in_reply_to_screen_name" : "TEDTalks",
  "in_reply_to_user_id_str" : "15492359",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC Sport",
      "screen_name" : "BBCSport",
      "indices" : [ 0, 9 ],
      "id_str" : "265902729",
      "id" : 265902729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684468186507415553",
  "geo" : { },
  "id_str" : "684468651311812608",
  "in_reply_to_user_id" : 265902729,
  "text" : "@BBCSport Poor Benitez. What other words can he say ?",
  "id" : 684468651311812608,
  "in_reply_to_status_id" : 684468186507415553,
  "created_at" : "2016-01-05 20:16:57 +0000",
  "in_reply_to_screen_name" : "BBCSport",
  "in_reply_to_user_id_str" : "265902729",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UW Env. Studies",
      "screen_name" : "uwpoe",
      "indices" : [ 0, 6 ],
      "id_str" : "86197429",
      "id" : 86197429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684464716622598144",
  "geo" : { },
  "id_str" : "684465082760167425",
  "in_reply_to_user_id" : 86197429,
  "text" : "@uwpoe Thank you for your reply. I would love to get an invite in online events in future.",
  "id" : 684465082760167425,
  "in_reply_to_status_id" : 684464716622598144,
  "created_at" : "2016-01-05 20:02:47 +0000",
  "in_reply_to_screen_name" : "uwpoe",
  "in_reply_to_user_id_str" : "86197429",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UW Env. Studies",
      "screen_name" : "uwpoe",
      "indices" : [ 0, 6 ],
      "id_str" : "86197429",
      "id" : 86197429
    }, {
      "name" : "UW Environment",
      "screen_name" : "UW_CoEnv",
      "indices" : [ 7, 16 ],
      "id_str" : "386239885",
      "id" : 386239885
    }, {
      "name" : "U. of Washington",
      "screen_name" : "UW",
      "indices" : [ 17, 20 ],
      "id_str" : "27103822",
      "id" : 27103822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684445946147557376",
  "geo" : { },
  "id_str" : "684460926188175360",
  "in_reply_to_user_id" : 86197429,
  "text" : "@uwpoe @UW_CoEnv @UW Can we attend this online ? Or will you have a recorded archive ?",
  "id" : 684460926188175360,
  "in_reply_to_status_id" : 684445946147557376,
  "created_at" : "2016-01-05 19:46:16 +0000",
  "in_reply_to_screen_name" : "uwpoe",
  "in_reply_to_user_id_str" : "86197429",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zinedine Zidane ",
      "screen_name" : "ZidaneOfficial_",
      "indices" : [ 13, 29 ],
      "id_str" : "833265805",
      "id" : 833265805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684128777647951872",
  "text" : "Good luck to @ZidaneOfficial_ for Real Madrid.",
  "id" : 684128777647951872,
  "created_at" : "2016-01-04 21:46:25 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafa Benitez Web",
      "screen_name" : "rafabenitezweb",
      "indices" : [ 69, 84 ],
      "id_str" : "454862443",
      "id" : 454862443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684090248997900288",
  "text" : "Don't like the culture of Real Madrid sacking the managers so often. @rafabenitezweb didn't do a bad job.",
  "id" : 684090248997900288,
  "created_at" : "2016-01-04 19:13:19 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 19, 26 ],
      "id_str" : "558797310",
      "id" : 558797310
    }, {
      "name" : "David De Gea",
      "screen_name" : "D_DeGea",
      "indices" : [ 98, 106 ],
      "id_str" : "265982289",
      "id" : 265982289
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/janeshdev\/status\/683332698828505088\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/OcVYdeNpSa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXuvd93UQAAdwnJ.jpg",
      "id_str" : "683332697834405888",
      "id" : 683332697834405888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXuvd93UQAAdwnJ.jpg",
      "sizes" : [ {
        "h" : 432,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/OcVYdeNpSa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683332698828505088",
  "text" : "Finally a win from @ManUtd . Great performance by Martial and Young.  Good goal by Rooney.  Super @D_DeGea https:\/\/t.co\/OcVYdeNpSa",
  "id" : 683332698828505088,
  "created_at" : "2016-01-02 17:03:05 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basti Schweinsteiger",
      "screen_name" : "BSchweinsteiger",
      "indices" : [ 0, 16 ],
      "id_str" : "1283561876",
      "id" : 1283561876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682881327314677760",
  "geo" : { },
  "id_str" : "683058430983028736",
  "in_reply_to_user_id" : 1283561876,
  "text" : "@BSchweinsteiger happy new year Bastian.",
  "id" : 683058430983028736,
  "in_reply_to_status_id" : 682881327314677760,
  "created_at" : "2016-01-01 22:53:15 +0000",
  "in_reply_to_screen_name" : "BSchweinsteiger",
  "in_reply_to_user_id_str" : "1283561876",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H\u00E9ctor Beller\u00EDn",
      "screen_name" : "HectorBellerin",
      "indices" : [ 3, 18 ],
      "id_str" : "191985864",
      "id" : 191985864
    }, {
      "name" : "PUMA Football",
      "screen_name" : "pumafootball",
      "indices" : [ 21, 34 ],
      "id_str" : "88944305",
      "id" : 88944305
    }, {
      "name" : "Arsenal FC",
      "screen_name" : "Arsenal",
      "indices" : [ 37, 45 ],
      "id_str" : "34613288",
      "id" : 34613288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "evoSPEED",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683058183158407168",
  "text" : "RT @HectorBellerin: .@pumafootball x @Arsenal competition! Win a signed shirt &amp; a pair of my #evoSPEED boots. RT this tweet to enter. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PUMA Football",
        "screen_name" : "pumafootball",
        "indices" : [ 1, 14 ],
        "id_str" : "88944305",
        "id" : 88944305
      }, {
        "name" : "Arsenal FC",
        "screen_name" : "Arsenal",
        "indices" : [ 17, 25 ],
        "id_str" : "34613288",
        "id" : 34613288
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HectorBellerin\/status\/682544712671195136\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/UEA37RYfg9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXjiy53W8AAOylH.jpg",
        "id_str" : "682544707700977664",
        "id" : 682544707700977664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXjiy53W8AAOylH.jpg",
        "sizes" : [ {
          "h" : 811,
          "resize" : "fit",
          "w" : 541
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 454
        }, {
          "h" : 811,
          "resize" : "fit",
          "w" : 541
        }, {
          "h" : 811,
          "resize" : "fit",
          "w" : 541
        } ],
        "display_url" : "pic.twitter.com\/UEA37RYfg9"
      } ],
      "hashtags" : [ {
        "text" : "evoSPEED",
        "indices" : [ 77, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682544712671195136",
    "text" : ".@pumafootball x @Arsenal competition! Win a signed shirt &amp; a pair of my #evoSPEED boots. RT this tweet to enter. https:\/\/t.co\/UEA37RYfg9",
    "id" : 682544712671195136,
    "created_at" : "2015-12-31 12:51:55 +0000",
    "user" : {
      "name" : "H\u00E9ctor Beller\u00EDn",
      "screen_name" : "HectorBellerin",
      "protected" : false,
      "id_str" : "191985864",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/909738197621645312\/bHtR0QX2_normal.jpg",
      "id" : 191985864,
      "verified" : true
    }
  },
  "id" : 683058183158407168,
  "created_at" : "2016-01-01 22:52:16 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682880869686579201",
  "text" : "Happy new year to everyone around the world.",
  "id" : 682880869686579201,
  "created_at" : "2016-01-01 11:07:41 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC Sport",
      "screen_name" : "BBCSport",
      "indices" : [ 0, 9 ],
      "id_str" : "265902729",
      "id" : 265902729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682697848891129856",
  "geo" : { },
  "id_str" : "682708958000226304",
  "in_reply_to_user_id" : 265902729,
  "text" : "@BBCSport Posting different pic just to get click ?",
  "id" : 682708958000226304,
  "in_reply_to_status_id" : 682697848891129856,
  "created_at" : "2015-12-31 23:44:34 +0000",
  "in_reply_to_screen_name" : "BBCSport",
  "in_reply_to_user_id_str" : "265902729",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682708720401317888",
  "text" : "Happy new year 2016 to everyone around the world.",
  "id" : 682708720401317888,
  "created_at" : "2015-12-31 23:43:37 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC Sport",
      "screen_name" : "BBCSport",
      "indices" : [ 0, 9 ],
      "id_str" : "265902729",
      "id" : 265902729
    }, {
      "name" : "Gary Neville",
      "screen_name" : "GNev2",
      "indices" : [ 10, 16 ],
      "id_str" : "287834630",
      "id" : 287834630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682620980213100544",
  "geo" : { },
  "id_str" : "682621261407633408",
  "in_reply_to_user_id" : 265902729,
  "text" : "@BBCSport @GNev2 has a long way to go. But I think he will prevail.",
  "id" : 682621261407633408,
  "in_reply_to_status_id" : 682620980213100544,
  "created_at" : "2015-12-31 17:56:05 +0000",
  "in_reply_to_screen_name" : "BBCSport",
  "in_reply_to_user_id_str" : "265902729",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "indices" : [ 0, 12 ],
      "id_str" : "216299334",
      "id" : 216299334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682617129741385728",
  "in_reply_to_user_id" : 216299334,
  "text" : "@piersmorgan where do you rank Ozil and Sanchez ?",
  "id" : 682617129741385728,
  "created_at" : "2015-12-31 17:39:40 +0000",
  "in_reply_to_screen_name" : "piersmorgan",
  "in_reply_to_user_id_str" : "216299334",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]