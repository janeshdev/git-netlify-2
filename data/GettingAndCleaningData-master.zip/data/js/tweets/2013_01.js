Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292796060013834240",
  "text" : "Finally Barcelona got beaten.",
  "id" : 292796060013834240,
  "created_at" : "2013-01-20 00:49:55 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shiraj Pokharel",
      "screen_name" : "ShirajPokharel",
      "indices" : [ 0, 15 ],
      "id_str" : "25052176",
      "id" : 25052176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291578266966441984",
  "geo" : { },
  "id_str" : "291629090841178113",
  "in_reply_to_user_id" : 25052176,
  "text" : "@ShirajPokharel that was little bit shocking. I thought he was coming to England.",
  "id" : 291629090841178113,
  "in_reply_to_status_id" : 291578266966441984,
  "created_at" : "2013-01-16 19:32:48 +0000",
  "in_reply_to_screen_name" : "ShirajPokharel",
  "in_reply_to_user_id_str" : "25052176",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "indices" : [ 3, 15 ],
      "id_str" : "216299334",
      "id" : 216299334
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CNN",
      "indices" : [ 130, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291411825227087872",
  "text" : "RT @piersmorgan: BREAKING: 2nd school shooting in America today - 2 reportedly dead, 1 wounded, at community college in Kentucky. #CNN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CNN",
        "indices" : [ 113, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291348648128815105",
    "text" : "BREAKING: 2nd school shooting in America today - 2 reportedly dead, 1 wounded, at community college in Kentucky. #CNN",
    "id" : 291348648128815105,
    "created_at" : "2013-01-16 00:58:25 +0000",
    "user" : {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "protected" : false,
      "id_str" : "216299334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870221940690124801\/Uiu7aejS_normal.jpg",
      "id" : 216299334,
      "verified" : true
    }
  },
  "id" : 291411825227087872,
  "created_at" : "2013-01-16 05:09:27 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "indices" : [ 0, 12 ],
      "id_str" : "216299334",
      "id" : 216299334
    }, {
      "name" : "Paddy Power",
      "screen_name" : "paddypower",
      "indices" : [ 13, 24 ],
      "id_str" : "14387275",
      "id" : 14387275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287156588781924352",
  "geo" : { },
  "id_str" : "287650111805329408",
  "in_reply_to_user_id" : 216299334,
  "text" : "@piersmorgan @paddypower I think Rafael is far better than Sagna",
  "id" : 287650111805329408,
  "in_reply_to_status_id" : 287156588781924352,
  "created_at" : "2013-01-05 20:01:45 +0000",
  "in_reply_to_screen_name" : "piersmorgan",
  "in_reply_to_user_id_str" : "216299334",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "indices" : [ 0, 12 ],
      "id_str" : "216299334",
      "id" : 216299334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287600348724617216",
  "geo" : { },
  "id_str" : "287649251331297281",
  "in_reply_to_user_id" : 216299334,
  "text" : "@piersmorgan yes definitely he is a fantastic player",
  "id" : 287649251331297281,
  "in_reply_to_status_id" : 287600348724617216,
  "created_at" : "2013-01-05 19:58:20 +0000",
  "in_reply_to_screen_name" : "piersmorgan",
  "in_reply_to_user_id_str" : "216299334",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "indices" : [ 0, 12 ],
      "id_str" : "216299334",
      "id" : 216299334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287642685723013120",
  "geo" : { },
  "id_str" : "287648911085146112",
  "in_reply_to_user_id" : 216299334,
  "text" : "@piersmorgan lack of ambition of Arsenal is the reason for losing its best players",
  "id" : 287648911085146112,
  "in_reply_to_status_id" : 287642685723013120,
  "created_at" : "2013-01-05 19:56:59 +0000",
  "in_reply_to_screen_name" : "piersmorgan",
  "in_reply_to_user_id_str" : "216299334",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujan Baral",
      "screen_name" : "baralsujan",
      "indices" : [ 0, 11 ],
      "id_str" : "18218149",
      "id" : 18218149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286871157246943232",
  "geo" : { },
  "id_str" : "287645796676014080",
  "in_reply_to_user_id" : 18218149,
  "text" : "@baralsujan Nice time lapse videos indeed.",
  "id" : 287645796676014080,
  "in_reply_to_status_id" : 286871157246943232,
  "created_at" : "2013-01-05 19:44:36 +0000",
  "in_reply_to_screen_name" : "baralsujan",
  "in_reply_to_user_id_str" : "18218149",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287645072663650304",
  "text" : "Fantastic Equalizer by Van Persie. Give him just one chance and see the magic.",
  "id" : 287645072663650304,
  "created_at" : "2013-01-05 19:41:44 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]