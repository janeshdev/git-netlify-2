Grailbird.data.tweets_2015_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/DepA3fKIhX",
      "expanded_url" : "http:\/\/www.panempropaganda.com\/movie-countdown\/2015\/11\/24\/giveaway-enter-for-a-chance-to-win-imax-tickets-to-see-the-h.html\/?utm_content=buffer38e0e&utm_medium=social&utm_source=facebook.com&utm_campaign=buffer",
      "display_url" : "panempropaganda.com\/movie-countdow\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670014530794033152",
  "text" : "Enter for a chance to win IMAX\u00AE tickets to see The Hunger Games: Mockingjay Part 2 The IMAX Experience &amp; 2 posters https:\/\/t.co\/DepA3fKIhX",
  "id" : 670014530794033152,
  "created_at" : "2015-11-26 23:01:27 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maz Bonafide",
      "screen_name" : "MazBONAFIDE",
      "indices" : [ 3, 15 ],
      "id_str" : "51734182",
      "id" : 51734182
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAttack",
      "indices" : [ 75, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665801405106491398",
  "text" : "RT @MazBONAFIDE: My name is Maz Hussain Raja. I am a Muslim. I condemn the #ParisAttack. Over 1.5 billion Muslims do. \n\nPlease remember thi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ParisAttack",
        "indices" : [ 58, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665326061874364416",
    "text" : "My name is Maz Hussain Raja. I am a Muslim. I condemn the #ParisAttack. Over 1.5 billion Muslims do. \n\nPlease remember this.",
    "id" : 665326061874364416,
    "created_at" : "2015-11-14 00:31:08 +0000",
    "user" : {
      "name" : "Maz Bonafide",
      "screen_name" : "MazBONAFIDE",
      "protected" : false,
      "id_str" : "51734182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/849890146300416000\/hVOwQI4P_normal.jpg",
      "id" : 51734182,
      "verified" : true
    }
  },
  "id" : 665801405106491398,
  "created_at" : "2015-11-15 07:59:59 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Walsh",
      "screen_name" : "WalshFreedom",
      "indices" : [ 0, 13 ],
      "id_str" : "236487888",
      "id" : 236487888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665297436261355521",
  "geo" : { },
  "id_str" : "665801249674018816",
  "in_reply_to_user_id" : 236487888,
  "text" : "@WalshFreedom What are you trying to say ? Islam didn't do this. Remember the difference between ISIS and Islam. Don't just spit words.",
  "id" : 665801249674018816,
  "in_reply_to_status_id" : 665297436261355521,
  "created_at" : "2015-11-15 07:59:22 +0000",
  "in_reply_to_screen_name" : "WalshFreedom",
  "in_reply_to_user_id_str" : "236487888",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]