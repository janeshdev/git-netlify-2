Grailbird.data.tweets_2016_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFDC",
      "indices" : [ 137, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/SPm401efnw",
      "expanded_url" : "http:\/\/www.efdc-explorer.com\/efdc-explorer",
      "display_url" : "efdc-explorer.com\/efdc-explorer"
    } ]
  },
  "geo" : { },
  "id_str" : "754041336693526528",
  "text" : "RT @EFDC_Explorer: EE8.1 is now available with new SEDZLJ Sediment Model Display &amp; Offline\/Dongle Activation https:\/\/t.co\/SPm401efnw #EFDC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EFDC",
        "indices" : [ 118, 123 ]
      }, {
        "text" : "hydrodynamic",
        "indices" : [ 124, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/SPm401efnw",
        "expanded_url" : "http:\/\/www.efdc-explorer.com\/efdc-explorer",
        "display_url" : "efdc-explorer.com\/efdc-explorer"
      } ]
    },
    "geo" : { },
    "id_str" : "753970557973106688",
    "text" : "EE8.1 is now available with new SEDZLJ Sediment Model Display &amp; Offline\/Dongle Activation https:\/\/t.co\/SPm401efnw #EFDC #hydrodynamic",
    "id" : 753970557973106688,
    "created_at" : "2016-07-15 15:12:43 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 754041336693526528,
  "created_at" : "2016-07-15 19:53:58 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754041325184364544",
  "text" : "RT @EFDC_Explorer: Current EE8 users or those with active maintenance, download 8.1 now at no cost. To upgrade from an older version, conta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753971211105923072",
    "text" : "Current EE8 users or those with active maintenance, download 8.1 now at no cost. To upgrade from an older version, contact us for a quote.",
    "id" : 753971211105923072,
    "created_at" : "2016-07-15 15:15:19 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 754041325184364544,
  "created_at" : "2016-07-15 19:53:55 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754041271862210560",
  "text" : "RT @EFDC_Explorer: Join our free training on EFDC_Explorer\/EFDC+ Modeling System led by developer Paul Craig. Edmonds, WA 12-16 Sept https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/o9QUD8YxCp",
        "expanded_url" : "http:\/\/www.efdc-explorer.com\/support\/training.html",
        "display_url" : "efdc-explorer.com\/support\/traini\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743885022881583104",
    "text" : "Join our free training on EFDC_Explorer\/EFDC+ Modeling System led by developer Paul Craig. Edmonds, WA 12-16 Sept https:\/\/t.co\/o9QUD8YxCp",
    "id" : 743885022881583104,
    "created_at" : "2016-06-17 19:16:24 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 754041271862210560,
  "created_at" : "2016-07-15 19:53:43 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]