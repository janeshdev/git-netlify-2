Grailbird.data.tweets_2015_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Climate Reality",
      "screen_name" : "ClimateReality",
      "indices" : [ 3, 18 ],
      "id_str" : "16958346",
      "id" : 16958346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/fbEzibq0tn",
      "expanded_url" : "http:\/\/nyti.ms\/1QXlhoS",
      "display_url" : "nyti.ms\/1QXlhoS"
    } ]
  },
  "geo" : { },
  "id_str" : "682421307221217280",
  "text" : "RT @ClimateReality: Wow. November 2015 was the seventh month in a row to break a global temperature record https:\/\/t.co\/fbEzibq0tn https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.crowdbooster.com\" rel=\"nofollow\"\u003ECrowdbooster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ClimateReality\/status\/682413867956318209\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/t0wUSFIwb6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXhrzA5WEAAgxiU.jpg",
        "id_str" : "682413867704651776",
        "id" : 682413867704651776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXhrzA5WEAAgxiU.jpg",
        "sizes" : [ {
          "h" : 403,
          "resize" : "fit",
          "w" : 642
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 642
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 642
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 642
        } ],
        "display_url" : "pic.twitter.com\/t0wUSFIwb6"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/fbEzibq0tn",
        "expanded_url" : "http:\/\/nyti.ms\/1QXlhoS",
        "display_url" : "nyti.ms\/1QXlhoS"
      } ]
    },
    "geo" : { },
    "id_str" : "682413867956318209",
    "text" : "Wow. November 2015 was the seventh month in a row to break a global temperature record https:\/\/t.co\/fbEzibq0tn https:\/\/t.co\/t0wUSFIwb6",
    "id" : 682413867956318209,
    "created_at" : "2015-12-31 04:11:59 +0000",
    "user" : {
      "name" : "Climate Reality",
      "screen_name" : "ClimateReality",
      "protected" : false,
      "id_str" : "16958346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/808356177851518976\/ZxOHK5Vm_normal.jpg",
      "id" : 16958346,
      "verified" : true
    }
  },
  "id" : 682421307221217280,
  "created_at" : "2015-12-31 04:41:33 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Climate Reality",
      "screen_name" : "ClimateReality",
      "indices" : [ 3, 18 ],
      "id_str" : "16958346",
      "id" : 16958346
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ClimateReality\/status\/682323775917023232\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/7YTkhVi7cV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXgZ2-TWQAAltAA.jpg",
      "id_str" : "682323775774408704",
      "id" : 682323775774408704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXgZ2-TWQAAltAA.jpg",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/7YTkhVi7cV"
    } ],
    "hashtags" : [ {
      "text" : "PutSolarOnIt",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682338759812067328",
  "text" : "RT @ClimateReality: When there\u2019s a huge solar energy spill, it\u2019s just called \"a nice day.\" #PutSolarOnIt https:\/\/t.co\/7YTkhVi7cV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.crowdbooster.com\" rel=\"nofollow\"\u003ECrowdbooster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ClimateReality\/status\/682323775917023232\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/7YTkhVi7cV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXgZ2-TWQAAltAA.jpg",
        "id_str" : "682323775774408704",
        "id" : 682323775774408704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXgZ2-TWQAAltAA.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/7YTkhVi7cV"
      } ],
      "hashtags" : [ {
        "text" : "PutSolarOnIt",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682323775917023232",
    "text" : "When there\u2019s a huge solar energy spill, it\u2019s just called \"a nice day.\" #PutSolarOnIt https:\/\/t.co\/7YTkhVi7cV",
    "id" : 682323775917023232,
    "created_at" : "2015-12-30 22:13:59 +0000",
    "user" : {
      "name" : "Climate Reality",
      "screen_name" : "ClimateReality",
      "protected" : false,
      "id_str" : "16958346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/808356177851518976\/ZxOHK5Vm_normal.jpg",
      "id" : 16958346,
      "verified" : true
    }
  },
  "id" : 682338759812067328,
  "created_at" : "2015-12-30 23:13:32 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 109, 116 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manutdvschelsea",
      "indices" : [ 117, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681541106312417280",
  "text" : "A good first half performance by Red devils. Unlucky that they didn't score. More of the same in second half @ManUtd #manutdvschelsea",
  "id" : 681541106312417280,
  "created_at" : "2015-12-28 18:23:56 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 3, 10 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mufc",
      "indices" : [ 12, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681522090369941504",
  "text" : "RT @ManUtd: #mufc XI: De Gea, Darmian, Smalling, Blind, Young, Schneiderlin, Schweinsteiger, Mata, Herrera, Martial, Rooney. https:\/\/t.co\/J\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/681512471824302080\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/JLWbsjhJwU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXU3-z9WsAAmMp4.jpg",
        "id_str" : "681512470855462912",
        "id" : 681512470855462912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXU3-z9WsAAmMp4.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 481
        }, {
          "h" : 1002,
          "resize" : "fit",
          "w" : 709
        }, {
          "h" : 1002,
          "resize" : "fit",
          "w" : 709
        }, {
          "h" : 1002,
          "resize" : "fit",
          "w" : 709
        } ],
        "display_url" : "pic.twitter.com\/JLWbsjhJwU"
      } ],
      "hashtags" : [ {
        "text" : "mufc",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "681512471824302080",
    "text" : "#mufc XI: De Gea, Darmian, Smalling, Blind, Young, Schneiderlin, Schweinsteiger, Mata, Herrera, Martial, Rooney. https:\/\/t.co\/JLWbsjhJwU",
    "id" : 681512471824302080,
    "created_at" : "2015-12-28 16:30:09 +0000",
    "user" : {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "protected" : false,
      "id_str" : "558797310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/934706707258904578\/7HAVD2b0_normal.jpg",
      "id" : 558797310,
      "verified" : true
    }
  },
  "id" : 681522090369941504,
  "created_at" : "2015-12-28 17:08:23 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680693432017264640",
  "text" : "RT @paulocoelho: When sharing your problems with others:\n5% will help, \n15% will not care\n80% will be happy you have them",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "680593132094943232",
    "text" : "When sharing your problems with others:\n5% will help, \n15% will not care\n80% will be happy you have them",
    "id" : 680593132094943232,
    "created_at" : "2015-12-26 03:37:02 +0000",
    "user" : {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "protected" : false,
      "id_str" : "5520952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791423363797377024\/svEXr6X8_normal.jpg",
      "id" : 5520952,
      "verified" : true
    }
  },
  "id" : 680693432017264640,
  "created_at" : "2015-12-26 10:15:35 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lomas \u0932\u094B\u092E\u0938",
      "screen_name" : "lomaspj",
      "indices" : [ 3, 11 ],
      "id_str" : "14788193",
      "id" : 14788193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678829721342205952",
  "text" : "RT @lomaspj: RIP Padam Sir! I still remember the orientation class given by you in Pulchowk Campus.. sad that you are no more... https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/1rOPvbuLJu",
        "expanded_url" : "http:\/\/fb.me\/70UDaxeUh",
        "display_url" : "fb.me\/70UDaxeUh"
      } ]
    },
    "geo" : { },
    "id_str" : "678429493267066881",
    "text" : "RIP Padam Sir! I still remember the orientation class given by you in Pulchowk Campus.. sad that you are no more... https:\/\/t.co\/1rOPvbuLJu",
    "id" : 678429493267066881,
    "created_at" : "2015-12-20 04:19:30 +0000",
    "user" : {
      "name" : "lomas \u0932\u094B\u092E\u0938",
      "screen_name" : "lomaspj",
      "protected" : false,
      "id_str" : "14788193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494970766580936705\/CXhAC46q_normal.jpeg",
      "id" : 14788193,
      "verified" : false
    }
  },
  "id" : 678829721342205952,
  "created_at" : "2015-12-21 06:49:52 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ranveer Singh",
      "screen_name" : "RanveerOfficial",
      "indices" : [ 29, 45 ],
      "id_str" : "68497896",
      "id" : 68497896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BajiraoMastani",
      "indices" : [ 81, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678829442026704896",
  "text" : "A brilliant performance from @RanveerOfficial in Bajirao Mastani . Awesome movie #BajiraoMastani",
  "id" : 678829442026704896,
  "created_at" : "2015-12-21 06:48:45 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VanGaalOut",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678303097475608576",
  "text" : "Disappointing display from United.  #VanGaalOut",
  "id" : 678303097475608576,
  "created_at" : "2015-12-19 19:57:15 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sky Sports Football",
      "screen_name" : "SkyFootball",
      "indices" : [ 3, 15 ],
      "id_str" : "443668407",
      "id" : 443668407
    }, {
      "name" : "Wayne Rooney",
      "screen_name" : "WayneRooney",
      "indices" : [ 22, 34 ],
      "id_str" : "285332860",
      "id" : 285332860
    }, {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 62, 69 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/phd1nzFZfD",
      "expanded_url" : "http:\/\/skysports.tv\/8WxqaS",
      "display_url" : "skysports.tv\/8WxqaS"
    } ]
  },
  "geo" : { },
  "id_str" : "677950302104907776",
  "text" : "RT @SkyFootball: With @WayneRooney set to make play his 500th @ManUtd game, we look at his career in numbers: https:\/\/t.co\/phd1nzFZfD https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wayne Rooney",
        "screen_name" : "WayneRooney",
        "indices" : [ 5, 17 ],
        "id_str" : "285332860",
        "id" : 285332860
      }, {
        "name" : "Manchester United",
        "screen_name" : "ManUtd",
        "indices" : [ 45, 52 ],
        "id_str" : "558797310",
        "id" : 558797310
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SkyFootball\/status\/677833646758363136\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/RjaVsyp60h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWgmHBtVAAAppGy.jpg",
        "id_str" : "677833646078754816",
        "id" : 677833646078754816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWgmHBtVAAAppGy.jpg",
        "sizes" : [ {
          "h" : 432,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/RjaVsyp60h"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/phd1nzFZfD",
        "expanded_url" : "http:\/\/skysports.tv\/8WxqaS",
        "display_url" : "skysports.tv\/8WxqaS"
      } ]
    },
    "geo" : { },
    "id_str" : "677833646758363136",
    "text" : "With @WayneRooney set to make play his 500th @ManUtd game, we look at his career in numbers: https:\/\/t.co\/phd1nzFZfD https:\/\/t.co\/RjaVsyp60h",
    "id" : 677833646758363136,
    "created_at" : "2015-12-18 12:51:49 +0000",
    "user" : {
      "name" : "Sky Sports PL",
      "screen_name" : "SkySportsPL",
      "protected" : false,
      "id_str" : "713993413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933810750560317440\/-RcnuxRi_normal.jpg",
      "id" : 713993413,
      "verified" : true
    }
  },
  "id" : 677950302104907776,
  "created_at" : "2015-12-18 20:35:22 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]