Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ManUtd",
      "indices" : [ 38, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428284844028608513",
  "text" : "Finally a comfortable win for United. #ManUtd",
  "id" : 428284844028608513,
  "created_at" : "2014-01-28 21:53:58 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manutd",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428242488294268928",
  "text" : "Excited for today's match. Very eager to see Rooney, Mata, Van Persie, and Januzaj on the same match. #manutd",
  "id" : 428242488294268928,
  "created_at" : "2014-01-28 19:05:40 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428234564167684096",
  "text" : "I.wonder why United didn't go for Cabaye. He went for a mere 20 million.",
  "id" : 428234564167684096,
  "created_at" : "2014-01-28 18:34:10 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chhabi Adhikari",
      "screen_name" : "adhikarichhabi",
      "indices" : [ 0, 15 ],
      "id_str" : "837795091",
      "id" : 837795091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428165687350009856",
  "geo" : { },
  "id_str" : "428211646620647424",
  "in_reply_to_user_id" : 837795091,
  "text" : "@adhikarichhabi Tyehai ta maile hijo socheko thiye. Jhoor bhayecha ta.",
  "id" : 428211646620647424,
  "in_reply_to_status_id" : 428165687350009856,
  "created_at" : "2014-01-28 17:03:07 +0000",
  "in_reply_to_screen_name" : "adhikarichhabi",
  "in_reply_to_user_id_str" : "837795091",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chhabi Adhikari",
      "screen_name" : "adhikarichhabi",
      "indices" : [ 0, 15 ],
      "id_str" : "837795091",
      "id" : 837795091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427439834773217280",
  "geo" : { },
  "id_str" : "427811730626867202",
  "in_reply_to_user_id" : 837795091,
  "text" : "@adhikarichhabi la badhai cha. Good luck.",
  "id" : 427811730626867202,
  "in_reply_to_status_id" : 427439834773217280,
  "created_at" : "2014-01-27 14:33:59 +0000",
  "in_reply_to_screen_name" : "adhikarichhabi",
  "in_reply_to_user_id_str" : "837795091",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Stanimal",
      "indices" : [ 8, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427360063322193920",
  "text" : "Come on #Stanimal Wawrinka",
  "id" : 427360063322193920,
  "created_at" : "2014-01-26 08:39:13 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LetsTalkTennis",
      "screen_name" : "letstalktennis1",
      "indices" : [ 3, 19 ],
      "id_str" : "1047611400",
      "id" : 1047611400
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/letstalktennis1\/status\/427127226652721153\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/vdMyH7XvXe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Be118wmIUAAHGHh.jpg",
      "id_str" : "427127226367496192",
      "id" : 427127226367496192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be118wmIUAAHGHh.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/vdMyH7XvXe"
    } ],
    "hashtags" : [ {
      "text" : "SupportStan",
      "indices" : [ 53, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427321674611314688",
  "text" : "RT @letstalktennis1: Show your support for Stan with #SupportStan http:\/\/t.co\/vdMyH7XvXe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/letstalktennis1\/status\/427127226652721153\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/vdMyH7XvXe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Be118wmIUAAHGHh.jpg",
        "id_str" : "427127226367496192",
        "id" : 427127226367496192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be118wmIUAAHGHh.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/vdMyH7XvXe"
      } ],
      "hashtags" : [ {
        "text" : "SupportStan",
        "indices" : [ 32, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427127226652721153",
    "text" : "Show your support for Stan with #SupportStan http:\/\/t.co\/vdMyH7XvXe",
    "id" : 427127226652721153,
    "created_at" : "2014-01-25 17:14:01 +0000",
    "user" : {
      "name" : "LetsTalkTennis",
      "screen_name" : "letstalktennis1",
      "protected" : false,
      "id_str" : "1047611400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638462796657766400\/aaqzP5T1_normal.jpg",
      "id" : 1047611400,
      "verified" : false
    }
  },
  "id" : 427321674611314688,
  "created_at" : "2014-01-26 06:06:41 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JM",
      "screen_name" : "juanmata10",
      "indices" : [ 0, 11 ],
      "id_str" : "2313722569",
      "id" : 2313722569
    }, {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 12, 19 ],
      "id_str" : "558797310",
      "id" : 558797310
    }, {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 42, 49 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427208629314285568",
  "geo" : { },
  "id_str" : "427213788337553408",
  "in_reply_to_user_id" : 140750163,
  "text" : "@juanmata10 @ManUtd Welcome to Manchester @ManUtd",
  "id" : 427213788337553408,
  "in_reply_to_status_id" : 427208629314285568,
  "created_at" : "2014-01-25 22:57:59 +0000",
  "in_reply_to_screen_name" : "juanmata8",
  "in_reply_to_user_id_str" : "140750163",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JM",
      "screen_name" : "juanmata10",
      "indices" : [ 3, 14 ],
      "id_str" : "2313722569",
      "id" : 2313722569
    }, {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 55, 62 ],
      "id_str" : "558797310",
      "id" : 558797310
    }, {
      "name" : "Manchester United",
      "screen_name" : "ManUtd_Es",
      "indices" : [ 105, 115 ],
      "id_str" : "1613095693",
      "id" : 1613095693
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/juanmata10\/status\/427203164735950851\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Jhu1iW8GIU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Be27A9GCUAAeQv_.jpg",
      "id_str" : "427203164744339456",
      "id" : 427203164744339456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be27A9GCUAAeQv_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1833,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1833,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1074,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Jhu1iW8GIU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427213657479864320",
  "text" : "RT @juanmata10: I can confirm that I'm a new player of @ManUtd. Os confirmo que ya soy nuevo jugador del @ManUtd_Es http:\/\/t.co\/Jhu1iW8GIU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Manchester United",
        "screen_name" : "ManUtd",
        "indices" : [ 39, 46 ],
        "id_str" : "558797310",
        "id" : 558797310
      }, {
        "name" : "Manchester United",
        "screen_name" : "ManUtd_Es",
        "indices" : [ 89, 99 ],
        "id_str" : "1613095693",
        "id" : 1613095693
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/juanmata10\/status\/427203164735950851\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/Jhu1iW8GIU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Be27A9GCUAAeQv_.jpg",
        "id_str" : "427203164744339456",
        "id" : 427203164744339456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be27A9GCUAAeQv_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 609,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1833,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1833,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1074,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Jhu1iW8GIU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427203164735950851",
    "text" : "I can confirm that I'm a new player of @ManUtd. Os confirmo que ya soy nuevo jugador del @ManUtd_Es http:\/\/t.co\/Jhu1iW8GIU",
    "id" : 427203164735950851,
    "created_at" : "2014-01-25 22:15:46 +0000",
    "user" : {
      "name" : "Juan Mata Garc\u00EDa",
      "screen_name" : "juanmata8",
      "protected" : false,
      "id_str" : "140750163",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724687712159162370\/wyFcOj1s_normal.jpg",
      "id" : 140750163,
      "verified" : true
    }
  },
  "id" : 427213657479864320,
  "created_at" : "2014-01-25 22:57:27 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "indices" : [ 0, 12 ],
      "id_str" : "216299334",
      "id" : 216299334
    }, {
      "name" : "Chris Gayle",
      "screen_name" : "henrygayle",
      "indices" : [ 13, 24 ],
      "id_str" : "45452226",
      "id" : 45452226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418692111584616449",
  "geo" : { },
  "id_str" : "418839084677623808",
  "in_reply_to_user_id" : 216299334,
  "text" : "@piersmorgan @henrygayle What has Arsenal won in the last 9 years and you are speaking BS .",
  "id" : 418839084677623808,
  "in_reply_to_status_id" : 418692111584616449,
  "created_at" : "2014-01-02 20:19:54 +0000",
  "in_reply_to_screen_name" : "piersmorgan",
  "in_reply_to_user_id_str" : "216299334",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]