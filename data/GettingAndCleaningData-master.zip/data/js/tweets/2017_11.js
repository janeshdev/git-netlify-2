Grailbird.data.tweets_2017_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison Hill",
      "screen_name" : "apreshill",
      "indices" : [ 3, 13 ],
      "id_str" : "3199856542",
      "id" : 3199856542
    }, {
      "name" : "Yihui Xie",
      "screen_name" : "xieyihui",
      "indices" : [ 34, 43 ],
      "id_str" : "39010299",
      "id" : 39010299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "xaringan",
      "indices" : [ 54, 63 ]
    }, {
      "text" : "rstats",
      "indices" : [ 76, 83 ]
    }, {
      "text" : "Rladies",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "936008246904594432",
  "text" : "RT @apreshill: if you want to use @xieyihui's awesome #xaringan package for #rstats slides but want more #Rladies flavor, there is now a bu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yihui Xie",
        "screen_name" : "xieyihui",
        "indices" : [ 19, 28 ],
        "id_str" : "39010299",
        "id" : 39010299
      }, {
        "name" : "R-Ladies Global",
        "screen_name" : "RLadiesGlobal",
        "indices" : [ 194, 208 ],
        "id_str" : "770490229769789440",
        "id" : 770490229769789440
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/apreshill\/status\/935973869554487296\/photo\/1",
        "indices" : [ 268, 291 ],
        "url" : "https:\/\/t.co\/YnlGSVAMsl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DP0-lIQVwAARHV5.jpg",
        "id_str" : "935973105155031040",
        "id" : 935973105155031040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DP0-lIQVwAARHV5.jpg",
        "sizes" : [ {
          "h" : 314,
          "resize" : "fit",
          "w" : 662
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 662
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 662
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 662
        } ],
        "display_url" : "pic.twitter.com\/YnlGSVAMsl"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/apreshill\/status\/935973869554487296\/photo\/1",
        "indices" : [ 268, 291 ],
        "url" : "https:\/\/t.co\/YnlGSVAMsl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DP0-mbvU8AElDce.jpg",
        "id_str" : "935973127565144065",
        "id" : 935973127565144065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DP0-mbvU8AElDce.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 729
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 729
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 729
        } ],
        "display_url" : "pic.twitter.com\/YnlGSVAMsl"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/apreshill\/status\/935973869554487296\/photo\/1",
        "indices" : [ 268, 291 ],
        "url" : "https:\/\/t.co\/YnlGSVAMsl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DP0-n29V4AUmjWp.jpg",
        "id_str" : "935973152051552261",
        "id" : 935973152051552261,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DP0-n29V4AUmjWp.jpg",
        "sizes" : [ {
          "h" : 452,
          "resize" : "fit",
          "w" : 649
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 649
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 649
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 649
        } ],
        "display_url" : "pic.twitter.com\/YnlGSVAMsl"
      } ],
      "hashtags" : [ {
        "text" : "xaringan",
        "indices" : [ 39, 48 ]
      }, {
        "text" : "rstats",
        "indices" : [ 61, 68 ]
      }, {
        "text" : "Rladies",
        "indices" : [ 90, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "935973869554487296",
    "text" : "if you want to use @xieyihui's awesome #xaringan package for #rstats slides but want more #Rladies flavor, there is now a built-in theme for that (with code highlighting)! Thanks to the awesome @RLadiesGlobal starter kit. Update the CSS in your YAML to use  \uD83E\uDDD9\uD83C\uDFFD\u200D\u2640\uFE0F\uD83E\uDDDE\u200D\u2640\uFE0F https:\/\/t.co\/YnlGSVAMsl",
    "id" : 935973869554487296,
    "created_at" : "2017-11-29 20:48:54 +0000",
    "user" : {
      "name" : "Alison Hill",
      "screen_name" : "apreshill",
      "protected" : false,
      "id_str" : "3199856542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875831653297303552\/71gkhnO0_normal.jpg",
      "id" : 3199856542,
      "verified" : false
    }
  },
  "id" : 936008246904594432,
  "created_at" : "2017-11-29 23:05:30 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ipfconline",
      "screen_name" : "ipfconline1",
      "indices" : [ 3, 15 ],
      "id_str" : "705539763349164032",
      "id" : 705539763349164032
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ipfconline1\/status\/935810722067599360\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/RUtJ5yRFwI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPyq5CiVoAA0vLl.jpg",
      "id_str" : "935810719496380416",
      "id" : 935810719496380416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPyq5CiVoAA0vLl.jpg",
      "sizes" : [ {
        "h" : 744,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/RUtJ5yRFwI"
    } ],
    "hashtags" : [ {
      "text" : "Bitcoin",
      "indices" : [ 21, 29 ]
    }, {
      "text" : "Fintech",
      "indices" : [ 50, 58 ]
    }, {
      "text" : "Blockchain",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "936002314325782528",
  "text" : "RT @ipfconline1: How #Bitcoin Works [Infographic]\n#Fintech #Blockchain https:\/\/t.co\/RUtJ5yRFwI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ipfconline1\/status\/935810722067599360\/photo\/1",
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/RUtJ5yRFwI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DPyq5CiVoAA0vLl.jpg",
        "id_str" : "935810719496380416",
        "id" : 935810719496380416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPyq5CiVoAA0vLl.jpg",
        "sizes" : [ {
          "h" : 744,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 744,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 744,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 460,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/RUtJ5yRFwI"
      } ],
      "hashtags" : [ {
        "text" : "Bitcoin",
        "indices" : [ 4, 12 ]
      }, {
        "text" : "Fintech",
        "indices" : [ 33, 41 ]
      }, {
        "text" : "Blockchain",
        "indices" : [ 42, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "935810722067599360",
    "text" : "How #Bitcoin Works [Infographic]\n#Fintech #Blockchain https:\/\/t.co\/RUtJ5yRFwI",
    "id" : 935810722067599360,
    "created_at" : "2017-11-29 10:00:37 +0000",
    "user" : {
      "name" : "ipfconline",
      "screen_name" : "ipfconline1",
      "protected" : false,
      "id_str" : "705539763349164032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729065804004769793\/St2_Pum9_normal.jpg",
      "id" : 705539763349164032,
      "verified" : false
    }
  },
  "id" : 936002314325782528,
  "created_at" : "2017-11-29 22:41:56 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/WUZhWEevD7",
      "expanded_url" : "http:\/\/www.espn.com\/video\/clip?id=3289979",
      "display_url" : "espn.com\/video\/clip?id=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "935994114658648065",
  "text" : "Fantastic goal by Wayne Rooney https:\/\/t.co\/WUZhWEevD7",
  "id" : 935994114658648065,
  "created_at" : "2017-11-29 22:09:21 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob J Hyndman",
      "screen_name" : "robjhyndman",
      "indices" : [ 0, 12 ],
      "id_str" : "229638179",
      "id" : 229638179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "935865653730217985",
  "geo" : { },
  "id_str" : "935909443773935617",
  "in_reply_to_user_id" : 229638179,
  "text" : "@robjhyndman Thank you for these packages. I will try them out soon",
  "id" : 935909443773935617,
  "in_reply_to_status_id" : 935865653730217985,
  "created_at" : "2017-11-29 16:32:54 +0000",
  "in_reply_to_screen_name" : "robjhyndman",
  "in_reply_to_user_id_str" : "229638179",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lingard",
      "screen_name" : "JesseLingard",
      "indices" : [ 3, 16 ],
      "id_str" : "755703497195225088",
      "id" : 755703497195225088
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JesseLingard\/status\/935638361204756486\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/6cJDKMkTWW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPwOIGjXcAAbFep.jpg",
      "id_str" : "935638354946912256",
      "id" : 935638354946912256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPwOIGjXcAAbFep.jpg",
      "sizes" : [ {
        "h" : 718,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/6cJDKMkTWW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "935642582100537349",
  "text" : "RT @JesseLingard: I Feel Like Im Hercules \uD83D\uDCAA\uD83C\uDFFE https:\/\/t.co\/6cJDKMkTWW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JesseLingard\/status\/935638361204756486\/photo\/1",
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/6cJDKMkTWW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DPwOIGjXcAAbFep.jpg",
        "id_str" : "935638354946912256",
        "id" : 935638354946912256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPwOIGjXcAAbFep.jpg",
        "sizes" : [ {
          "h" : 718,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 718,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 718,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/6cJDKMkTWW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "935638361204756486",
    "text" : "I Feel Like Im Hercules \uD83D\uDCAA\uD83C\uDFFE https:\/\/t.co\/6cJDKMkTWW",
    "id" : 935638361204756486,
    "created_at" : "2017-11-28 22:35:43 +0000",
    "user" : {
      "name" : "Jesse Lingard",
      "screen_name" : "JesseLingard",
      "protected" : false,
      "id_str" : "755703497195225088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890024867701166080\/SQBxydwe_normal.jpg",
      "id" : 755703497195225088,
      "verified" : true
    }
  },
  "id" : 935642582100537349,
  "created_at" : "2017-11-28 22:52:29 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Auburn",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "934573148262957056",
  "text" : "A great win by Auburn Tigers. #Auburn",
  "id" : 934573148262957056,
  "created_at" : "2017-11-26 00:02:56 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Kim",
      "screen_name" : "larrykim",
      "indices" : [ 3, 12 ],
      "id_str" : "17850785",
      "id" : 17850785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Billionaire",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933777577277194240",
  "text" : "RT @larrykim: 5 Incredible People Who Went From Broke to #Billionaire\n\n\uD83D\uDD25Jeff Bezos (Amazon)\n\uD83D\uDD25Jan Koum (WhatsApp)\n\uD83D\uDD25Howard Schultz (Starbucks\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Billionaire",
        "indices" : [ 43, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "933667763171745793",
    "text" : "5 Incredible People Who Went From Broke to #Billionaire\n\n\uD83D\uDD25Jeff Bezos (Amazon)\n\uD83D\uDD25Jan Koum (WhatsApp)\n\uD83D\uDD25Howard Schultz (Starbucks)\n\uD83D\uDD25Larry Ellison (Oracle Corporation) \n\uD83D\uDD25Oprah Winfrey",
    "id" : 933667763171745793,
    "created_at" : "2017-11-23 12:05:16 +0000",
    "user" : {
      "name" : "Larry Kim",
      "screen_name" : "larrykim",
      "protected" : false,
      "id_str" : "17850785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634035372733898752\/6aSBCDd9_normal.jpg",
      "id" : 17850785,
      "verified" : true
    }
  },
  "id" : 933777577277194240,
  "created_at" : "2017-11-23 19:21:37 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Pearce",
      "screen_name" : "bloomcommKP",
      "indices" : [ 3, 15 ],
      "id_str" : "2395743901",
      "id" : 2395743901
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scicomm",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933266360498405376",
  "text" : "RT @bloomcommKP: Everyone's a winner with good #scicomm: 'Communication with different audiences can help scientists find connections to ot\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Simon Torok",
        "screen_name" : "Scientell",
        "indices" : [ 196, 206 ],
        "id_str" : "4325436976",
        "id" : 4325436976
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scicomm",
        "indices" : [ 30, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 208, 231 ],
        "url" : "https:\/\/t.co\/AFXJ35UCqE",
        "expanded_url" : "https:\/\/theconversation.com\/new-research-shows-explaining-things-to-normal-people-can-help-scientists-be-better-at-their-jobs-84619",
        "display_url" : "theconversation.com\/new-research-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "933105910616014848",
    "text" : "Everyone's a winner with good #scicomm: 'Communication with different audiences can help scientists find connections to other disciplines and see the societal relevance of their own research' [HT @Scientell] https:\/\/t.co\/AFXJ35UCqE",
    "id" : 933105910616014848,
    "created_at" : "2017-11-21 22:52:40 +0000",
    "user" : {
      "name" : "Karen Pearce",
      "screen_name" : "bloomcommKP",
      "protected" : false,
      "id_str" : "2395743901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562802927576707072\/93IikpBg_normal.jpeg",
      "id" : 2395743901,
      "verified" : false
    }
  },
  "id" : 933266360498405376,
  "created_at" : "2017-11-22 09:30:14 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heidi Seibold",
      "screen_name" : "HeidiBaya",
      "indices" : [ 3, 13 ],
      "id_str" : "532115122",
      "id" : 532115122
    }, {
      "name" : "Universit\u00E4t M\u00FCnchen",
      "screen_name" : "LMU_Muenchen",
      "indices" : [ 33, 46 ],
      "id_str" : "91982547",
      "id" : 91982547
    }, {
      "name" : "Klinikum der LMU",
      "screen_name" : "LMU_Uniklinikum",
      "indices" : [ 47, 63 ],
      "id_str" : "20666336",
      "id" : 20666336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stats",
      "indices" : [ 67, 73 ]
    }, {
      "text" : "MachineLearning",
      "indices" : [ 78, 94 ]
    }, {
      "text" : "rstats",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933265550674862080",
  "text" : "RT @HeidiBaya: Come work with me @LMU_Muenchen @LMU_Uniklinikum on #stats and #MachineLearning methods \uD83D\uDD2D\uD83E\uDD13 Knowledge in #rstats and enthusia\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Universit\u00E4t M\u00FCnchen",
        "screen_name" : "LMU_Muenchen",
        "indices" : [ 18, 31 ],
        "id_str" : "91982547",
        "id" : 91982547
      }, {
        "name" : "Klinikum der LMU",
        "screen_name" : "LMU_Uniklinikum",
        "indices" : [ 32, 48 ],
        "id_str" : "20666336",
        "id" : 20666336
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HeidiBaya\/status\/932670316580687879\/photo\/1",
        "indices" : [ 163, 186 ],
        "url" : "https:\/\/t.co\/wbApdQCTu4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DPGB7cfXkAEPUBw.jpg",
        "id_str" : "932669456102428673",
        "id" : 932669456102428673,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPGB7cfXkAEPUBw.jpg",
        "sizes" : [ {
          "h" : 537,
          "resize" : "fit",
          "w" : 664
        }, {
          "h" : 537,
          "resize" : "fit",
          "w" : 664
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 537,
          "resize" : "fit",
          "w" : 664
        }, {
          "h" : 537,
          "resize" : "fit",
          "w" : 664
        } ],
        "display_url" : "pic.twitter.com\/wbApdQCTu4"
      } ],
      "hashtags" : [ {
        "text" : "stats",
        "indices" : [ 52, 58 ]
      }, {
        "text" : "MachineLearning",
        "indices" : [ 63, 79 ]
      }, {
        "text" : "rstats",
        "indices" : [ 104, 111 ]
      }, {
        "text" : "openscience",
        "indices" : [ 131, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "932670316580687879",
    "text" : "Come work with me @LMU_Muenchen @LMU_Uniklinikum on #stats and #MachineLearning methods \uD83D\uDD2D\uD83E\uDD13 Knowledge in #rstats and enthusiasm for #openscience welcome! Please RT https:\/\/t.co\/wbApdQCTu4",
    "id" : 932670316580687879,
    "created_at" : "2017-11-20 18:01:46 +0000",
    "user" : {
      "name" : "Heidi Seibold",
      "screen_name" : "HeidiBaya",
      "protected" : false,
      "id_str" : "532115122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618312466934575104\/NaFte4jy_normal.jpg",
      "id" : 532115122,
      "verified" : false
    }
  },
  "id" : 933265550674862080,
  "created_at" : "2017-11-22 09:27:01 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ronald van Loon",
      "screen_name" : "Ronald_vanLoon",
      "indices" : [ 0, 15 ],
      "id_str" : "555031989",
      "id" : 555031989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "933259181947174914",
  "geo" : { },
  "id_str" : "933264155817140224",
  "in_reply_to_user_id" : 555031989,
  "text" : "@Ronald_vanLoon That's the great list. How did you order the libraries? Tensorflow is kicking pretty fast.",
  "id" : 933264155817140224,
  "in_reply_to_status_id" : 933259181947174914,
  "created_at" : "2017-11-22 09:21:28 +0000",
  "in_reply_to_screen_name" : "Ronald_vanLoon",
  "in_reply_to_user_id_str" : "555031989",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ronald van Loon",
      "screen_name" : "Ronald_vanLoon",
      "indices" : [ 3, 18 ],
      "id_str" : "555031989",
      "id" : 555031989
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DataScience",
      "indices" : [ 71, 83 ]
    }, {
      "text" : "Python",
      "indices" : [ 84, 91 ]
    }, {
      "text" : "RT",
      "indices" : [ 92, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/X1p4ynKSav",
      "expanded_url" : "http:\/\/bit.ly\/2sWZeqd",
      "display_url" : "bit.ly\/2sWZeqd"
    } ]
  },
  "geo" : { },
  "id_str" : "933262328572780545",
  "text" : "RT @Ronald_vanLoon: Top 15 Python Libraries For Data Science In 2017 | #DataScience #Python #RT https:\/\/t.co\/X1p4ynKSav https:\/\/t.co\/IjOILz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/app.sendblur.com\" rel=\"nofollow\"\u003ESocial Media Publisher App \u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Ronald_vanLoon\/status\/933259181947174914\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/IjOILzX6Sy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DPOaRvpVAAABtEh.jpg",
        "id_str" : "933259177434087424",
        "id" : 933259177434087424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPOaRvpVAAABtEh.jpg",
        "sizes" : [ {
          "h" : 217,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/IjOILzX6Sy"
      } ],
      "hashtags" : [ {
        "text" : "DataScience",
        "indices" : [ 51, 63 ]
      }, {
        "text" : "Python",
        "indices" : [ 64, 71 ]
      }, {
        "text" : "RT",
        "indices" : [ 72, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/X1p4ynKSav",
        "expanded_url" : "http:\/\/bit.ly\/2sWZeqd",
        "display_url" : "bit.ly\/2sWZeqd"
      } ]
    },
    "geo" : { },
    "id_str" : "933259181947174914",
    "text" : "Top 15 Python Libraries For Data Science In 2017 | #DataScience #Python #RT https:\/\/t.co\/X1p4ynKSav https:\/\/t.co\/IjOILzX6Sy",
    "id" : 933259181947174914,
    "created_at" : "2017-11-22 09:01:42 +0000",
    "user" : {
      "name" : "Ronald van Loon",
      "screen_name" : "Ronald_vanLoon",
      "protected" : false,
      "id_str" : "555031989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456884052847386624\/a69hONyQ_normal.jpeg",
      "id" : 555031989,
      "verified" : false
    }
  },
  "id" : 933262328572780545,
  "created_at" : "2017-11-22 09:14:12 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janesh Devkota",
      "screen_name" : "janeshdev",
      "indices" : [ 41, 51 ],
      "id_str" : "59507236",
      "id" : 59507236
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 89, 97 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/sKSnLca8Ok",
      "expanded_url" : "https:\/\/youtu.be\/AKxO-zhBUjI",
      "display_url" : "youtu.be\/AKxO-zhBUjI"
    } ]
  },
  "geo" : { },
  "id_str" : "933084536182685696",
  "text" : "EFDC+ and EFDC Explorer Training 2017 by @janeshdev from DSI https:\/\/t.co\/sKSnLca8Ok via @YouTube",
  "id" : 933084536182685696,
  "created_at" : "2017-11-21 21:27:43 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ronald van Loon",
      "screen_name" : "Ronald_vanLoon",
      "indices" : [ 3, 18 ],
      "id_str" : "555031989",
      "id" : 555031989
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigData",
      "indices" : [ 90, 98 ]
    }, {
      "text" : "Analytics",
      "indices" : [ 99, 109 ]
    }, {
      "text" : "RT",
      "indices" : [ 110, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/MNrejsVpfS",
      "expanded_url" : "http:\/\/bit.ly\/2j8KEJ8",
      "display_url" : "bit.ly\/2j8KEJ8"
    } ]
  },
  "geo" : { },
  "id_str" : "933045144340668416",
  "text" : "RT @Ronald_vanLoon: BIG DATA ANALYTICS AND SENSORS: HOW THEY ARE TRANSFORMING OUR WORLD | #BigData #Analytics #RT https:\/\/t.co\/MNrejsVpfS h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/app.sendblur.com\" rel=\"nofollow\"\u003ESocial Media Publisher App \u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Ronald_vanLoon\/status\/933039091591139328\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/m2GLfEGcMm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DPLSG4oUIAAtwoH.png",
        "id_str" : "933039088541638656",
        "id" : 933039088541638656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPLSG4oUIAAtwoH.png",
        "sizes" : [ {
          "h" : 518,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 344,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 518,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 518,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/m2GLfEGcMm"
      } ],
      "hashtags" : [ {
        "text" : "BigData",
        "indices" : [ 70, 78 ]
      }, {
        "text" : "Analytics",
        "indices" : [ 79, 89 ]
      }, {
        "text" : "RT",
        "indices" : [ 90, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/MNrejsVpfS",
        "expanded_url" : "http:\/\/bit.ly\/2j8KEJ8",
        "display_url" : "bit.ly\/2j8KEJ8"
      } ]
    },
    "geo" : { },
    "id_str" : "933039091591139328",
    "text" : "BIG DATA ANALYTICS AND SENSORS: HOW THEY ARE TRANSFORMING OUR WORLD | #BigData #Analytics #RT https:\/\/t.co\/MNrejsVpfS https:\/\/t.co\/m2GLfEGcMm",
    "id" : 933039091591139328,
    "created_at" : "2017-11-21 18:27:09 +0000",
    "user" : {
      "name" : "Ronald van Loon",
      "screen_name" : "Ronald_vanLoon",
      "protected" : false,
      "id_str" : "555031989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456884052847386624\/a69hONyQ_normal.jpeg",
      "id" : 555031989,
      "verified" : false
    }
  },
  "id" : 933045144340668416,
  "created_at" : "2017-11-21 18:51:12 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Attali",
      "screen_name" : "daattali",
      "indices" : [ 120, 129 ],
      "id_str" : "253791979",
      "id" : 253791979
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/fFYo8lhii5",
      "expanded_url" : "https:\/\/deanattali.com\/blog\/user2017\/",
      "display_url" : "deanattali.com\/blog\/user2017\/"
    } ]
  },
  "geo" : { },
  "id_str" : "933030692035870720",
  "text" : "What makes an R talk popular? Scraping useR2017 attendance information to find out! https:\/\/t.co\/fFYo8lhii5 #rstats via @daattali",
  "id" : 933030692035870720,
  "created_at" : "2017-11-21 17:53:46 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Attali",
      "screen_name" : "daattali",
      "indices" : [ 3, 12 ],
      "id_str" : "253791979",
      "id" : 253791979
    }, {
      "name" : "Kirill M\u00FCller",
      "screen_name" : "krlmlr",
      "indices" : [ 124, 131 ],
      "id_str" : "3354999513",
      "id" : 3354999513
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932680129477619713",
  "text" : "RT @daattali: Want to learn or improve your #rstats\/tidyverse\/shiny skills?\n\nAttend the 4-day workshop hosted by myself and @krlmlr in Toro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kirill M\u00FCller",
        "screen_name" : "krlmlr",
        "indices" : [ 110, 117 ],
        "id_str" : "3354999513",
        "id" : 3354999513
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rstats",
        "indices" : [ 30, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 240, 263 ],
        "url" : "https:\/\/t.co\/ZKePRjNLv6",
        "expanded_url" : "https:\/\/www.eventbrite.com\/e\/modern-r-data-processing-visualization-and-reporting-with-r-tickets-39862492789?aff=deantwitter",
        "display_url" : "eventbrite.com\/e\/modern-r-dat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "932671715129270272",
    "text" : "Want to learn or improve your #rstats\/tidyverse\/shiny skills?\n\nAttend the 4-day workshop hosted by myself and @krlmlr in Toronto in January! Use promo code TIDYSHINY15 for a limited-time 15% discount.\n\nPlease retweet\/share within your org\n\nhttps:\/\/t.co\/ZKePRjNLv6",
    "id" : 932671715129270272,
    "created_at" : "2017-11-20 18:07:19 +0000",
    "user" : {
      "name" : "Dean Attali",
      "screen_name" : "daattali",
      "protected" : false,
      "id_str" : "253791979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507322253776650240\/TyAxiMi6_normal.jpeg",
      "id" : 253791979,
      "verified" : false
    }
  },
  "id" : 932680129477619713,
  "created_at" : "2017-11-20 18:40:45 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miles McBain",
      "screen_name" : "MilesMcBain",
      "indices" : [ 0, 12 ],
      "id_str" : "1715370056",
      "id" : 1715370056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "932257990253645829",
  "geo" : { },
  "id_str" : "932427255120199681",
  "in_reply_to_user_id" : 1715370056,
  "text" : "@MilesMcBain Very interesting approach on tidying the dat",
  "id" : 932427255120199681,
  "in_reply_to_status_id" : 932257990253645829,
  "created_at" : "2017-11-20 01:55:55 +0000",
  "in_reply_to_screen_name" : "MilesMcBain",
  "in_reply_to_user_id_str" : "1715370056",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/iYiFA106S1",
      "expanded_url" : "https:\/\/twitter.com\/ipfconline1\/status\/931598108743610373",
      "display_url" : "twitter.com\/ipfconline1\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931598824589496320",
  "text" : "Very well put. Data science covers so much https:\/\/t.co\/iYiFA106S1",
  "id" : 931598824589496320,
  "created_at" : "2017-11-17 19:04:02 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kara Woo",
      "screen_name" : "kara_woo",
      "indices" : [ 3, 12 ],
      "id_str" : "551600672",
      "id" : 551600672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931592990123966464",
  "text" : "RT @kara_woo: Come be my colleague! My team is hiring a data science content developer. If you like data science and education, check it ou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 128, 151 ],
        "url" : "https:\/\/t.co\/RrBZHKe5vb",
        "expanded_url" : "https:\/\/www.datacamp.com\/careers\/736671",
        "display_url" : "datacamp.com\/careers\/736671"
      } ]
    },
    "geo" : { },
    "id_str" : "931586173608214528",
    "text" : "Come be my colleague! My team is hiring a data science content developer. If you like data science and education, check it out: https:\/\/t.co\/RrBZHKe5vb",
    "id" : 931586173608214528,
    "created_at" : "2017-11-17 18:13:46 +0000",
    "user" : {
      "name" : "Kara Woo",
      "screen_name" : "kara_woo",
      "protected" : false,
      "id_str" : "551600672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687151931127500800\/Kdf54J10_normal.jpg",
      "id" : 551600672,
      "verified" : false
    }
  },
  "id" : 931592990123966464,
  "created_at" : "2017-11-17 18:40:51 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rajan Devkota",
      "screen_name" : "rajandevkota",
      "indices" : [ 0, 13 ],
      "id_str" : "69660252",
      "id" : 69660252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "916740034425966592",
  "geo" : { },
  "id_str" : "931592916782292992",
  "in_reply_to_user_id" : 69660252,
  "text" : "@rajandevkota What is the best part of the book ?",
  "id" : 931592916782292992,
  "in_reply_to_status_id" : 916740034425966592,
  "created_at" : "2017-11-17 18:40:34 +0000",
  "in_reply_to_screen_name" : "rajandevkota",
  "in_reply_to_user_id_str" : "69660252",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Robinson",
      "screen_name" : "drob",
      "indices" : [ 91, 96 ],
      "id_str" : "46245868",
      "id" : 46245868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    }, {
      "text" : "fantasypremierleague",
      "indices" : [ 97, 118 ]
    }, {
      "text" : "dataanalysis",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 135, 158 ],
      "url" : "https:\/\/t.co\/ob9kAME6x3",
      "expanded_url" : "https:\/\/janeshdevkota.com\/2017\/11\/fantasy-premier-league\/",
      "display_url" : "janeshdevkota.com\/2017\/11\/fantas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931082635568332800",
  "text" : "Wrote a First Data Science Blog on analyzing fantasy premier league data using R. #rstats  @drob #fantasypremierleague #dataanalysis. \nhttps:\/\/t.co\/ob9kAME6x3",
  "id" : 931082635568332800,
  "created_at" : "2017-11-16 08:52:53 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/4LM6fVlEcb",
      "expanded_url" : "https:\/\/twitter.com\/AndrewYNg\/status\/930938692310482944",
      "display_url" : "twitter.com\/AndrewYNg\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930939519725060096",
  "text" : "Amazing https:\/\/t.co\/4LM6fVlEcb",
  "id" : 930939519725060096,
  "created_at" : "2017-11-15 23:24:12 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rubeena Mahato",
      "screen_name" : "rubeenaa",
      "indices" : [ 3, 12 ],
      "id_str" : "274931306",
      "id" : 274931306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "930579719753306112",
  "text" : "RT @rubeenaa: Depressing to think that there are millions of Nepalis who are not home this Dashain-Tihar, toiling away in a faraway country\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "922139879131242496",
    "text" : "Depressing to think that there are millions of Nepalis who are not home this Dashain-Tihar, toiling away in a faraway country for a chance to make a decent living.  Their fathers had done the same and so will their children.",
    "id" : 922139879131242496,
    "created_at" : "2017-10-22 16:37:34 +0000",
    "user" : {
      "name" : "Rubeena Mahato",
      "screen_name" : "rubeenaa",
      "protected" : false,
      "id_str" : "274931306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788009257497092096\/FkUvvWd6_normal.jpg",
      "id" : 274931306,
      "verified" : true
    }
  },
  "id" : 930579719753306112,
  "created_at" : "2017-11-14 23:34:29 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/QbIZ2iA1kS",
      "expanded_url" : "http:\/\/ed.gr\/f9gi",
      "display_url" : "ed.gr\/f9gi"
    } ]
  },
  "geo" : { },
  "id_str" : "925820010425065472",
  "text" : "RT @EFDC_Explorer: Check out this 3D visualization example of the Three Gorges Dam: https:\/\/t.co\/QbIZ2iA1kS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/meetedgar.com\" rel=\"nofollow\"\u003EMeet Edgar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/QbIZ2iA1kS",
        "expanded_url" : "http:\/\/ed.gr\/f9gi",
        "display_url" : "ed.gr\/f9gi"
      } ]
    },
    "geo" : { },
    "id_str" : "925817113532600321",
    "text" : "Check out this 3D visualization example of the Three Gorges Dam: https:\/\/t.co\/QbIZ2iA1kS",
    "id" : 925817113532600321,
    "created_at" : "2017-11-01 20:09:35 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 925820010425065472,
  "created_at" : "2017-11-01 20:21:06 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]