Grailbird.data.tweets_2017_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PersianGulf",
      "indices" : [ 45, 57 ]
    }, {
      "text" : "oiltransport",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821038590322831361",
  "text" : "RT @EFDC_Explorer: Get your free grid of the #PersianGulf, critical to the world economy &amp; understanding #oiltransport hazards. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EFDC_Explorer\/status\/818870082600398855\/photo\/1",
        "indices" : [ 143, 166 ],
        "url" : "https:\/\/t.co\/2FZ3Uks0wl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C101_5SUsAA_5MH.jpg",
        "id_str" : "818870079077003264",
        "id" : 818870079077003264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C101_5SUsAA_5MH.jpg",
        "sizes" : [ {
          "h" : 790,
          "resize" : "fit",
          "w" : 1088
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 790,
          "resize" : "fit",
          "w" : 1088
        }, {
          "h" : 494,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 790,
          "resize" : "fit",
          "w" : 1088
        } ],
        "display_url" : "pic.twitter.com\/2FZ3Uks0wl"
      } ],
      "hashtags" : [ {
        "text" : "PersianGulf",
        "indices" : [ 26, 38 ]
      }, {
        "text" : "oiltransport",
        "indices" : [ 90, 103 ]
      }, {
        "text" : "efdc",
        "indices" : [ 137, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/Uil0guDDcI",
        "expanded_url" : "http:\/\/www.efdc-explorer.com\/resources\/coastal-grids\/persian-gulf-middle-east.html",
        "display_url" : "efdc-explorer.com\/resources\/coas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "818870082600398855",
    "text" : "Get your free grid of the #PersianGulf, critical to the world economy &amp; understanding #oiltransport hazards. https:\/\/t.co\/Uil0guDDcI #efdc https:\/\/t.co\/2FZ3Uks0wl",
    "id" : 818870082600398855,
    "created_at" : "2017-01-10 17:20:16 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 821038590322831361,
  "created_at" : "2017-01-16 16:57:08 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    }, {
      "name" : "Battelle",
      "screen_name" : "Battelle",
      "indices" : [ 39, 48 ],
      "id_str" : "74748331",
      "id" : 74748331
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EFDC_Explorer\/status\/818931410828480512\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/NnEHGKko4s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C11tEuNWIAErDxU.jpg",
      "id_str" : "818930635142209537",
      "id" : 818930635142209537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C11tEuNWIAErDxU.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/NnEHGKko4s"
    } ],
    "hashtags" : [ {
      "text" : "sediments17",
      "indices" : [ 49, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821038407660863490",
  "text" : "RT @EFDC_Explorer: Panel discussion at @Battelle #sediments17 conference: Advances in Sediment Remediation https:\/\/t.co\/NnEHGKko4s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Battelle",
        "screen_name" : "Battelle",
        "indices" : [ 20, 29 ],
        "id_str" : "74748331",
        "id" : 74748331
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EFDC_Explorer\/status\/818931410828480512\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/NnEHGKko4s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C11tEuNWIAErDxU.jpg",
        "id_str" : "818930635142209537",
        "id" : 818930635142209537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C11tEuNWIAErDxU.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/NnEHGKko4s"
      } ],
      "hashtags" : [ {
        "text" : "sediments17",
        "indices" : [ 30, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "818931410828480512",
    "text" : "Panel discussion at @Battelle #sediments17 conference: Advances in Sediment Remediation https:\/\/t.co\/NnEHGKko4s",
    "id" : 818931410828480512,
    "created_at" : "2017-01-10 21:23:58 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 821038407660863490,
  "created_at" : "2017-01-16 16:56:25 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Battelle",
      "screen_name" : "Battelle",
      "indices" : [ 3, 12 ],
      "id_str" : "74748331",
      "id" : 74748331
    }, {
      "name" : "Battelle",
      "screen_name" : "Battelle",
      "indices" : [ 33, 42 ],
      "id_str" : "74748331",
      "id" : 74748331
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Battelle\/status\/819661110341206017\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/qoX1rm2hA7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C2AFbUqWgAQcgHe.jpg",
      "id_str" : "819661099142381572",
      "id" : 819661099142381572,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2AFbUqWgAQcgHe.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/qoX1rm2hA7"
    } ],
    "hashtags" : [ {
      "text" : "sediments17",
      "indices" : [ 43, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821038019457126400",
  "text" : "RT @Battelle: Closing session at @Battelle #sediments17 conference https:\/\/t.co\/qoX1rm2hA7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Battelle",
        "screen_name" : "Battelle",
        "indices" : [ 19, 28 ],
        "id_str" : "74748331",
        "id" : 74748331
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Battelle\/status\/819661110341206017\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/qoX1rm2hA7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C2AFbUqWgAQcgHe.jpg",
        "id_str" : "819661099142381572",
        "id" : 819661099142381572,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2AFbUqWgAQcgHe.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/qoX1rm2hA7"
      } ],
      "hashtags" : [ {
        "text" : "sediments17",
        "indices" : [ 29, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "819661110341206017",
    "text" : "Closing session at @Battelle #sediments17 conference https:\/\/t.co\/qoX1rm2hA7",
    "id" : 819661110341206017,
    "created_at" : "2017-01-12 21:43:31 +0000",
    "user" : {
      "name" : "Battelle",
      "screen_name" : "Battelle",
      "protected" : false,
      "id_str" : "74748331",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821809824774127617\/03ZU7Vdo_normal.jpg",
      "id" : 74748331,
      "verified" : true
    }
  },
  "id" : 821038019457126400,
  "created_at" : "2017-01-16 16:54:52 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hydrodynamic",
      "indices" : [ 41, 54 ]
    }, {
      "text" : "waterquality",
      "indices" : [ 61, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821037986443706369",
  "text" : "RT @EFDC_Explorer: Improve efficiency of #hydrodynamic &amp; #waterquality modeling projects. Get a free trial of EFDC_Explorer8.2 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EFDC_Explorer\/status\/821024469942734848\/photo\/1",
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/z9nx4Qs0ws",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C2TdZypWIAQa-bC.jpg",
        "id_str" : "821024467249930244",
        "id" : 821024467249930244,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C2TdZypWIAQa-bC.jpg",
        "sizes" : [ {
          "h" : 252,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 851
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 851
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 851
        } ],
        "display_url" : "pic.twitter.com\/z9nx4Qs0ws"
      } ],
      "hashtags" : [ {
        "text" : "hydrodynamic",
        "indices" : [ 22, 35 ]
      }, {
        "text" : "waterquality",
        "indices" : [ 42, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/SPm401efnw",
        "expanded_url" : "http:\/\/www.efdc-explorer.com\/efdc-explorer",
        "display_url" : "efdc-explorer.com\/efdc-explorer"
      } ]
    },
    "geo" : { },
    "id_str" : "821024469942734848",
    "text" : "Improve efficiency of #hydrodynamic &amp; #waterquality modeling projects. Get a free trial of EFDC_Explorer8.2 https:\/\/t.co\/SPm401efnw https:\/\/t.co\/z9nx4Qs0ws",
    "id" : 821024469942734848,
    "created_at" : "2017-01-16 16:01:02 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 821037986443706369,
  "created_at" : "2017-01-16 16:54:44 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]