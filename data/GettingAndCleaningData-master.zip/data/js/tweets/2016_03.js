Grailbird.data.tweets_2016_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 0, 7 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713008064320901120",
  "geo" : { },
  "id_str" : "713010842363531264",
  "in_reply_to_user_id" : 558797310,
  "text" : "@ManUtd Diego forlan",
  "id" : 713010842363531264,
  "in_reply_to_status_id" : 713008064320901120,
  "created_at" : "2016-03-24 14:33:26 +0000",
  "in_reply_to_screen_name" : "ManUtd",
  "in_reply_to_user_id_str" : "558797310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFDC_Explorer",
      "indices" : [ 49, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/B9cGCN580X",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=X353GFUiVHE&ab_channel=EFDCExplorer",
      "display_url" : "youtube.com\/watch?v=X353GF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712711318667571200",
  "text" : "RT @EFDC_Explorer: Sydney Harbor animation using #EFDC_Explorer with labels, bridges, Opera House. https:\/\/t.co\/B9cGCN580X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EFDC_Explorer",
        "indices" : [ 30, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/B9cGCN580X",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=X353GFUiVHE&ab_channel=EFDCExplorer",
        "display_url" : "youtube.com\/watch?v=X353GF\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712710174914424832",
    "text" : "Sydney Harbor animation using #EFDC_Explorer with labels, bridges, Opera House. https:\/\/t.co\/B9cGCN580X",
    "id" : 712710174914424832,
    "created_at" : "2016-03-23 18:38:41 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 712711318667571200,
  "created_at" : "2016-03-23 18:43:14 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/my.ringplus.net\" rel=\"nofollow\"\u003ERingPlus\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RingPlus",
      "screen_name" : "ringplusmobile",
      "indices" : [ 102, 117 ],
      "id_str" : "468637465",
      "id" : 468637465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/ChX0Jg1GYX",
      "expanded_url" : "http:\/\/ringplus.net",
      "display_url" : "ringplus.net"
    } ]
  },
  "geo" : { },
  "id_str" : "711600156249038849",
  "text" : "I'm getting an incredible amount of free cellphone service - all from https:\/\/t.co\/ChX0Jg1GYX! Thanks @ringplusmobile!",
  "id" : 711600156249038849,
  "created_at" : "2016-03-20 17:07:52 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710859546193842176",
  "text" : "I think it's time for Louis Van Gaal to go.",
  "id" : 710859546193842176,
  "created_at" : "2016-03-18 16:04:57 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basti Schweinsteiger",
      "screen_name" : "BSchweinsteiger",
      "indices" : [ 0, 16 ],
      "id_str" : "1283561876",
      "id" : 1283561876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710450834484686850",
  "geo" : { },
  "id_str" : "710510790793531393",
  "in_reply_to_user_id" : 1283561876,
  "text" : "@BSchweinsteiger Good luck Bastian.",
  "id" : 710510790793531393,
  "in_reply_to_status_id" : 710450834484686850,
  "created_at" : "2016-03-17 16:59:07 +0000",
  "in_reply_to_screen_name" : "BSchweinsteiger",
  "in_reply_to_user_id_str" : "1283561876",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/KMrUVcsQ3k",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=LdPMeWizoTA&ab_channel=EFDCExplorer",
      "display_url" : "youtube.com\/watch?v=LdPMeW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709876462900228096",
  "text" : "RT @EFDC_Explorer: Sydney Harbor flyover using EFDC_Explorer. \n\nhttps:\/\/t.co\/KMrUVcsQ3k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/KMrUVcsQ3k",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=LdPMeWizoTA&ab_channel=EFDCExplorer",
        "display_url" : "youtube.com\/watch?v=LdPMeW\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "709874113985130496",
    "text" : "Sydney Harbor flyover using EFDC_Explorer. \n\nhttps:\/\/t.co\/KMrUVcsQ3k",
    "id" : 709874113985130496,
    "created_at" : "2016-03-15 22:49:12 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 709876462900228096,
  "created_at" : "2016-03-15 22:58:32 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 0, 7 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707659395006664707",
  "geo" : { },
  "id_str" : "707693330415489026",
  "in_reply_to_user_id" : 558797310,
  "text" : "@ManUtd no Kathmandu, Nepal ?",
  "id" : 707693330415489026,
  "in_reply_to_status_id" : 707659395006664707,
  "created_at" : "2016-03-09 22:23:32 +0000",
  "in_reply_to_screen_name" : "ManUtd",
  "in_reply_to_user_id_str" : "558797310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/0Pxr7T8VB8",
      "expanded_url" : "https:\/\/twitter.com\/EFDC_Explorer\/status\/707648426779906048",
      "display_url" : "twitter.com\/EFDC_Explorer\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707648836722753536",
  "text" : "Awesome the new EE8 is out with significant improvement and lots of exciting features. https:\/\/t.co\/0Pxr7T8VB8",
  "id" : 707648836722753536,
  "created_at" : "2016-03-09 19:26:44 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmexCarrabbas",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706923217840017408",
  "text" : "#AmexCarrabbas",
  "id" : 706923217840017408,
  "created_at" : "2016-03-07 19:23:23 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 0, 7 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706504171806023680",
  "geo" : { },
  "id_str" : "706508964641411072",
  "in_reply_to_user_id" : 558797310,
  "text" : "@ManUtd really that's what you say good work ?",
  "id" : 706508964641411072,
  "in_reply_to_status_id" : 706504171806023680,
  "created_at" : "2016-03-06 15:57:18 +0000",
  "in_reply_to_screen_name" : "ManUtd",
  "in_reply_to_user_id_str" : "558797310",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 3, 10 ],
      "id_str" : "558797310",
      "id" : 558797310
    }, {
      "name" : "Morgan Schneiderlin",
      "screen_name" : "SchneiderlinMo4",
      "indices" : [ 32, 48 ],
      "id_str" : "2550652224",
      "id" : 2550652224
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/705149311903014912\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/4sZZLf5M4Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cckxj-0UsAA05D7.jpg",
      "id_str" : "705149310887833600",
      "id" : 705149310887833600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cckxj-0UsAA05D7.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 709
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 709
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 709
      } ],
      "display_url" : "pic.twitter.com\/4sZZLf5M4Z"
    } ],
    "hashtags" : [ {
      "text" : "mufc",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705155122490245124",
  "text" : "RT @ManUtd: Retweet to vote for @SchneiderlinMo4 as #mufc's Man of the Match v Watford. https:\/\/t.co\/4sZZLf5M4Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Morgan Schneiderlin",
        "screen_name" : "SchneiderlinMo4",
        "indices" : [ 20, 36 ],
        "id_str" : "2550652224",
        "id" : 2550652224
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/705149311903014912\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/4sZZLf5M4Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cckxj-0UsAA05D7.jpg",
        "id_str" : "705149310887833600",
        "id" : 705149310887833600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cckxj-0UsAA05D7.jpg",
        "sizes" : [ {
          "h" : 399,
          "resize" : "fit",
          "w" : 709
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 709
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 709
        } ],
        "display_url" : "pic.twitter.com\/4sZZLf5M4Z"
      } ],
      "hashtags" : [ {
        "text" : "mufc",
        "indices" : [ 40, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "705149311903014912",
    "text" : "Retweet to vote for @SchneiderlinMo4 as #mufc's Man of the Match v Watford. https:\/\/t.co\/4sZZLf5M4Z",
    "id" : 705149311903014912,
    "created_at" : "2016-03-02 21:54:31 +0000",
    "user" : {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "protected" : false,
      "id_str" : "558797310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/934706707258904578\/7HAVD2b0_normal.jpg",
      "id" : 558797310,
      "verified" : true
    }
  },
  "id" : 705155122490245124,
  "created_at" : "2016-03-02 22:17:37 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 3, 10 ],
      "id_str" : "558797310",
      "id" : 558797310
    }, {
      "name" : "Juan Mata Garc\u00EDa",
      "screen_name" : "juanmata8",
      "indices" : [ 32, 42 ],
      "id_str" : "140750163",
      "id" : 140750163
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/705149129740132353\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/0hEkHa97sD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CckxZWWUEAAOxN8.jpg",
      "id_str" : "705149128225853440",
      "id" : 705149128225853440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CckxZWWUEAAOxN8.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 709
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 709
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 709
      } ],
      "display_url" : "pic.twitter.com\/0hEkHa97sD"
    } ],
    "hashtags" : [ {
      "text" : "mufc",
      "indices" : [ 46, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705155093868359680",
  "text" : "RT @ManUtd: Retweet to vote for @JuanMata8 as #mufc's Man of the Match v Watford. https:\/\/t.co\/0hEkHa97sD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Juan Mata Garc\u00EDa",
        "screen_name" : "juanmata8",
        "indices" : [ 20, 30 ],
        "id_str" : "140750163",
        "id" : 140750163
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/705149129740132353\/photo\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/0hEkHa97sD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CckxZWWUEAAOxN8.jpg",
        "id_str" : "705149128225853440",
        "id" : 705149128225853440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CckxZWWUEAAOxN8.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 709
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 709
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 709
        } ],
        "display_url" : "pic.twitter.com\/0hEkHa97sD"
      } ],
      "hashtags" : [ {
        "text" : "mufc",
        "indices" : [ 34, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "705149129740132353",
    "text" : "Retweet to vote for @JuanMata8 as #mufc's Man of the Match v Watford. https:\/\/t.co\/0hEkHa97sD",
    "id" : 705149129740132353,
    "created_at" : "2016-03-02 21:53:48 +0000",
    "user" : {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "protected" : false,
      "id_str" : "558797310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/934706707258904578\/7HAVD2b0_normal.jpg",
      "id" : 558797310,
      "verified" : true
    }
  },
  "id" : 705155093868359680,
  "created_at" : "2016-03-02 22:17:30 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 3, 10 ],
      "id_str" : "558797310",
      "id" : 558797310
    }, {
      "name" : "Juan Mata Garc\u00EDa",
      "screen_name" : "juanmata8",
      "indices" : [ 74, 84 ],
      "id_str" : "140750163",
      "id" : 140750163
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/705152003215892480\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/AUuZl4iJgZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cck0AmaUAAAJufp.jpg",
      "id_str" : "705152001575747584",
      "id" : 705152001575747584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cck0AmaUAAAJufp.jpg",
      "sizes" : [ {
        "h" : 1253,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2494,
        "resize" : "fit",
        "w" : 4077
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/AUuZl4iJgZ"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/705152003215892480\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/AUuZl4iJgZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cckz4Y1UcAA9hlo.jpg",
      "id_str" : "705151860491972608",
      "id" : 705151860491972608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cckz4Y1UcAA9hlo.jpg",
      "sizes" : [ {
        "h" : 2064,
        "resize" : "fit",
        "w" : 3000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 826,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1409,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/AUuZl4iJgZ"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/705152003215892480\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/AUuZl4iJgZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cckz92yUUAAxnlQ.jpg",
      "id_str" : "705151954431791104",
      "id" : 705151954431791104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cckz92yUUAAxnlQ.jpg",
      "sizes" : [ {
        "h" : 583,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1030,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2574,
        "resize" : "fit",
        "w" : 3000
      }, {
        "h" : 1757,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/AUuZl4iJgZ"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/705152003215892480\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/AUuZl4iJgZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cckz8xnVIAE8psJ.jpg",
      "id_str" : "705151935863660545",
      "id" : 705151935863660545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cckz8xnVIAE8psJ.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2818,
        "resize" : "fit",
        "w" : 4233
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1363,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/AUuZl4iJgZ"
    } ],
    "hashtags" : [ {
      "text" : "mufc",
      "indices" : [ 46, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705154941740982272",
  "text" : "RT @ManUtd: There's nothing quite like a late #mufc winner - well played, @JuanMata8! \uD83D\uDC4C https:\/\/t.co\/AUuZl4iJgZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Juan Mata Garc\u00EDa",
        "screen_name" : "juanmata8",
        "indices" : [ 62, 72 ],
        "id_str" : "140750163",
        "id" : 140750163
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/705152003215892480\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/AUuZl4iJgZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cck0AmaUAAAJufp.jpg",
        "id_str" : "705152001575747584",
        "id" : 705152001575747584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cck0AmaUAAAJufp.jpg",
        "sizes" : [ {
          "h" : 1253,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 416,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2494,
          "resize" : "fit",
          "w" : 4077
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 734,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/AUuZl4iJgZ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/705152003215892480\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/AUuZl4iJgZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cckz4Y1UcAA9hlo.jpg",
        "id_str" : "705151860491972608",
        "id" : 705151860491972608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cckz4Y1UcAA9hlo.jpg",
        "sizes" : [ {
          "h" : 2064,
          "resize" : "fit",
          "w" : 3000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 826,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1409,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/AUuZl4iJgZ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/705152003215892480\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/AUuZl4iJgZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cckz92yUUAAxnlQ.jpg",
        "id_str" : "705151954431791104",
        "id" : 705151954431791104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cckz92yUUAAxnlQ.jpg",
        "sizes" : [ {
          "h" : 583,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1030,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2574,
          "resize" : "fit",
          "w" : 3000
        }, {
          "h" : 1757,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/AUuZl4iJgZ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/705152003215892480\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/AUuZl4iJgZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cckz8xnVIAE8psJ.jpg",
        "id_str" : "705151935863660545",
        "id" : 705151935863660545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cckz8xnVIAE8psJ.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2818,
          "resize" : "fit",
          "w" : 4233
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1363,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/AUuZl4iJgZ"
      } ],
      "hashtags" : [ {
        "text" : "mufc",
        "indices" : [ 34, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "705152003215892480",
    "text" : "There's nothing quite like a late #mufc winner - well played, @JuanMata8! \uD83D\uDC4C https:\/\/t.co\/AUuZl4iJgZ",
    "id" : 705152003215892480,
    "created_at" : "2016-03-02 22:05:13 +0000",
    "user" : {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "protected" : false,
      "id_str" : "558797310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/934706707258904578\/7HAVD2b0_normal.jpg",
      "id" : 558797310,
      "verified" : true
    }
  },
  "id" : 705154941740982272,
  "created_at" : "2016-03-02 22:16:53 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]