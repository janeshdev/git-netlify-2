Grailbird.data.tweets_2017_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lomas \u0932\u094B\u092E\u0938",
      "screen_name" : "lomaspj",
      "indices" : [ 0, 8 ],
      "id_str" : "14788193",
      "id" : 14788193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "922720847483277312",
  "geo" : { },
  "id_str" : "922890432467501056",
  "in_reply_to_user_id" : 14788193,
  "text" : "@lomaspj Moj garnu",
  "id" : 922890432467501056,
  "in_reply_to_status_id" : 922720847483277312,
  "created_at" : "2017-10-24 18:20:00 +0000",
  "in_reply_to_screen_name" : "lomaspj",
  "in_reply_to_user_id_str" : "14788193",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mara Averick",
      "screen_name" : "dataandme",
      "indices" : [ 0, 10 ],
      "id_str" : "3230388598",
      "id" : 3230388598
    }, {
      "name" : "Roger D. Peng",
      "screen_name" : "rdpeng",
      "indices" : [ 11, 18 ],
      "id_str" : "9308212",
      "id" : 9308212
    }, {
      "name" : "Sean Kross",
      "screen_name" : "seankross",
      "indices" : [ 19, 29 ],
      "id_str" : "273200904",
      "id" : 273200904
    }, {
      "name" : "Brooke Anderson",
      "screen_name" : "gbwanderson",
      "indices" : [ 30, 42 ],
      "id_str" : "4103532134",
      "id" : 4103532134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "916412004650373121",
  "geo" : { },
  "id_str" : "916707078441394176",
  "in_reply_to_user_id" : 3230388598,
  "text" : "@dataandme @rdpeng @seankross @gbwanderson Thanks for letting us know. Going through this book and learning a lot already",
  "id" : 916707078441394176,
  "in_reply_to_status_id" : 916412004650373121,
  "created_at" : "2017-10-07 16:49:33 +0000",
  "in_reply_to_screen_name" : "dataandme",
  "in_reply_to_user_id_str" : "3230388598",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LasVegasShooting",
      "indices" : [ 71, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "914888497076477952",
  "text" : "Really sad to learn about Las Vegas massacre. Gun laws need to change? #LasVegasShooting",
  "id" : 914888497076477952,
  "created_at" : "2017-10-02 16:23:10 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]