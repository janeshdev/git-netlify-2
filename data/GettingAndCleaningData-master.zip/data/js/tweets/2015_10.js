Grailbird.data.tweets_2015_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slickdeals",
      "screen_name" : "slickdeals",
      "indices" : [ 3, 14 ],
      "id_str" : "7542702",
      "id" : 7542702
    }, {
      "name" : "slickdeals",
      "screen_name" : "slickdeals",
      "indices" : [ 42, 53 ],
      "id_str" : "7542702",
      "id" : 7542702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaway",
      "indices" : [ 54, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/yKE2oy7tHy",
      "expanded_url" : "http:\/\/slickdeals.net\/giveaway\/5149\/?utm_campaign=5149&utm_medium=giveawaytweet&utm_source=twitter",
      "display_url" : "slickdeals.net\/giveaway\/5149\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659797884120858624",
  "text" : "RT @slickdeals: Win a $200 Visa Gift Card @slickdeals #giveaway https:\/\/t.co\/yKE2oy7tHy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/slickdeals.net\" rel=\"nofollow\"\u003ESlickdeals\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "slickdeals",
        "screen_name" : "slickdeals",
        "indices" : [ 26, 37 ],
        "id_str" : "7542702",
        "id" : 7542702
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "giveaway",
        "indices" : [ 38, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/yKE2oy7tHy",
        "expanded_url" : "http:\/\/slickdeals.net\/giveaway\/5149\/?utm_campaign=5149&utm_medium=giveawaytweet&utm_source=twitter",
        "display_url" : "slickdeals.net\/giveaway\/5149\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659625804184227840",
    "text" : "Win a $200 Visa Gift Card @slickdeals #giveaway https:\/\/t.co\/yKE2oy7tHy",
    "id" : 659625804184227840,
    "created_at" : "2015-10-29 07:00:21 +0000",
    "user" : {
      "name" : "slickdeals",
      "screen_name" : "slickdeals",
      "protected" : false,
      "id_str" : "7542702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913775734065324033\/62niNMkQ_normal.jpg",
      "id" : 7542702,
      "verified" : true
    }
  },
  "id" : 659797884120858624,
  "created_at" : "2015-10-29 18:24:08 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]