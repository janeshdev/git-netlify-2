Grailbird.data.tweets_2016_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 99, 109 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/91hHU4zkNu",
      "expanded_url" : "https:\/\/shar.es\/1wwDg4",
      "display_url" : "shar.es\/1wwDg4"
    } ]
  },
  "geo" : { },
  "id_str" : "771811207942549505",
  "text" : "Hot $1 Deals in Exchange for Your Honest Review - Amazing Deals Group! https:\/\/t.co\/91hHU4zkNu via @sharethis",
  "id" : 771811207942549505,
  "created_at" : "2016-09-02 20:45:06 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]