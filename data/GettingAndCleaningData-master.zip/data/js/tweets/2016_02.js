Grailbird.data.tweets_2016_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    }, {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 61, 75 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVLGrid",
      "indices" : [ 48, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703264246201618433",
  "text" : "RT @EFDC_Explorer: Create georeferenced maps in #CVLGrid and @EFDC_Explorer to visualize backgroud maps in EFDC model https:\/\/t.co\/A0pZX5Ss\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EFDC_Explorer",
        "screen_name" : "EFDC_Explorer",
        "indices" : [ 42, 56 ],
        "id_str" : "351972911",
        "id" : 351972911
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CVLGrid",
        "indices" : [ 29, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/A0pZX5SsS0",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=URDI1LP_McI&ab_channel=EFDCExplorer",
        "display_url" : "youtube.com\/watch?v=URDI1L\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "703264066014302208",
    "text" : "Create georeferenced maps in #CVLGrid and @EFDC_Explorer to visualize backgroud maps in EFDC model https:\/\/t.co\/A0pZX5SsS0",
    "id" : 703264066014302208,
    "created_at" : "2016-02-26 17:03:14 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 703264246201618433,
  "created_at" : "2016-02-26 17:03:56 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/kbGqIkpX12",
      "expanded_url" : "https:\/\/www.youtube.com\/playlist?list=PLDdqtlbD-U1zfcvK7Bx8TcNfmnwn0-zCM&ab_channel=EFDCExplorer",
      "display_url" : "youtube.com\/playlist?list=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702532431488782337",
  "text" : "RT @EFDC_Explorer: How to videos on EFDC_Explorer  https:\/\/t.co\/kbGqIkpX12. These will be great resource to getting started with EFDC and @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EFDC_Explorer",
        "screen_name" : "EFDC_Explorer",
        "indices" : [ 119, 133 ],
        "id_str" : "351972911",
        "id" : 351972911
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/kbGqIkpX12",
        "expanded_url" : "https:\/\/www.youtube.com\/playlist?list=PLDdqtlbD-U1zfcvK7Bx8TcNfmnwn0-zCM&ab_channel=EFDCExplorer",
        "display_url" : "youtube.com\/playlist?list=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702531954822897666",
    "text" : "How to videos on EFDC_Explorer  https:\/\/t.co\/kbGqIkpX12. These will be great resource to getting started with EFDC and @EFDC_Explorer .",
    "id" : 702531954822897666,
    "created_at" : "2016-02-24 16:34:05 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 702532431488782337,
  "created_at" : "2016-02-24 16:35:58 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Svein T veitdal",
      "screen_name" : "tveitdal",
      "indices" : [ 3, 12 ],
      "id_str" : "75742264",
      "id" : 75742264
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tveitdal\/status\/697820950604222464\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/Yr5X1Gi6BW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca8oc9fXIAAxzAZ.jpg",
      "id_str" : "697820945273266176",
      "id" : 697820945273266176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca8oc9fXIAAxzAZ.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/Yr5X1Gi6BW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/20ydyNiGr2",
      "expanded_url" : "http:\/\/reneweconomy.com.au\/2016\/australian-super-funds-lose-5-6-billion-on-fossil-fuel-investments-76239",
      "display_url" : "reneweconomy.com.au\/2016\/australia\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697825311015047169",
  "text" : "RT @tveitdal: Australian super funds lose $5.6 billion on fossil fuel investments https:\/\/t.co\/20ydyNiGr2 https:\/\/t.co\/Yr5X1Gi6BW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tveitdal\/status\/697820950604222464\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/Yr5X1Gi6BW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca8oc9fXIAAxzAZ.jpg",
        "id_str" : "697820945273266176",
        "id" : 697820945273266176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca8oc9fXIAAxzAZ.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/Yr5X1Gi6BW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/20ydyNiGr2",
        "expanded_url" : "http:\/\/reneweconomy.com.au\/2016\/australian-super-funds-lose-5-6-billion-on-fossil-fuel-investments-76239",
        "display_url" : "reneweconomy.com.au\/2016\/australia\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697820950604222464",
    "text" : "Australian super funds lose $5.6 billion on fossil fuel investments https:\/\/t.co\/20ydyNiGr2 https:\/\/t.co\/Yr5X1Gi6BW",
    "id" : 697820950604222464,
    "created_at" : "2016-02-11 16:34:14 +0000",
    "user" : {
      "name" : "Svein T veitdal",
      "screen_name" : "tveitdal",
      "protected" : false,
      "id_str" : "75742264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000413900056\/d331f29eb299f905fb9936e8d07a1cec_normal.jpeg",
      "id" : 75742264,
      "verified" : false
    }
  },
  "id" : 697825311015047169,
  "created_at" : "2016-02-11 16:51:33 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Perez",
      "screen_name" : "EdPerezLive",
      "indices" : [ 0, 12 ],
      "id_str" : "1390094640",
      "id" : 1390094640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697576146452529152",
  "geo" : { },
  "id_str" : "697577710009200640",
  "in_reply_to_user_id" : 1390094640,
  "text" : "@EdPerezLive Interesting ones.",
  "id" : 697577710009200640,
  "in_reply_to_status_id" : 697576146452529152,
  "created_at" : "2016-02-11 00:27:41 +0000",
  "in_reply_to_screen_name" : "EdPerezLive",
  "in_reply_to_user_id_str" : "1390094640",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 3, 17 ],
      "id_str" : "351972911",
      "id" : 351972911
    }, {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "indices" : [ 38, 52 ],
      "id_str" : "351972911",
      "id" : 351972911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/72HuGXBR8D",
      "expanded_url" : "http:\/\/www.efdc-explorer.com\/support\/newsletters\/efdc-explorer-did-you-know-2015-06-20.html",
      "display_url" : "efdc-explorer.com\/support\/newsle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697201648020553728",
  "text" : "RT @EFDC_Explorer: Use \"F2\" button on @EFDC_Explorer to find the context specific hot-key actions. https:\/\/t.co\/72HuGXBR8D https:\/\/t.co\/E0t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EFDC_Explorer",
        "screen_name" : "EFDC_Explorer",
        "indices" : [ 19, 33 ],
        "id_str" : "351972911",
        "id" : 351972911
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EFDC_Explorer\/status\/697198823068708864\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/E0t4VZhv3N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CazyooqUkAAmOeq.jpg",
        "id_str" : "697198822259200000",
        "id" : 697198822259200000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CazyooqUkAAmOeq.jpg",
        "sizes" : [ {
          "h" : 368,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 649,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 862,
          "resize" : "fit",
          "w" : 1593
        }, {
          "h" : 862,
          "resize" : "fit",
          "w" : 1593
        } ],
        "display_url" : "pic.twitter.com\/E0t4VZhv3N"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/EFDC_Explorer\/status\/697198823068708864\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/E0t4VZhv3N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cazyop9UMAAGqMJ.jpg",
        "id_str" : "697198822607302656",
        "id" : 697198822607302656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cazyop9UMAAGqMJ.jpg",
        "sizes" : [ {
          "h" : 860,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 860,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 366,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 645,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/E0t4VZhv3N"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/72HuGXBR8D",
        "expanded_url" : "http:\/\/www.efdc-explorer.com\/support\/newsletters\/efdc-explorer-did-you-know-2015-06-20.html",
        "display_url" : "efdc-explorer.com\/support\/newsle\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697198823068708864",
    "text" : "Use \"F2\" button on @EFDC_Explorer to find the context specific hot-key actions. https:\/\/t.co\/72HuGXBR8D https:\/\/t.co\/E0t4VZhv3N",
    "id" : 697198823068708864,
    "created_at" : "2016-02-09 23:22:07 +0000",
    "user" : {
      "name" : "EFDC_Explorer",
      "screen_name" : "EFDC_Explorer",
      "protected" : false,
      "id_str" : "351972911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481641637336989696\/R41dGUpY_normal.jpeg",
      "id" : 351972911,
      "verified" : false
    }
  },
  "id" : 697201648020553728,
  "created_at" : "2016-02-09 23:33:20 +0000",
  "user" : {
    "name" : "Janesh Devkota",
    "screen_name" : "janeshdev",
    "protected" : false,
    "id_str" : "59507236",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933045510272729088\/vcIwRUt5_normal.jpg",
    "id" : 59507236,
    "verified" : false
  }
} ]