var user_details =  {
  "screen_name" : "janeshdev",
  "location" : "Seattle, WA",
  "full_name" : "Janesh Devkota",
  "bio" : "PhD from Auburn, @DSI #rstats , r enthusiast, #datascience, #machinelearning, #python",
  "id" : "59507236",
  "created_at" : "2009-07-23 16:08:18 +0000"
}